import fs from "fs";
import path from "path";

export interface BankDetails {
  holderName: string;
  accountNumber: string;
  ifscCode: string;
  upiId: string;
}

export interface PayoutRequest {
  token: string;
  email: string;
  affiliateCode: string;
  amount: number;
  date: string;
  status: "Processing" | "Credited" | "Returned";
  bankDetails: BankDetails;
  transactionId?: string;
  notes?: string;
}

export interface PricingSettings {
  starter: { price: number; limit: number };
  pro: { price: number; limit: number };
  pro_yearly: { price: number; limit: number };
}

export interface SystemSettings {
  customerDiscount: number;
  affiliateCommission: number;
  validCoupons: string[];
}

export interface AdminData {
  payouts: PayoutRequest[];
  pricingOverrides: PricingSettings;
  systemSettings: SystemSettings;
}

const STORAGE_PATH = path.join(process.cwd(), "server", "admin_storage.json");

const defaultData: AdminData = {
  payouts: [
    {
      token: "TXN-WNX-72A91D",
      email: "spatil23012008@gmail.com",
      affiliateCode: "SPATIL50",
      amount: 13000,
      date: "12 Jun 2026",
      status: "Credited",
      bankDetails: {
        holderName: "Shashidhar Patil",
        accountNumber: "35091029103",
        ifscCode: "SBIN0001830",
        upiId: "spatil@okaxis"
      },
      transactionId: "CF_TXN_8029102",
      notes: "Auto-approved promotional clearance"
    },
    {
      token: "TXN-WNX-31B45F",
      email: "shivanagouda.012@gmail.com",
      affiliateCode: "SHIVANAGOUDA50",
      amount: 4800,
      date: "02 May 2026",
      status: "Credited",
      bankDetails: {
        holderName: "Shivanagouda P",
        accountNumber: "918201202910",
        ifscCode: "HDFC0000412",
        upiId: "shivu@okhdfc"
      },
      transactionId: "CF_TXN_7162531",
      notes: "Manual payout executed"
    },
    {
      token: "TXN-WNX-PENDING",
      email: "ytshivu8@gmail.com",
      affiliateCode: "YTSHIVU50",
      amount: 2500,
      date: "20 Jun 2026",
      status: "Processing",
      bankDetails: {
        holderName: "Shivanand Y",
        accountNumber: "7210291039",
        ifscCode: "ICIC0000104",
        upiId: "ytshivu8@icici"
      }
    }
  ],
  pricingOverrides: {
    starter: { price: 199, limit: 1000 },
    pro: { price: 499, limit: 3000 },
    pro_yearly: { price: 3999, limit: 40000 }
  },
  systemSettings: {
    customerDiscount: 50,
    affiliateCommission: 50,
    validCoupons: ["LAUNCH50", "AFFILIATE50", "WEBNIXO50", "START50"]
  }
};

export function loadAdminData(): AdminData {
  try {
    if (fs.existsSync(STORAGE_PATH)) {
      const content = fs.readFileSync(STORAGE_PATH, "utf-8");
      return JSON.parse(content);
    } else {
      saveAdminData(defaultData);
      return defaultData;
    }
  } catch (err) {
    console.error("[ADMIN STORAGE] Failed load admin data, fallback to default", err);
    return defaultData;
  }
}

export function saveAdminData(data: AdminData): void {
  try {
    // Ensure parent directory of STORAGE_PATH exists
    const dir = path.dirname(STORAGE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(STORAGE_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("[ADMIN STORAGE] Failed saving admin data", err);
  }
}
