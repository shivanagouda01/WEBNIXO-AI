import { createClient, SupabaseClient } from "@supabase/supabase-js";
import dotenv from "dotenv";

dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

let dbClient: SupabaseClient | null = null;
let connectionStatus: {
  connected: boolean;
  hasTables: boolean;
  error?: string;
} = { connected: false, hasTables: false };

export function getSupabase(): SupabaseClient {
  if (!dbClient) {
    if (!supabaseUrl) {
      throw new Error("SUPABASE_URL environment variable is required for database integration.");
    }
    // Prefer service role key for backend operations for complete tables bypass, fallback to anon
    const secretKey = supabaseServiceKey || supabaseAnonKey;
    if (!secretKey) {
      throw new Error("SUPABASE_ANON_KEY or SUPABASE_SERVICE_ROLE_KEY is required for database integration.");
    }
    dbClient = createClient(supabaseUrl, secretKey);
  }
  return dbClient;
}

export async function checkSupabaseConnection() {
  try {
    const client = getSupabase();
    connectionStatus.connected = true;

    // Test if profiles table exists
    const { error: profileError } = await client
      .from("profiles")
      .select("id")
      .limit(1);

    // Test if conversations table exists
    const { error: conversationError } = await client
      .from("conversations")
      .select("id")
      .limit(1);

    if (profileError && profileError.code === "PGRST116") {
      // PGRST116 is just "no rows returned", which means table exists and is empty
    }
    
    const profilesExist = !profileError || profileError.code === "PGRST116" || profileError.code !== "42P01";
    const conversationsExist = !conversationError || conversationError.code === "PGRST116" || conversationError.code !== "42P01";

    if (profilesExist && conversationsExist) {
      connectionStatus.hasTables = true;
      connectionStatus.error = undefined;
    } else {
      connectionStatus.hasTables = false;
      connectionStatus.error = `Tables are missing from your database. Please execute the required SQL schema inside your Supabase SQL Editor. Error codes: Profiles (${profileError?.code || "OK"}), Conversations (${conversationError?.code || "OK"})`;
    }
  } catch (error: any) {
    connectionStatus.connected = false;
    connectionStatus.hasTables = false;
    connectionStatus.error = error.message || "Failed to initialize Supabase connection client.";
    console.error("Supabase check error:", error);
  }
  return connectionStatus;
}

// REST database handlers
export async function getSessionsForEmail(email: string) {
  const client = getSupabase();
  
  // Try querying chat_sessions table if it exists
  try {
    const { data, error } = await client
      .from("chat_sessions")
      .select("*")
      .eq("email", email)
      .order("created_at", { ascending: false });

    if (!error) {
      return data || [];
    }
    
    if (error.code !== "42P01") {
      console.warn(`Non-42P01 error (fetch chat_sessions) for ${email}:`, error);
    }
  } catch (err) {
    console.warn("Exception checking chat_sessions:", err);
  }

  // Fallback to primary profiles -> conversations -> messages standard schema
  try {
    const { data: profile, error: profileErr } = await client
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (profileErr) {
      if (profileErr.code !== "42P01") throw profileErr;
      return [];
    }
    if (!profile) {
      return [];
    }

    const { data: convs, error: convsErr } = await client
      .from("conversations")
      .select("*")
      .eq("user_id", profile.id)
      .order("created_at", { ascending: false });

    if (convsErr) {
      if (convsErr.code !== "42P01") throw convsErr;
      return [];
    }

    if (!convs || convs.length === 0) {
      return [];
    }

    const sessions = [];
    for (const conv of convs) {
      const { data: msgs, error: msgsErr } = await client
        .from("messages")
        .select("*")
        .eq("conversation_id", conv.id)
        .order("created_at", { ascending: true });

      if (msgsErr) {
        if (msgsErr.code !== "42P01") throw msgsErr;
        continue;
      }

      sessions.push({
        id: conv.id,
        email: email,
        title: conv.title,
        prompt_type: "general",
        selected_model: msgs && msgs.length > 0 ? msgs[0].model_used || "google/gemini-3.5-flash" : "google/gemini-3.5-flash",
        created_at: conv.created_at,
        messages: (msgs || []).map((m: any) => ({
          role: m.role,
          content: m.content,
          model: m.model_used,
          timestamp: m.created_at
        }))
      });
    }

    return sessions;
  } catch (schemaErr: any) {
    console.error("Error retrieving conversations from standard schema:", schemaErr);
    return [];
  }
}

export async function upsertChatSession(session: any, email: string) {
  const client = getSupabase();
  const payload = {
    id: session.id,
    email: email,
    title: session.title,
    prompt_type: session.promptType || "general",
    selected_model: session.selectedModel || "google/gemini-3.5-flash",
    created_at: session.createdAt || new Date().toISOString(),
    messages: session.messages || []
  };

  // Try saving to chat_sessions first
  try {
    const { error } = await client
      .from("chat_sessions")
      .upsert(payload, { onConflict: "id" });

    if (!error) {
      return payload;
    }
    if (error.code !== "42P01") {
      console.warn(`Non-42P01 error upserting to chat_sessions:`, error);
    }
  } catch (err) {
    console.warn("Exception upserting to chat_sessions:", err);
  }

  // Fallback to standard profiles -> conversations -> messages
  try {
    let { data: profile, error: pErr } = await client
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (pErr && pErr.code !== "42P01") throw pErr;

    if (!profile) {
      const userId = crypto.randomUUID();
      const { data: newProfile, error: createPErr } = await client
        .from("profiles")
        .insert({
          id: userId,
          email: email,
          full_name: email.split("@")[0],
          plan: "free"
        })
        .select("id")
        .single();
      
      if (createPErr) {
        console.warn("Could not create profile stub in fallback sync:", createPErr);
        return payload;
      }
      profile = newProfile;
    }

    if (profile) {
      const { error: convErr } = await client
        .from("conversations")
        .upsert({
          id: session.id,
          user_id: profile.id,
          title: session.title,
          updated_at: new Date().toISOString()
        }, { onConflict: "id" });

      if (convErr) throw convErr;

      await client
        .from("messages")
        .delete()
        .eq("conversation_id", session.id);

      if (session.messages && session.messages.length > 0) {
        const msgsPayload = session.messages.map((m: any) => {
          let createdAt = new Date().toISOString();
          // Avoid passing raw human local timestamps like "05:30 PM" to PostgreSQL.
          // Only use m.timestamp if it is a valid parsable ISO timestamp format.
          if (m.timestamp && m.timestamp.includes("-") && m.timestamp.includes("T")) {
            createdAt = m.timestamp;
          }
          return {
            conversation_id: session.id,
            role: m.role === "assistant" ? "assistant" : "user",
            content: m.content || "",
            model_used: session.selectedModel || "google/gemini-3.5-flash",
            created_at: createdAt
          };
        });

        const { error: msgsInsErr } = await client
          .from("messages")
          .insert(msgsPayload);

        if (msgsInsErr) throw msgsInsErr;
      }
    }
  } catch (schemaErr: any) {
    console.error("Error upserting into standard schema:", schemaErr);
  }

  return payload;
}

export async function deleteChatSession(id: string, email: string) {
  const client = getSupabase();
  try {
    const { error } = await client
      .from("chat_sessions")
      .delete()
      .eq("id", id)
      .eq("email", email);

    if (!error) {
      return { success: true };
    }
    if (error.code !== "42P01") {
      console.warn(`Non-42P01 error deleting from chat_sessions:`, error);
    }
  } catch (err) {
    console.warn("Exception deleting from chat_sessions:", err);
  }

  try {
    const { error } = await client
      .from("conversations")
      .delete()
      .eq("id", id);

    if (error) throw error;
  } catch (schemaErr) {
    console.error("Error deleting conversation from standard schema:", schemaErr);
  }

  return { success: true };
}

export async function clearAllSessionsForEmail(email: string) {
  const client = getSupabase();
  try {
    const { error } = await client
      .from("chat_sessions")
      .delete()
      .eq("email", email);

    if (!error) {
      return { success: true };
    }
    if (error.code !== "42P01") {
      console.warn(`Non-42P01 error clearing chat_sessions:`, error);
    }
  } catch (err) {
    console.warn("Exception clearing chat_sessions:", err);
  }

  try {
    const { data: profile } = await client
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (profile) {
      const { error } = await client
        .from("conversations")
        .delete()
        .eq("user_id", profile.id);

      if (error) throw error;
    }
  } catch (schemaErr) {
    console.error("Error clearing conversations in standard schema:", schemaErr);
  }

  return { success: true };
}

export async function getGenerationsForEmail(email: string) {
  const client = getSupabase();
  try {
    const { data, error } = await client
      .from("saved_generations")
      .select("*")
      .eq("email", email)
      .order("created_at", { ascending: false });

    if (error) {
      if (error.code !== "42P01") {
        console.warn(`Non-42P01 error fetching generations for ${email}:`, error);
      }
      return [];
    }

    // Map database format back to client model
    return (data || []).map(row => ({
      id: row.id,
      prompt: row.prompt,
      url: row.url,
      model: row.model,
      aspectRatio: row.aspect_ratio,
      artStyle: row.art_style,
      cfgScale: Number(row.cfg_scale),
      steps: Number(row.steps),
      seed: Number(row.seed),
      createdAt: row.created_at
    }));
  } catch (err) {
    console.warn("Exception fetching generations:", err);
    return [];
  }
}

export async function insertGeneration(gen: any, email: string) {
  const client = getSupabase();
  const payload = {
    id: gen.id,
    email: email,
    prompt: gen.prompt,
    url: gen.url,
    model: gen.model,
    aspect_ratio: gen.aspectRatio,
    art_style: gen.artStyle || "none",
    cfg_scale: gen.cfgScale,
    steps: gen.steps,
    seed: gen.seed,
    created_at: gen.createdAt || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  try {
    const { error } = await client
      .from("saved_generations")
      .insert(payload);

    if (error) {
      if (error.code !== "42P01") {
        console.warn(`Non-42P01 error saving generation ${gen.id}:`, error);
      }
    }
  } catch (err) {
    console.warn("Exception inserting generation:", err);
  }
  return payload;
}

export async function deleteGenerationFromDb(id: string, email: string) {
  const client = getSupabase();
  try {
    const { error } = await client
      .from("saved_generations")
      .delete()
      .eq("id", id)
      .eq("email", email);

    if (error) {
      if (error.code !== "42P01") {
        console.warn(`Non-42P01 error deleting generation ${id}:`, error);
      }
    }
  } catch (err) {
    console.warn("Exception deleting generation:", err);
  }
  return { success: true };
}

export async function clearAllGenerationsForEmail(email: string) {
  const client = getSupabase();
  try {
    const { error } = await client
      .from("saved_generations")
      .delete()
      .eq("email", email);

    if (error) {
      if (error.code !== "42P01") {
        console.warn(`Non-42P01 error clearing generations for ${email}:`, error);
      }
    }
  } catch (err) {
    console.warn("Exception clearing generations:", err);
  }
  return { success: true };
}

// === CENTRAL CREDIT & SUBSCRIPTION ENGINE HELPERS ===

import { PRICING_PLANS } from "../src/lib/pricing_config";

/**
 * Normalizes a date to YYYY-MM-DD
 */
function getTodayString(): string {
  const d = new Date();
  return d.toISOString().split("T")[0]; // YYYY-MM-DD
}

/**
 * Normalizes a date to YYYY-MM
 */
function getCurrentMonthString(): string {
  const d = new Date();
  return d.toISOString().substring(0, 7); // YYYY-MM
}

/**
 * Fetches and synchronizes user credits and plan details from Supabase.
 * Implements auto-reset of credits on period roll-overs.
 */
export async function getOrCreateUserCredits(email: string) {
  const client = getSupabase();
  const todayStr = getTodayString();
  const monthStr = getCurrentMonthString();

  try {
    // 1. Fetch profile to get plan
    const { data: profile, error: pError } = await client
      .from("profiles")
      .select("*")
      .eq("email", email)
      .maybeSingle();

    if (pError || !profile) {
      // Graceful fallback for non-existent profiles / missing db tables
      return {
        plan: "free",
        creditsUsed: 0,
        totalCredits: PRICING_PLANS.free.limit,
        creditsRemaining: PRICING_PLANS.free.limit,
        period: "day" as const,
        warning: false,
        isBelowTenPercent: false,
        lastResetDate: todayStr,
      };
    }

    const planKey = (profile.plan || "free").toLowerCase() as "free" | "starter" | "pro" | "pro_yearly";
    const plan = PRICING_PLANS[planKey] || PRICING_PLANS.free;

    // 2. Fetch or create user usage record
    let { data: usage, error: uError } = await client
      .from("user_usage")
      .select("*")
      .eq("user_id", profile.id)
      .maybeSingle();

    if (uError || !usage) {
      // Create user usage row
      const { data: newUsage, error: insertError } = await client
        .from("user_usage")
        .insert({
          id: profile.id,
          user_id: profile.id,
          prompts_used_today: 0,
          images_generated_today: 0,
          last_reset_date: todayStr
        })
        .select()
        .single();

      if (!insertError && newUsage) {
        usage = newUsage;
      } else {
        // Fallback usage
        usage = {
          prompts_used_today: 0,
          last_reset_date: todayStr
        };
      }
    }

    let creditsUsed = usage.prompts_used_today || 0;
    let dbResetDate = usage.last_reset_date ? String(usage.last_reset_date) : todayStr;
    let shouldReset = false;

    // 3. Evaluate cycle period limits and auto-resets
    if (plan.period === "day") {
      // Daily reset for Free: compare todayStr with dbResetDate
      if (dbResetDate !== todayStr) {
        shouldReset = true;
      }
    } else if (plan.period === "year") {
      // Yearly reset for Pro Yearly: compare dbResetYear with current year
      const dbResetYear = dbResetDate.substring(0, 4);
      const currentYear = todayStr.substring(0, 4);
      if (dbResetYear !== currentYear) {
        shouldReset = true;
      }
    } else {
      // Monthly reset for Starter / Pro: compare monthStr (YYYY-MM) with dbResetDate's month
      const dbResetMonth = dbResetDate.substring(0, 7);
      if (dbResetMonth !== monthStr) {
        shouldReset = true;
      }
    }

    if (shouldReset) {
      creditsUsed = 0;
      dbResetDate = todayStr;

      // Update in background
      await client
        .from("user_usage")
        .update({
          prompts_used_today: 0,
          last_reset_date: todayStr
        })
        .eq("user_id", profile.id);
    }

    const creditsRemaining = Math.max(0, plan.limit - creditsUsed);
    const isBelowTenPercent = creditsRemaining < (plan.limit * 0.1);

    return {
      plan: plan.key,
      creditsUsed,
      totalCredits: plan.limit,
      creditsRemaining,
      period: plan.period,
      warning: isBelowTenPercent,
      isBelowTenPercent,
      lastResetDate: dbResetDate,
    };

  } catch (err: any) {
    console.error("Failed to retrieve or reset credits from db:", err);
    return {
      plan: "free",
      creditsUsed: 0,
      totalCredits: PRICING_PLANS.free.limit,
      creditsRemaining: PRICING_PLANS.free.limit,
      period: "day" as const,
      warning: false,
      isBelowTenPercent: false,
      lastResetDate: todayStr,
    };
  }
}

/**
 * Deducts credit cost by updating usage tables.
 */
export async function consumeUserCredits(email: string, amount: number) {
  const client = getSupabase();
  try {
    const { data: profile } = await client
      .from("profiles")
      .select("id, plan")
      .eq("email", email)
      .maybeSingle();

    if (!profile) return false;

    // Fetch current usage row
    const { data: usage } = await client
      .from("user_usage")
      .select("prompts_used_today")
      .eq("user_id", profile.id)
      .maybeSingle();

    const currentUsed = usage ? (usage.prompts_used_today || 0) : 0;
    const newUsed = currentUsed + amount;

    const { error: updateError } = await client
      .from("user_usage")
      .update({
        prompts_used_today: newUsed,
        last_reset_date: getTodayString() // keep updated
      })
      .eq("user_id", profile.id);

    return !updateError;
  } catch (err) {
    console.error("Failed to consume user credits in database:", err);
    return false;
  }
}

/**
 * Upgrades user plan in database and resets current consumption
 */
export async function upgradeUserProfilePlan(email: string, planKey: string) {
  const client = getSupabase();
  const normalizedPlan = planKey.toLowerCase();
  
  try {
    const { data: profile, error: pError } = await client
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (pError || !profile) {
      throw new Error("No user profile found matching this account email.");
    }

    // Update plans column
    const { error: updateError } = await client
      .from("profiles")
      .update({ plan: normalizedPlan })
      .eq("id", profile.id);

    if (updateError) throw updateError;

    // Reset credits consumption to 0 on subscription upgrade
    await client
      .from("user_usage")
      .update({
        prompts_used_today: 0,
        last_reset_date: getTodayString()
      })
      .eq("user_id", profile.id);

    return { success: true, plan: normalizedPlan };
  } catch (err: any) {
    console.error("Failed to update plan inside db engine:", err);
    throw err;
  }
}
