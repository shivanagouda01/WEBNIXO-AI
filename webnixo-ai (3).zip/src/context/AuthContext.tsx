import React, { createContext, useContext, useState, useEffect } from "react";
import { User } from "@supabase/supabase-js";
import { supabase } from "../lib/supabase";
import { SupabaseService, Profile } from "../lib/supabaseService";

// Define the interface for our Auth Context state and actions
interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

// React Context for holding session and profile state
const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  /**
   * Helper function to create or update profile inside profiles table on Supabase.
   * Utilizes Upsert logic so duplicate records are not created.
   */
  const upsertUserProfile = async (currentUser: User): Promise<Profile | null> => {
    try {
      const email = currentUser.email || "";
      const fullName = currentUser.user_metadata?.full_name || email.split("@")[0] || "Spec Specialist";
      const avatarUrl = currentUser.user_metadata?.avatar_url || "";

      // Construct profile payload for upsert
      const profileData: any = {
        id: currentUser.id,
        email: email,
        full_name: fullName,
        avatar_url: avatarUrl,
        plan: "free", // default signup plan
        updated_at: new Date().toISOString()
      };

      // Check if profile exists, to preserve their plan if they already upgraded
      const existingProfile = await SupabaseService.getProfile(currentUser.id);
      if (existingProfile) {
        // If profile exists, merge fields safely while keeping the original created_at and plan
        profileData.plan = existingProfile.plan || "free";
        profileData.created_at = existingProfile.created_at;
      } else {
        profileData.created_at = new Date().toISOString();
      }

      // Perform the Supabase upsert operation
      const { data, error: upsertError } = await supabase
        .from("profiles")
        .upsert(profileData, { onConflict: "id" })
        .select()
        .single();

      if (upsertError) {
        console.error("Supabase Profile Upsert Error:", upsertError.message);
        throw upsertError;
      }

      return data as Profile;
    } catch (err: any) {
      console.error("Failed to create/update user profile:", err.message || err);
      return null;
    }
  };

  /**
   * Safe retrieval or refresh of profile data
   */
  const refreshProfile = async () => {
    if (!user) return;
    try {
      const prof = await SupabaseService.getProfile(user.id);
      if (prof) {
        setProfile(prof);
      }
    } catch (err: any) {
      console.error("Error refreshing profile:", err);
    }
  };

  // Triggered on first load to initialize session from Supabase
  useEffect(() => {
    let active = true;

    const initializeAuth = async () => {
      try {
        setLoading(true);

        // --- DETAILED DIAGNOSTIC LOGGING FOR OAUTH DEBUGGING ---
        console.log("=== [DEBUG] AUTHCONTEXT INITIALIZING SYSTEM STATE ===");
        console.log("Current Origin:", window.location.origin);
        console.log("Current Page URL:", window.location.href);
        console.log("Search parameters received:", window.location.search);
        console.log("Hash parameters received:", window.location.hash);

        // Read and log Supabase specific keys to verify PKCE state verifiers parity
        const sbKeys = Object.keys(localStorage).filter(
          k => k.includes("supabase") || k.includes("sb-") || k.includes("verifier")
        );
        console.log("Detected local storage keys matching Supabase queries:", sbKeys);
        sbKeys.forEach(key => {
          try {
            console.log(`Local item [${key}] value snippet:`, localStorage.getItem(key)?.substring(0, 55) + "...");
          } catch (storageErr) {
            console.error(`Failed to read key [${key}] from storage:`, storageErr);
          }
        });
        console.log("====================================================");

        // Handle error parameters parsed directly from the redirect URL
        const urlParams = new URLSearchParams(window.location.search);
        const urlError = urlParams.get("error");
        const urlErrorDesc = urlParams.get("error_description");
        const urlErrorCode = urlParams.get("error_code");

        if (urlError) {
          console.error("AuthContext: Discovered OAuth error parameter in URL query:", { urlError, urlErrorDesc, urlErrorCode });
          const errorMessage = `OAuth Error [Code: ${urlErrorCode || "unknown"}]: ${decodeURIComponent(urlErrorDesc || urlError)}`;
          
          if (active) {
            setError(errorMessage);
            // Clean up the URL in address bar to prevent bad reloads
            window.history.replaceState(null, "", window.location.origin + window.location.pathname);
          }
          setLoading(false);
          return;
        }

        // Step 1: Check existing authenticated session
        console.log("AuthContext: Fetching Supabase session...");
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          throw sessionError;
        }

        if (session?.user) {
          console.log("AuthContext: Successfully retrieved active user session:", session.user.email);
          if (active) {
            setUser(session.user);
            // Upsert / fetch profile
            const prof = await upsertUserProfile(session.user);
            if (prof && active) {
              setProfile(prof);
            }
          }
        } else {
          console.log("AuthContext: No active user session detected on load.");
        }
      } catch (err: any) {
        console.error("AuthContext: Unexpected authentication core failure:", err);
        if (active) {
          setError(err.message || "Authentication initialization failed.");
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    initializeAuth();

    // Step 2: Establish listener for auth status changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!active) return;
      
      console.log(`[Supabase Auth Listener] Event: ${event}. Session Active?`, !!session);
      
      if (session?.user) {
        setUser(session.user);
        // Execute profile upsert in the background to prevent blocking the UI with loading screens
        upsertUserProfile(session.user).then((prof) => {
          if (prof && active) {
            setProfile(prof);
          }
        });
      } else {
        setUser(null);
        setProfile(null);
      }
      
      // Assure loading is complete
      setLoading(false);
    });

    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);

  // Initiate Google Authentication OAuth login
  const signInWithGoogle = async () => {
    try {
      setLoading(true);
      setError(null);

      const redirectUrl = window.location.origin;
      console.log("[Supabase Auth] Initiating Google sign-in. redirecting user back to:", redirectUrl);
      
      const { error: signInError } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: redirectUrl
        }
      });

      if (signInError) {
        throw signInError;
      }
    } catch (err: any) {
      console.error("[Supabase Auth] Initiating Google sign-in failed:", err);
      setError(err.message || "An error occurred starting Google OAuth.");
      setLoading(false);
    }
  };

  // Sign out user session
  const signOut = async () => {
    try {
      setLoading(true);
      localStorage.removeItem("login_as");
      const { error: signOutError } = await supabase.auth.signOut();
      if (signOutError) {
        throw signOutError;
      }
      setUser(null);
      setProfile(null);
    } catch (err: any) {
      setError(err.message || "Failed to sign out of active session.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, error, signInWithGoogle, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

// Reusable hook for children components to access auth variables
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be consumed within an AuthProvider Wrapper.");
  }
  return context;
};
