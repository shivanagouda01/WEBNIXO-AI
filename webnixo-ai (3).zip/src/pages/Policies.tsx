import React, { useEffect, useState } from "react";
import { useParams, Navigate, Link } from "react-router-dom";
import { Copy, CheckCircle2 } from "lucide-react";

export function Policies() {
  const { policyType } = useParams<{ policyType: string }>();
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [policyType]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const policies: Record<string, { title: string; content: React.ReactNode; lastUpdated: string }> = {
    privacy: {
      title: "Privacy Policy",
      lastUpdated: "June 22, 2026",
      content: (
        <div className="space-y-6 text-zinc-300">
          <p>
            At WEBNIXO AI, we are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, and safeguard your data when you use our services.
          </p>
          <h3 className="text-xl font-bold text-white mt-8 mb-4">1. Information We Collect</h3>
          <p>
            When you interact with our platform, we may collect the following types of information:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li><strong>Account Information:</strong> Name, email address, password, and billing details.</li>
            <li><strong>Usage Data:</strong> Information on how you use our API, features accessed, and connection logs.</li>
            <li><strong>Device Data:</strong> IP address, browser type, operating system, and authentication tokens.</li>
          </ul>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">2. How We Use Your Information</h3>
          <p>We use the data we collect for the following purposes:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>To provide, maintain, and improve our platform and AI sandbox instances.</li>
            <li>To process your transactions and manage your billing cycles.</li>
            <li>To send you important notices, technical updates, and security alerts.</li>
            <li>To monitor usage patterns and prevent fraudulent activities or abuse of the services.</li>
          </ul>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">3. Data Security and Privacy</h3>
          <p>
            We implement industry-standard encryption protocols to protect your data both in transit and at rest. Access to your personal data is restricted to authorized personnel only. We do NOT use your private API prompts to train our foundational models unless you explicitly opt-in.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">4. Sharing Your Information</h3>
          <p>
            We do not sell your personal data to third parties. We may share data with trusted service providers who assist us in operating our platform, conducting our business, or serving our users, so long as those parties agree to keep this information confidential.
          </p>
          
          <h3 className="text-xl font-bold text-white mt-8 mb-4">5. Your Rights</h3>
          <p>
            Depending on your jurisdiction, you may have the right to access, correct, or delete your personal data. If you have any requests regarding your data, please contact our privacy team.
          </p>
        </div>
      ),
    },
    terms: {
      title: "Terms of Service",
      lastUpdated: "June 22, 2026",
      content: (
        <div className="space-y-6 text-zinc-300">
          <p>
            These Terms of Service ("Terms") govern your use of the WEBNIXO AI platform, websites, and related services. By accessing or using our services, you agree to be bound by these Terms.
          </p>
          <h3 className="text-xl font-bold text-white mt-8 mb-4">1. Acceptance of Terms</h3>
          <p>
            By creating an account, you confirm that you are of legal age in your jurisdiction and have the authority to accept these Terms on behalf of any organization you represent.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">2. Acceptable Use</h3>
          <p>
            You agree to use our platform only for lawful purposes. You are strictly prohibited from:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Using the service for illegal activities, harassment, or to generate malicious code.</li>
            <li>Attempting to bypass our security measures, rate limits, or reverse-engineer the API.</li>
            <li>Using compromised credentials or unauthorized payment methods.</li>
            <li>Generating content that violates third-party intellectual property rights.</li>
          </ul>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">3. Subscriptions and Payments</h3>
          <p>
            Certain services are billed on a subscription basis. You will be billed in advance on a recurring schedule. If auto-renewal is enabled, your payment method will automatically be charged until you cancel the subscription. We reserve the right to suspend accounts with overdue payments.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">4. Service Availability</h3>
          <p>
            We strive to maintain a high uptime for our services. However, WEBNIXO AI does not guarantee uninterrupted or error-free operations. We are not liable for any downtime resulting from maintenance, network failures, or circumstances beyond our control.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">5. Termination</h3>
          <p>
            We reserve the right to terminate or suspend your account immediately, without prior notice or liability, for any reason, including without limitation if you breach the Terms of Service.
          </p>
        </div>
      ),
    },
    cookies: {
      title: "Cookie Consent & Policy",
      lastUpdated: "June 22, 2026",
      content: (
        <div className="space-y-6 text-zinc-300">
          <p>
            This Cookie Policy explains how WEBNIXO AI uses cookies and similar technologies to recognize you when you visit our website. It explains what these technologies are and why we use them, as well as your rights to control our use of them.
          </p>
          
          <h3 className="text-xl font-bold text-white mt-8 mb-4">1. What are Cookies?</h3>
          <p>
            Cookies are small data files that are placed on your computer or mobile device when you visit a website. Cookies are widely used by website owners to make their websites work, or to work more efficiently, as well as to provide reporting information.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">2. How We Use Cookies</h3>
          <p>We use cookies for the following purposes:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li><strong>Essential Cookies:</strong> These are strictly necessary to provide you with services available through our website, such as secure login sessions.</li>
            <li><strong>Performance & Analytics Cookies:</strong> These cookies collect information to help us understand how our website is being used, so we can improve the user experience.</li>
            <li><strong>Functionality Cookies:</strong> Used to remember your preferences (like theme or language selection) to provide a more personalized experience.</li>
          </ul>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">3. Third-Party Cookies</h3>
          <p>
            In some special cases, we also use cookies provided by trusted third parties, such as analytics providers or payment gateways, to ensure secure processing and measure site performance.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">4. Managing Your Cookie Preferences</h3>
          <p>
            You have the right to decide whether to accept or reject non-essential cookies. You can set or amend your web browser controls to accept or refuse cookies. If you choose to reject cookies, you may still use our website, though your access to some functionality and areas may be restricted.
          </p>
        </div>
      ),
    },
    refund: {
      title: "Refund & Cancellation Policy",
      lastUpdated: "June 22, 2026",
      content: (
        <div className="space-y-6 text-zinc-300">
          <p>
            We want you to be completely satisfied with WEBNIXO AI. This policy outlines the terms under which refunds and subscription cancellations are handled.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">1. General Refund Policy</h3>
          <p>
            As our services involve the allocation of significant computational resources (such as GPU time and AI model inference), refunds are generally not provided for standard monthly subscription fees once the billing cycle has begun, except where required by law.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">2. 14-Day Money-Back Guarantee</h3>
          <p>
            For first-time subscribers on an Annual Plan, we offer a 14-day money-back guarantee. If you are not satisfied with the platform within your first 14 days, you may request a full refund by contacting support. Note: High volume of usage (exceeding 20% of your allocated monthly credits within the 14 days) may void the guarantee.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">3. Accidental Charges</h3>
          <p>
            If you notice an unauthorized or accidental charge on your account, please contact our billing team within 7 days. Once we verify that the charge was made in error and the allocated resources were not consumed, we will issue a full refund to your original payment method.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">4. Cancellation Policy</h3>
          <p>
            You can cancel your subscription at any time via your account dashboard. Upon cancellation, you will continue to have access to your paid features until the end of your current billing period. We do not provide prorated refunds for mid-cycle cancellations.
          </p>

          <h3 className="text-xl font-bold text-white mt-8 mb-4">5. Service Interruptions</h3>
          <p>
            In the rare event of prolonged, significant platform downtime (&gt; 24 hours), we may, at our sole discretion, issue credit adjustments to affected active subscribers.
          </p>
        </div>
      ),
    },
  };

  const currentPolicy = policies[policyType || ""];

  if (!currentPolicy) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-[#09090b] text-white selection:bg-indigo-500/30 selection:text-indigo-200 font-sans flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#09090b]/80 backdrop-blur-xl border-b border-zinc-900/60 transition-all shadow-sm">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group transition-transform active:scale-95 cursor-pointer">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-zinc-900 border border-zinc-800 shadow-xl overflow-hidden">
              <img 
                src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                alt="Webnixo AI Logo" 
                className="w-5 h-5 object-contain" 
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="font-sans font-extrabold text-lg text-white tracking-tight group-hover:text-indigo-400 transition-colors">WEBNIXO AI</span>
          </Link>
          <div className="text-zinc-500 font-mono text-xs hidden sm:block">
            LEGAL // DOCUMENTATION
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow max-w-4xl mx-auto px-6 py-12 w-full">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 pb-8 border-b border-zinc-900/60">
          <div>
            <div className="text-indigo-400 font-mono text-sm font-bold uppercase tracking-widest mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
              {currentPolicy.title}
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-none mb-4">
              {currentPolicy.title}
            </h1>
            <p className="text-zinc-400 font-medium">Last Updated: {currentPolicy.lastUpdated}</p>
          </div>
          
          <button 
            onClick={handleCopyLink}
            className="flex items-center gap-2 text-xs font-bold text-zinc-300 hover:text-white bg-zinc-900 hover:bg-zinc-800 px-4 py-2 rounded-lg border border-zinc-800 transition-colors self-start sm:self-auto cursor-pointer"
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            {copied ? "Link Copied" : "Copy Link"}
          </button>
        </div>

        <article className="prose prose-invert prose-zinc max-w-none prose-headings:font-bold prose-h3:text-white prose-p:text-zinc-300 prose-a:text-indigo-400 hover:prose-a:text-indigo-300">
          {currentPolicy.content}
        </article>

        <div className="mt-16 pt-8 border-t border-zinc-900/60 flex justify-between items-center text-sm font-medium text-zinc-500">
          <p>© {new Date().getFullYear()} WEBNIXO AI. All rights reserved.</p>
          <Link to="/" className="text-indigo-400 hover:text-indigo-300 hover:underline">Return to Home</Link>
        </div>
      </main>
    </div>
  );
}
