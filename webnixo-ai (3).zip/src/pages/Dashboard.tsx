import React, { useState, useEffect, useRef } from "react";
import { 
  MessageSquare, 
  Plus, 
  Trash2, 
  Edit2, 
  Check, 
  X, 
  Send, 
  Sparkles, 
  Terminal, 
  Compass, 
  BookOpen, 
  Menu, 
  Paperclip, 
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  RefreshCw,
  Search,
  CheckCircle,
  AlertCircle,
  LogOut,
  Image as ImageIcon,
  Database,
  CreditCard,
  ShieldCheck,
  User,
  Settings,
  Columns,
  Lock,
  HelpCircle,
  GitCompare,
  Layers,
  Zap
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Message, ChatSession, ModelOption } from "../types";
import { MarkdownRenderer } from "../components/MarkdownRenderer";
import { ImageStudio } from "../components/ImageStudio";
import { useAuth } from "../context/AuthContext";
import { isModelAllowedOnPlan, getModelCreditCost, getPlanCost, PRICING_PLANS, AFFILIATE_SYSTEM } from "../lib/pricing_config";
import { supabase } from "../lib/supabase";

const MODEL_OPTIONS: ModelOption[] = [
  { 
    id: "google/gemini-3.5-flash", 
    name: "Gemini 3.5 Flash", 
    description: "Next-gen premier Google model. Outstanding speed, rich instructions context, and excellent reasoning parameters.", 
    badge: "New",
    logo: "https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m"
  },
  { 
    id: "google/gemini-2.5-flash", 
    name: "Gemini 2.5 Flash", 
    description: "Extremely fast, multimodal champion. Perfect for general discussions and rapid responses.", 
    badge: "Fast",
    logo: "https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m"
  },
  { 
    id: "openai/gpt-5.5-preview", 
    name: "GPT-5.5 Preview", 
    description: "Next-generation pre-release frontier model. Unrivaled long-form coherence and creative intelligence.", 
    badge: "Futuristic",
    logo: "https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa"
  },
  { 
    id: "openai/gpt-5.5", 
    name: "GPT 5.5", 
    description: "The next-generation production powerhouse. Pinnacle logical performance, layout crafting, and comprehensive reasoning.", 
    badge: "Premium",
    logo: "https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa"
  },
  { 
    id: "openai/gpt-4o", 
    name: "GPT-4o", 
    description: "Highly intelligent conversational flagship. Exceptional reasoning, coding logic, and world knowledge.", 
    badge: "Smart",
    logo: "https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa"
  },
  { 
    id: "openai/gpt-o1-preview", 
    name: "OpenAI o1 Preview", 
    description: "Advanced reasoning model that thinks before responding. Excellent for science, coding logic, and mathematics.", 
    badge: "Reasoning",
    logo: "https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa"
  },
  { 
    id: "anthropic/claude-opus-4.8", 
    name: "Claude Opus 4.8", 
    description: "Flagship supercomputing model for advanced architectural layout, sequential programming, and deep logic analysis.", 
    badge: "Premium Boost",
    logo: "https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw"
  },
  { 
    id: "anthropic/claude-sonnet-4.5", 
    name: "Claude Sonnet 4.5", 
    description: "Precision-tuned sonnet. Industry-defining speed, linguistic clarity, prose crafting and modular web code generation.", 
    badge: "New Premium",
    logo: "https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw"
  },
  { 
    id: "anthropic/claude-3-5-sonnet", 
    name: "Claude 3.5 Sonnet", 
    description: "Superb prose generation, professional nuance, structured explanations, and precise coding helpers.", 
    badge: "Pro",
    logo: "https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw"
  },
  { 
    id: "xai/grok-2", 
    name: "xAI Grok-2", 
    description: "Real-time aware, witty and informative routing engine with exceptional analytical depth.", 
    badge: "Grok",
    logo: "https://lh3.googleusercontent.com/d/1YwA9adPBxxiSJho0oitmi8eAxR_JZ5Q9"
  },
  { 
    id: "mistralai/mistral-large-2", 
    name: "Mistral Large 2", 
    description: "Mistral's top European powerhouse. Exceptional multilingual capabilities and reasoning parameters.", 
    badge: "Global",
    logo: "https://lh3.googleusercontent.com/d/1yfqzyKb6799thhOSIN7V7a_6V78mo57h"
  },
  { 
    id: "mistralai/codestral", 
    name: "Mistral Codestral", 
    description: "Specialist programming assistant designed for flawless multi-language developer outputs.", 
    badge: "Coder",
    logo: "https://lh3.googleusercontent.com/d/1yfqzyKb6799thhOSIN7V7a_6V78mo57h"
  },
  { 
    id: "deepseek/deepseek-chat", 
    name: "DeepSeek Chat", 
    description: "Advanced open-weights alternative. Excellent value, math, structured queries, and analysis.", 
    badge: "Econ",
    logo: "https://lh3.googleusercontent.com/d/1Fbg0NTwHIIcYDrsMx66sE9PB1FbnpfvZ"
  },
  { 
    id: "perplexity/sonar", 
    name: "Perplexity Sonar", 
    description: "Elite real-time search and web grounding engine. Excellent for live citations and up-to-date context.", 
    badge: "Search",
    logo: "https://img.icons8.com/ios-filled/50/ffffff/globe.png"
  }
];

const MODEL_GROUPS = [
  {
    label: "Google Gemini",
    models: ["google/gemini-3.5-flash", "google/gemini-2.5-flash"]
  },
  {
    label: "OpenAI GPT",
    models: ["openai/gpt-5.5-preview", "openai/gpt-5.5", "openai/gpt-4o", "openai/gpt-o1-preview"]
  },
  {
    label: "Anthropic Claude",
    models: ["anthropic/claude-opus-4.8", "anthropic/claude-sonnet-4.5", "anthropic/claude-3-5-sonnet"]
  },
  {
    label: "Other Frontier Models",
    models: [
      "xai/grok-2",
      "mistralai/mistral-large-2",
      "mistralai/codestral",
      "deepseek/deepseek-chat",
      "perplexity/sonar"
    ]
  }
];

const PRESET_SUGGESTIONS = [
  {
    title: "Plan a dynamic trip",
    subtitle: "Explore beautiful historical libraries & tea houses in Kyoto, Japan",
    prompt: "Can you design a comprehensive 3-day itinerary for Kyoto that focuses on serene historical libraries, hidden Zen gardens, and authentic wood-paneled tea houses? Include neighborhood navigation tips.",
    icon: Compass,
    color: "text-amber-400"
  },
  {
    title: "Automate reports script",
    subtitle: "Write a neat Python script that collects CSV metrics & dispatches a summary",
    prompt: "Develop a clean, well-commented Python script that reads a daily sales CSV file, calculates vital KPIs (gross margin, total sales, top products), and drafts a friendly email summary formatted in clean HTML.",
    icon: Terminal,
    color: "text-emerald-400"
  },
  {
    title: "Solve typescript state",
    subtitle: "Demonstrate simple reactive state management patterns for SPA widgets",
    prompt: "Can you show me a beautifully structured React custom Hook pattern with TypeScript for securely holding complex local storage state, with generic support and schema safety checks?",
    icon: Sparkles,
    color: "text-sky-400"
  },
  {
    title: "Creative branding concepts",
    subtitle: "Invent names & tagline matrix for a vintage coffee brand with cozy aesthetics",
    prompt: "I need 6 highly distinct, cozy, and vintage name ideas with taglines for an artisanal slow-brew coffee shop. Avoid generic corporate prefixes and make them sound authentic and nostalgic.",
    icon: BookOpen,
    color: "text-purple-400"
  }
];

export const Dashboard: React.FC = () => {
  const { user, profile, signOut, refreshProfile } = useAuth();

  // Create clean user model matching App.tsx's expectations
  const currentUser = user ? {
    name: profile?.full_name || user.user_metadata?.full_name || user.email?.split("@")[0] || "WEBNIXO User",
    email: user.email || ""
  } : null;

  // State for sessions
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string>("");
  const [inputText, setInputText] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // UI States
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isEditingSessionId, setIsEditingSessionId] = useState<string | null>(null);
  const [editTitleValue, setEditTitleValue] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<string>("google/gemini-3.5-flash");
  const [isSideBySideMode, setIsSideBySideMode] = useState<boolean>(false);
  const [comparisonModel, setComparisonModel] = useState<string>("deepseek/deepseek-chat");
  const [comparisonModelC, setComparisonModelC] = useState<string>("openai/gpt-4o");
  const [comparisonModelD, setComparisonModelD] = useState<string>("anthropic/claude-3-5-sonnet");
  const [isThreeModelMode, setIsThreeModelMode] = useState<boolean>(false);
  const [isFourModelMode, setIsFourModelMode] = useState<boolean>(false);
  const [promptType, setPromptType] = useState<"general" | "creative" | "code" | "concise" | "website" | "blog" | "social">("general");
  const [activeWorkspace, setActiveWorkspace] = useState<"chat" | "image">("chat");

  // Supabase Sync States
  const [dbStatus, setDbStatus] = useState<{ connected: boolean; hasTables: boolean; error?: string } | null>(null);
  const [dbLoading, setDbLoading] = useState<boolean>(false);
  const [showDbInstallModal, setShowDbInstallModal] = useState<boolean>(false);

  // Account & Billing settings modal states
  const [showAccountSettingsModal, setShowAccountSettingsModal] = useState<boolean>(false);
  const [openedMainFaqIndex, setOpenedMainFaqIndex] = useState<number | null>(null);
  const [tempFullName, setTempFullName] = useState<string>("");
  const [profileSaving, setProfileSaving] = useState<boolean>(false);
  const [profileSaveSuccess, setProfileSaveSuccess] = useState<string | null>(null);

  // Billing Coupon and simulated payment states
  const [upgradeCoupon, setUpgradeCoupon] = useState<string>("");
  const [upgradePercent, setUpgradePercent] = useState<number>(0);
  const [upgradeDiscount, setUpgradeDiscount] = useState<number>(0); // Flat ₹50 off affiliate coupon discount
  const [upgradeCouponSuccess, setUpgradeCouponSuccess] = useState<string | null>(null);
  const [upgradeCouponError, setUpgradeCouponError] = useState<string | null>(null);
  const [isProcessingUpgrade, setIsProcessingUpgrade] = useState<boolean>(false);

  // Credit system dashboard state
  const [creditsState, setCreditsState] = useState<{
    plan: string;
    creditsUsed: number;
    totalCredits: number;
    creditsRemaining: number;
    period: string;
    warning: boolean;
    isBelowTenPercent: boolean;
    lastResetDate: string;
  } | null>(null);

  // File attachments state for multimodal user uploads
  const [attachedFiles, setAttachedFiles] = useState<{
    id: string;
    name: string;
    type: string;
    size: number;
    content: string;
    isImage: boolean;
    base64?: string;
  }[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const filesArray = Array.from(e.target.files) as File[];

    filesArray.forEach((file: File) => {
      const isImg = file.type.startsWith("image/");
      const reader = new FileReader();

      if (isImg) {
        reader.onloadend = () => {
          setAttachedFiles(prev => [
            ...prev,
            {
              id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              name: file.name,
              type: file.type,
              size: file.size,
              content: "[Base64 Image Data]",
              isImage: true,
              base64: reader.result as string
            }
          ]);
        };
        reader.readAsDataURL(file);
      } else {
        reader.onload = () => {
          setAttachedFiles(prev => [
            ...prev,
            {
              id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              name: file.name,
              type: file.type,
              size: file.size,
              content: reader.result as string,
              isImage: false
            }
          ]);
        };
        reader.readAsText(file);
      }
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const removeAttachedFile = (id: string) => {
    setAttachedFiles(prev => prev.filter(f => f.id !== id));
  };

  // Backend Connection Health Indicator
  const [backendOperational, setBackendOperational] = useState<boolean | null>(null);
  const [isCheckingHealth, setIsCheckingHealth] = useState<boolean>(false);

  // References
  const messageEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Sync user profile name with local temp state
  useEffect(() => {
    if (profile?.full_name) {
      setTempFullName(profile.full_name);
    } else if (user?.user_metadata?.full_name) {
      setTempFullName(user.user_metadata.full_name);
    }
  }, [profile, user]);

  // 1. Initial Load Effects
  useEffect(() => {
    checkBackendHealth();

    const stored = localStorage.getItem("webnixo_sessions");
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as ChatSession[];
        if (parsed.length > 0) {
          setSessions(parsed);
          setActiveSessionId(parsed[0].id);
          setSelectedModel(parsed[0].selectedModel || "google/gemini-3.5-flash");
          setPromptType(parsed[0].promptType || "general");
          return;
        }
      } catch (err) {
        console.error("Failed to parse stored sessions:", err);
      }
    }
    createNewSession("Initial Discovery Conversation");
  }, []);

  // 2. Clear out or persist sessions when state changes
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem("webnixo_sessions", JSON.stringify(sessions));
    }
  }, [sessions]);

  // 3. Scroll to bottom of chat area whenever active stream or history updates
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [sessions, activeSessionId]);

  // Auto-resize search input or prompt inputs comfortably
  const adjustInputHeight = () => {
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
      inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 200)}px`;
    }
  };

  useEffect(() => {
    adjustInputHeight();
  }, [inputText]);

  const checkBackendHealth = async () => {
    setIsCheckingHealth(true);
    try {
      const res = await fetch("/api/health");
      const data = await res.json();
      if (data.status === "ok") {
        setBackendOperational(true);
      } else {
        setBackendOperational(false);
      }
    } catch (e) {
      setBackendOperational(false);
    } finally {
      setIsCheckingHealth(false);
    }
  };

  const fetchSupabaseStatus = async () => {
    try {
      const res = await fetch("/api/supabase-status");
      if (res.ok) {
        const data = await res.json();
        setDbStatus(data);
      }
    } catch (e) {
      console.error("Failed to fetch database connection status:", e);
    }
  };

  const fetchUserCredits = async () => {
    if (!currentUser?.email) return;
    try {
      const res = await fetch(`/api/credits?email=${encodeURIComponent(currentUser.email)}`);
      if (res.ok) {
        const data = await res.json();
        setCreditsState(data);
      }
    } catch (e) {
      console.error("Failed to fetch user credit tracking profile:", e);
    }
  };

  useEffect(() => {
    if (currentUser?.email) {
      fetchUserCredits();
      fetchSupabaseStatus();
    }
  }, [currentUser?.email]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) return;
    setProfileSaving(true);
    setProfileSaveSuccess(null);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ full_name: tempFullName })
        .eq("id", user.id);

      if (error) throw error;
      if (refreshProfile) {
        await refreshProfile();
      }
      setProfileSaveSuccess("Profile updated successfully!");
      setTimeout(() => setProfileSaveSuccess(null), 3500);
    } catch (err: any) {
      console.error("Error updating profile name:", err);
      alert(`Error updating profile: ${err.message || "Please try again."}`);
    } finally {
      setProfileSaving(false);
    }
  };

  const handleApplyUpgradeCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setUpgradeCouponError(null);
    setUpgradeCouponSuccess(null);
    const cleanCode = upgradeCoupon.trim().toUpperCase();
    if (!cleanCode) {
      setUpgradeCouponError("Please type a valid coupon code first.");
      return;
    }

    if (AFFILIATE_SYSTEM.validCoupons.includes(cleanCode)) {
      setUpgradeDiscount(AFFILIATE_SYSTEM.customerDiscount);
      setUpgradeCouponSuccess(`Success! Affiliate Referral Coupon '${cleanCode}' applied: Flat ₹${AFFILIATE_SYSTEM.customerDiscount} customer discount activated!`);
    } else {
      setUpgradeCouponError(`Invalid coupon code. Try one of our standard affiliate coupons, like 'LAUNCH50' or 'WEBNIXO50'.`);
    }
  };

  const handleUpgradePlan = async (planKey: string) => {
    if (!currentUser?.email) return;
    setIsProcessingUpgrade(true);
    try {
      // Look up Cashfree client script from global window context
      if (!(window as any).Cashfree) {
        throw new Error("Cashfree Checkout Gateway is still loading. Please wait a moment and click upgrade again.");
      }

      console.log(`[CASHFREE] Initializing checkout: planKey=${planKey} email=${currentUser.email}`);

      // Call server backend to generate an official checkout transaction order
      const orderRes = await fetch("/api/cashfree/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: currentUser.email,
          planKey: planKey,
          couponCode: upgradeCoupon
        })
      });

      if (!orderRes.ok) {
        const errorData = await orderRes.json().catch(() => ({}));
        throw new Error(errorData.error || "Failed to contact billing server to establish order transaction");
      }

      const orderData = await orderRes.json();
      if (!orderData.payment_session_id) {
        throw new Error("Missing gateway session credential (payment_session_id)");
      }

      // Initialize Cashfree
      const cashfree = (window as any).Cashfree({
        mode: "production"
      });

      console.log("[CASHFREE] Redirecting user directly to Cashfree secure payments environment");
      
      // Load payment details instantly
      cashfree.checkout({
        paymentSessionId: orderData.payment_session_id,
        redirectTarget: "_self"
      });

    } catch (err: any) {
      console.error("[CASHFREE] Upgrade transaction setup failed:", err);
      alert(`Checkout initialization failed: ${err.message || "Please check connection or try again."}`);
    } finally {
      setIsProcessingUpgrade(false);
    }
  };

  // VERIFY CASHFREE TRANSACTION ON PAGE REDIRECT RETURN
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const orderId = params.get("order_id");
    const planKey = params.get("plan_key");
    const email = params.get("email");

    if (orderId && planKey && email) {
      const verifyCheckoutPayment = async () => {
        setIsProcessingUpgrade(true);
        try {
          console.log(`[CASHFREE] Verifying return order: ${orderId} for plan: ${planKey}`);
          const res = await fetch("/api/cashfree/verify-payment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              orderId,
              email: decodeURIComponent(email),
              planKey
            })
          });

          if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.error || "Unable to reach billing verification server.");
          }

          const verifyData = await res.json();
          if (verifyData.success) {
            alert(`🎉 Congratulations! Your payment of ₹${PRICING_PLANS[planKey]?.price || ""} was successfully verified via Cashfree (Order #${orderId}).\nYour plan is now upgraded to ${planKey.toUpperCase()} tier! App limits refreshed.`);
            
            // Sync database profile
            if (refreshProfile) {
              await refreshProfile();
            }
            // Populate credits status instantly
            await fetchUserCredits();
            setShowAccountSettingsModal(true); // Open modal with active confirmation
          } else {
            alert(`⚠️ Payment verification notice: ${verifyData.message}`);
          }
        } catch (err: any) {
          console.error("[CASHFREE] Verification failed:", err);
          alert(`Could not verify payment: ${err.message || "Please contact our support team providing order id: " + orderId}`);
        } finally {
          setIsProcessingUpgrade(false);
          // Clean parameters out of URL Address bar smoothly
          const cleanUrl = window.location.pathname;
          window.history.replaceState({}, document.title, cleanUrl);
        }
      };

      verifyCheckoutPayment();
    }
  }, [currentUser?.email]);

  const loadSessionsFromDb = async (email: string) => {
    setDbLoading(true);
    try {
      const res = await fetch(`/api/sessions?email=${encodeURIComponent(email)}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          const mappedSessions = data.map((s: any) => ({
            id: s.id,
            title: s.title,
            messages: Array.isArray(s.messages) ? s.messages : JSON.parse(s.messages || "[]"),
            createdAt: s.created_at,
            promptType: s.prompt_type || "general",
            selectedModel: s.selected_model || "google/gemini-3.5-flash"
          }));
          setSessions(mappedSessions);
          setActiveSessionId(mappedSessions[0].id);
          setSelectedModel(mappedSessions[0].selectedModel || "google/gemini-3.5-flash");
          setPromptType(mappedSessions[0].promptType || "general");
        } else {
          // Fallback parsing local state if exist
          const stored = localStorage.getItem("webnixo_sessions");
          if (stored) {
            const parsed = JSON.parse(stored) as ChatSession[];
            if (parsed.length > 0) {
              setSessions(parsed);
              setActiveSessionId(parsed[0].id);
              for (const s of parsed) {
                await saveSessionToDb(s, email);
              }
              return;
            }
          }
          createNewSession("Initial Discovery Conversation");
        }
      }
    } catch (e) {
      console.error("Failed to load sessions from database:", e);
    } finally {
      setDbLoading(false);
    }
  };

  const saveSessionToDb = async (session: ChatSession, email: string) => {
    try {
      await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session, email })
      });
    } catch (e) {
      console.error("Failed to save session to database:", e);
    }
  };

  const deleteSessionFromDb = async (sessionId: string, email: string) => {
    try {
      await fetch(`/api/sessions/${sessionId}?email=${encodeURIComponent(email)}`, {
        method: "DELETE"
      });
    } catch (e) {
      console.error("Failed to delete session from database:", e);
    }
  };

  const clearAllSessionsFromDb = async (email: string) => {
    try {
      await fetch(`/api/sessions?email=${encodeURIComponent(email)}`, {
        method: "DELETE"
      });
    } catch (e) {
      console.error("Failed to clear sessions from database:", e);
    }
  };

  // Synchronize database upon user login
  useEffect(() => {
    if (currentUser?.email) {
      fetchSupabaseStatus();
      loadSessionsFromDb(currentUser.email);
    }
  }, [currentUser?.email]);

  const createNewSession = (customTitle?: string) => {
    const newId = `session-${Date.now()}`;
    const newSession: ChatSession = {
      id: newId,
      title: customTitle || `Chat Session ${sessions.length + 1}`,
      messages: [],
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      promptType: promptType,
      selectedModel: selectedModel
    };

    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newId);
    setInputText("");
    setIsMobileMenuOpen(false);

    if (currentUser?.email) {
      saveSessionToDb(newSession, currentUser.email);
    }

    // Focus keyboard
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  };

  const deleteSession = (e: React.MouseEvent, idToDelete: string) => {
    e.stopPropagation();
    const filtered = sessions.filter(s => s.id !== idToDelete);

    if (currentUser?.email) {
      deleteSessionFromDb(idToDelete, currentUser.email);
    }

    if (filtered.length === 0) {
      const fallbackId = `session-${Date.now()}`;
      const fallbackSession: ChatSession = {
        id: fallbackId,
        title: "Fresh Chat Space",
        messages: [],
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        promptType: "general",
        selectedModel: "google/gemini-3.5-flash"
      };
      setSessions([fallbackSession]);
      setActiveSessionId(fallbackId);
      if (currentUser?.email) {
        saveSessionToDb(fallbackSession, currentUser.email);
      }
    } else {
      setSessions(filtered);
      if (activeSessionId === idToDelete) {
        setActiveSessionId(filtered[0].id);
      }
    }
  };

  const startRenameSession = (e: React.MouseEvent, s: ChatSession) => {
    e.stopPropagation();
    setIsEditingSessionId(s.id);
    setEditTitleValue(s.title);
  };

  const saveSessionName = (id: string) => {
    if (!editTitleValue.trim()) return;
    setSessions(prev => prev.map(s => {
      if (s.id === id) {
        const updated = { ...s, title: editTitleValue.trim() };
        if (currentUser?.email) {
          saveSessionToDb(updated, currentUser.email);
        }
        return updated;
      }
      return s;
    }));
    setIsEditingSessionId(null);
  };

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0] || {
    id: "fallback",
    title: "WEBNIXO AI Space",
    messages: [] as Message[],
    createdAt: "",
    promptType: "general" as const,
    selectedModel: "gemini-2.5-flash"
  };

  const handleSendMessage = async (textToSend?: string) => {
    let text = (textToSend || inputText).trim();
    if (!text && attachedFiles.length > 0) {
      text = "Analyze the uploaded file(s) and provide an overview.";
    }

    if (!text || !activeSession) return;

    // Upfront client-side Credit & Plan constraints authorization
    if (creditsState) {
      const isAllowed = isModelAllowedOnPlan(selectedModel, creditsState.plan);
      if (!isAllowed) {
        alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === selectedModel)?.name || selectedModel}' requires upgrading beyond your ${creditsState.plan.toUpperCase()} tier!`);
        setShowAccountSettingsModal(true);
        return;
      }

      if (isSideBySideMode) {
        const isCompAllowed = isModelAllowedOnPlan(comparisonModel, creditsState.plan);
        if (!isCompAllowed) {
          alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === comparisonModel)?.name || comparisonModel}' requires upgrading beyond your ${creditsState.plan.toUpperCase()} tier!`);
          setShowAccountSettingsModal(true);
          return;
        }

        if (isThreeModelMode) {
          const isCompCAllowed = isModelAllowedOnPlan(comparisonModelC, creditsState.plan);
          if (!isCompCAllowed) {
            alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === comparisonModelC)?.name || comparisonModelC}' requires upgrading beyond your ${creditsState.plan.toUpperCase()} tier!`);
            setShowAccountSettingsModal(true);
            return;
          }
        }

        if (isFourModelMode) {
          const isCompDAllowed = isModelAllowedOnPlan(comparisonModelD, creditsState.plan);
          if (!isCompDAllowed) {
            alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === comparisonModelD)?.name || comparisonModelD}' requires upgrading beyond your ${creditsState.plan.toUpperCase()} tier!`);
            setShowAccountSettingsModal(true);
            return;
          }
        }

        const totalCost = getModelCreditCost(selectedModel) + 
          getModelCreditCost(comparisonModel) + 
          (isThreeModelMode ? getModelCreditCost(comparisonModelC) : 0) +
          (isFourModelMode ? getModelCreditCost(comparisonModelD) : 0);

        if (creditsState.creditsRemaining < totalCost) {
          alert(`Usage Limit Reached: Running comparison models costs ${totalCost} credits, but you only have ${creditsState.creditsRemaining} credits left in your balance. Please upgrade to unleash unlimited power!`);
          setShowAccountSettingsModal(true);
          return;
        }
      } else {
        const cost = getModelCreditCost(selectedModel);
        if (creditsState.creditsRemaining < cost) {
          alert(`Usage Limit Reached: This request costs ${cost} credits, but you only have ${creditsState.creditsRemaining} credits left in your ${creditsState.period || "daily"} balance. Please upgrade to unleash unlimited power!`);
          setShowAccountSettingsModal(true);
          return;
        }
      }
    }

    if (!textToSend) {
      setInputText("");
    }

    const filesToSend = attachedFiles.length > 0 ? [...attachedFiles] : [];
    setAttachedFiles([]);

    const userMessageId = `user-${Date.now()}`;
    const assistantMessageId = `webnixo-${Date.now()}`;

    const userMsg: Message = {
      id: userMessageId,
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      files: filesToSend.length > 0 ? filesToSend : undefined
    };

    const assistantMsg: Message = {
      id: assistantMessageId,
      role: "assistant",
      content: "",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isStreaming: true,
      isSideBySide: isSideBySideMode,
      modelA_id: selectedModel,
      modelA_content: "",
      modelA_isStreaming: true,
      modelB_id: isSideBySideMode ? comparisonModel : undefined,
      modelB_content: isSideBySideMode ? "" : undefined,
      modelB_isStreaming: isSideBySideMode ? true : undefined,
      modelC_id: (isSideBySideMode && isThreeModelMode) ? comparisonModelC : undefined,
      modelC_content: (isSideBySideMode && isThreeModelMode) ? "" : undefined,
      modelC_isStreaming: (isSideBySideMode && isThreeModelMode) ? true : undefined,
      modelD_id: (isSideBySideMode && isFourModelMode) ? comparisonModelD : undefined,
      modelD_content: (isSideBySideMode && isFourModelMode) ? "" : undefined,
      modelD_isStreaming: (isSideBySideMode && isFourModelMode) ? true : undefined
    };

    if (activeSession.messages.length === 0) {
      fetch("/api/title", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      })
      .then(res => res.json())
      .then(data => {
        if (data.title) {
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return { ...s, title: data.title };
            }
            return s;
          }));
        }
      })
      .catch(err => console.error("Error setting custom topic title:", err));
    }

    const updatedMessages = [...activeSession.messages, userMsg, assistantMsg];

    setSessions(prev => prev.map(s => {
      if (s.id === activeSession.id) {
        return {
          ...s,
          messages: updatedMessages,
          selectedModel,
          promptType
        };
      }
      return s;
    }));

    if (!isSideBySideMode) {
      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            message: text,
            history: activeSession.messages,
            model: selectedModel,
            promptType: promptType,
            files: filesToSend.length > 0 ? filesToSend : undefined,
            email: currentUser?.email || ""
          })
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || `HTTP ${response.status} Connection issues`);
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder("utf-8");
        if (!reader) {
          throw new Error("Unable to retrieve readable message stream from host.");
        }

        let completeAnswer = "";
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            const cleanedLine = line.trim();
            if (!cleanedLine) continue;

            if (cleanedLine.startsWith("data: ")) {
              const jsonStr = cleanedLine.slice(6).trim();
              if (jsonStr === "[DONE]") {
                break;
              }

              let streamError = null;
              try {
                const data = JSON.parse(jsonStr);
                if (data.text) {
                  completeAnswer += data.text;
                  setSessions(prev => prev.map(s => {
                    if (s.id === activeSession.id) {
                      return {
                        ...s,
                        messages: s.messages.map(m => {
                          if (m.id === assistantMessageId) {
                            return { ...m, content: completeAnswer };
                          }
                          return m;
                        })
                      };
                    }
                    return s;
                  }));
                } else if (data.error) {
                  streamError = data.error;
                }
              } catch (err) {
                // Fail silently
              }

              if (streamError) {
                throw new Error(streamError);
              }
            }
          }
        }

        setSessions(prev => prev.map(s => {
          if (s.id === activeSession.id) {
            return {
              ...s,
              messages: s.messages.map(m => {
                if (m.id === assistantMessageId) {
                  return { ...m, content: completeAnswer, isStreaming: false };
                }
                return m;
              })
            };
          }
          return s;
        }));

        const guaranteedSessionState: ChatSession = {
          ...activeSession,
          messages: [
            ...activeSession.messages,
            userMsg,
            {
              id: assistantMessageId,
              role: "assistant",
              content: completeAnswer,
              timestamp: assistantMsg.timestamp,
              isStreaming: false
            }
          ],
          selectedModel,
          promptType
        };

        if (currentUser?.email) {
          saveSessionToDb(guaranteedSessionState, currentUser.email);
        }
        
        // Refresh user's remaining credits on the UI
        fetchUserCredits();

      } catch (e: any) {
        console.error(e);
        const errorContent = e.message?.includes("API key") 
          ? "⚠️ **API Key is missing or invalid.**\n\nTo operate WEBNIXO AI, please open the settings menu (Secrets panel) and configure your **GEMINI_API_KEY**. Once defined, the secure backend will process your inputs seamlessly."
          : `⚠️ **Session Connection Interrupted**:\n\n${e.message || "An unexpected network error occurred while streaming results. Please review host status."}`;

        setSessions(prev => prev.map(s => {
          if (s.id === activeSession.id) {
            return {
              ...s,
              messages: s.messages.map(m => {
                if (m.id === assistantMessageId) {
                  return { 
                    ...m, 
                    content: errorContent,
                    isStreaming: false,
                    error: true
                  };
                }
                return m;
              })
            };
          }
          return s;
        }));

        const guaranteedFailedSessionState: ChatSession = {
          ...activeSession,
          messages: [
            ...activeSession.messages,
            userMsg,
            {
              id: assistantMessageId,
              role: "assistant",
              content: errorContent,
              timestamp: assistantMsg.timestamp,
              isStreaming: false,
              error: true
            }
          ],
          selectedModel,
          promptType
        };

        if (currentUser?.email) {
          saveSessionToDb(guaranteedFailedSessionState, currentUser.email);
        }

        // Refresh credits balance even on failed operations
        fetchUserCredits();
      }
    } else {
      // Parallel Split Screen Execution Route
      let finalContentA = "";
      let finalContentB = "";
      let finalContentC = "";
      let finalContentD = "";
      let errorMsgA = "";
      let errorMsgB = "";
      let errorMsgC = "";
      let errorMsgD = "";

      const finalizeSideBySide = (
        contentA: string, 
        contentB: string, 
        contentC?: string, 
        contentD?: string,
        errA?: string, 
        errB?: string,
        errC?: string,
        errD?: string
      ) => {
        const guaranteedSessionState: ChatSession = {
          ...activeSession,
          messages: [
            ...activeSession.messages,
            userMsg,
            {
              id: assistantMessageId,
              role: "assistant",
              content: contentA || contentB || contentC || contentD || "",
              timestamp: assistantMsg.timestamp,
              isStreaming: false,
              isSideBySide: true,
              modelA_id: selectedModel,
              modelA_content: contentA,
              modelA_isStreaming: false,
              modelA_error: errA,
              modelB_id: comparisonModel,
              modelB_content: contentB,
              modelB_isStreaming: false,
              modelB_error: errB,
              modelC_id: isThreeModelMode ? comparisonModelC : undefined,
              modelC_content: isThreeModelMode ? contentC : undefined,
              modelC_isStreaming: false,
              modelC_error: errC,
              modelD_id: isFourModelMode ? comparisonModelD : undefined,
              modelD_content: isFourModelMode ? contentD : undefined,
              modelD_isStreaming: false,
              modelD_error: errD
            }
          ],
          selectedModel,
          promptType
        };

        if (currentUser?.email) {
          saveSessionToDb(guaranteedSessionState, currentUser.email);
        }
        fetchUserCredits();
      };

      const runA = async () => {
        try {
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: text,
              history: activeSession.messages,
              model: selectedModel,
              promptType: promptType,
              files: filesToSend.length > 0 ? filesToSend : undefined,
              email: currentUser?.email || ""
            })
          });

          if (!response.ok) {
            const errJson = await response.json().catch(() => ({}));
            throw new Error(errJson.error || `HTTP ${response.status}`);
          }

          const reader = response.body?.getReader();
          const decoder = new TextDecoder("utf-8");
          if (!reader) throw new Error("Connection limits reached on Model A");

          let buffer = "";
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";

            for (const line of lines) {
              const cleanedLine = line.trim();
              if (cleanedLine.startsWith("data: ")) {
                const jsonStr = cleanedLine.slice(6).trim();
                if (jsonStr === "[DONE]") break;

                let streamError = null;
                try {
                  const data = JSON.parse(jsonStr);
                  if (data.text) {
                    finalContentA += data.text;
                    setSessions(prev => prev.map(s => {
                      if (s.id === activeSession.id) {
                        return {
                          ...s,
                          messages: s.messages.map(m => {
                            if (m.id === assistantMessageId) {
                              return { ...m, modelA_content: finalContentA };
                            }
                            return m;
                          })
                        };
                      }
                      return s;
                    }));
                  } else if (data.error) {
                    streamError = data.error;
                  }
                } catch (e) {}
                if (streamError) {
                  throw new Error(streamError);
                }
              }
            }
          }
        } catch (err: any) {
          console.error("Model A failed", err);
          errorMsgA = err.message || "Model failed to stream";
          finalContentA = `⚠️ **Model Error:** ${errorMsgA}`;
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelA_content: finalContentA, modelA_error: errorMsgA };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        } finally {
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelA_isStreaming: false };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        }
      };

      const runB = async () => {
        try {
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: text,
              history: activeSession.messages,
              model: comparisonModel,
              promptType: promptType,
              files: filesToSend.length > 0 ? filesToSend : undefined,
              email: currentUser?.email || ""
            })
          });

          if (!response.ok) {
            const errJson = await response.json().catch(() => ({}));
            throw new Error(errJson.error || `HTTP ${response.status}`);
          }

          const reader = response.body?.getReader();
          const decoder = new TextDecoder("utf-8");
          if (!reader) throw new Error("Connection limits reached on Model B");

          let buffer = "";
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";

            for (const line of lines) {
              const cleanedLine = line.trim();
              if (cleanedLine.startsWith("data: ")) {
                const jsonStr = cleanedLine.slice(6).trim();
                if (jsonStr === "[DONE]") break;

                let streamError = null;
                try {
                  const data = JSON.parse(jsonStr);
                  if (data.text) {
                    finalContentB += data.text;
                    setSessions(prev => prev.map(s => {
                      if (s.id === activeSession.id) {
                        return {
                          ...s,
                          messages: s.messages.map(m => {
                            if (m.id === assistantMessageId) {
                              return { ...m, modelB_content: finalContentB };
                            }
                            return m;
                          })
                        };
                      }
                      return s;
                    }));
                  } else if (data.error) {
                    streamError = data.error;
                  }
                } catch (e) {}
                if (streamError) {
                  throw new Error(streamError);
                }
              }
            }
          }
        } catch (err: any) {
          console.error("Model B failed", err);
          errorMsgB = err.message || "Model failed to stream";
          finalContentB = `⚠️ **Model Error:** ${errorMsgB}`;
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelB_content: finalContentB, modelB_error: errorMsgB };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        } finally {
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelB_isStreaming: false };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        }
      };

      const runC = async () => {
        if (!isThreeModelMode) return;
        try {
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: text,
              history: activeSession.messages,
              model: comparisonModelC,
              promptType: promptType,
              files: filesToSend.length > 0 ? filesToSend : undefined,
              email: currentUser?.email || ""
            })
          });

          if (!response.ok) {
            const errJson = await response.json().catch(() => ({}));
            throw new Error(errJson.error || `HTTP ${response.status}`);
          }

          const reader = response.body?.getReader();
          const decoder = new TextDecoder("utf-8");
          if (!reader) throw new Error("Connection limits reached on Model C");

          let buffer = "";
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";

            for (const line of lines) {
              const cleanedLine = line.trim();
              if (cleanedLine.startsWith("data: ")) {
                const jsonStr = cleanedLine.slice(6).trim();
                if (jsonStr === "[DONE]") break;

                let streamError = null;
                try {
                  const data = JSON.parse(jsonStr);
                  if (data.text) {
                    finalContentC += data.text;
                    setSessions(prev => prev.map(s => {
                      if (s.id === activeSession.id) {
                        return {
                          ...s,
                          messages: s.messages.map(m => {
                            if (m.id === assistantMessageId) {
                              return { ...m, modelC_content: finalContentC };
                            }
                            return m;
                          })
                        };
                      }
                      return s;
                    }));
                  } else if (data.error) {
                    streamError = data.error;
                  }
                } catch (e) {}
                if (streamError) {
                  throw new Error(streamError);
                }
              }
            }
          }
        } catch (err: any) {
          console.error("Model C failed", err);
          errorMsgC = err.message || "Model failed to stream";
          finalContentC = `⚠️ **Model Error:** ${errorMsgC}`;
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelC_content: finalContentC, modelC_error: errorMsgC };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        } finally {
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelC_isStreaming: false };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        }
      };

      const runD = async () => {
        if (!isFourModelMode) return;
        try {
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: text,
              history: activeSession.messages,
              model: comparisonModelD,
              promptType: promptType,
              files: filesToSend.length > 0 ? filesToSend : undefined,
              email: currentUser?.email || ""
            })
          });

          if (!response.ok) {
            const errJson = await response.json().catch(() => ({}));
            throw new Error(errJson.error || `HTTP ${response.status}`);
          }

          const reader = response.body?.getReader();
          const decoder = new TextDecoder("utf-8");
          if (!reader) throw new Error("Connection limits reached on Model D");

          let buffer = "";
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";

            for (const line of lines) {
              const cleanedLine = line.trim();
              if (cleanedLine.startsWith("data: ")) {
                const jsonStr = cleanedLine.slice(6).trim();
                if (jsonStr === "[DONE]") break;

                let streamError = null;
                try {
                  const data = JSON.parse(jsonStr);
                  if (data.text) {
                    finalContentD += data.text;
                    setSessions(prev => prev.map(s => {
                      if (s.id === activeSession.id) {
                        return {
                          ...s,
                          messages: s.messages.map(m => {
                            if (m.id === assistantMessageId) {
                              return { ...m, modelD_content: finalContentD };
                            }
                            return m;
                          })
                        };
                      }
                      return s;
                    }));
                  } else if (data.error) {
                    streamError = data.error;
                  }
                } catch (e) {}
                if (streamError) {
                  throw new Error(streamError);
                }
              }
            }
          }
        } catch (err: any) {
          console.error("Model D failed", err);
          errorMsgD = err.message || "Model failed to stream";
          finalContentD = `⚠️ **Model Error:** ${errorMsgD}`;
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelD_content: finalContentD, modelD_error: errorMsgD };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        } finally {
          setSessions(prev => prev.map(s => {
            if (s.id === activeSession.id) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === assistantMessageId) {
                    return { ...m, modelD_isStreaming: false };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        }
      };

      const tasks = [runA(), runB()];
      if (isThreeModelMode) {
        tasks.push(runC());
      }
      if (isFourModelMode) {
        tasks.push(runD());
      }

      Promise.all(tasks).then(() => {
        setSessions(prev => prev.map(s => {
          if (s.id === activeSession.id) {
            return {
              ...s,
              messages: s.messages.map(m => {
                if (m.id === assistantMessageId) {
                  return { ...m, isStreaming: false };
                }
                return m;
              })
            };
          }
          return s;
        }));
        finalizeSideBySide(
          finalContentA, 
          finalContentB, 
          isThreeModelMode ? finalContentC : undefined, 
          isFourModelMode ? finalContentD : undefined,
          errorMsgA || undefined, 
          errorMsgB || undefined,
          isThreeModelMode ? errorMsgC || undefined : undefined,
          isFourModelMode ? errorMsgD || undefined : undefined
        );
      });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearAllSessions = () => {
    if (window.confirm("Are you absolutely sure you want to delete all historical logs and open a fresh conversation canvas?")) {
      localStorage.removeItem("webnixo_sessions");
      if (currentUser?.email) {
        clearAllSessionsFromDb(currentUser.email);
      }

      const freshId = `session-${Date.now()}`;
      const freshSession = {
        id: freshId,
        title: "Dynamic Portal Workspace",
        messages: [],
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        promptType: "general" as const,
        selectedModel: "google/gemini-3.5-flash"
      };

      setSessions([freshSession]);
      setActiveSessionId(freshId);

      if (currentUser?.email) {
        saveSessionToDb(freshSession, currentUser.email);
      }
    }
  };

  const handleLogoutClick = async () => {
    if (window.confirm("Are you sure you want to log out of your session?")) {
      await signOut();
    }
  };

  const filteredSessions = sessions.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.messages.some(m => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="flex h-screen w-full bg-[#050508] text-[#ececec] font-sans overflow-hidden relative">
      
      {/* Decorative premium ambient cyber highlights inside dashboard */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(99,102,241,0.015)_0,transparent_60%)] pointer-events-none z-0" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_80%,rgba(16,185,129,0.012)_0,transparent_60%)] pointer-events-none z-0" />
      
      {/* SIDEBAR FOR DESKTOP */}
      <aside 
        id="desktop-sidebar"
        className={`bg-[#171717] flex-shrink-0 flex flex-col border-r border-zinc-800 transition-all duration-300 ease-in-out relative z-30 ${
          isSidebarOpen ? "w-[260px] translate-x-0" : "w-0 -translate-x-full overflow-hidden border-r-0"
        } hidden md:flex`}
      >
        <div className="p-3.5 flex flex-col gap-2.5">
          <div className="flex items-center justify-between pb-1">
            <div className="flex items-center gap-2.5">
              <div 
                className="w-6 h-6 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[1px] shrink-0" 
                style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
              >
                <div 
                  className="w-full h-full bg-[#171717] flex items-center justify-center"
                  style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                >
                  <img 
                    src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                    alt="Webnixo AI Logo" 
                    className="w-4 h-4 object-contain" 
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
              <span className="font-sans font-semibold text-lg text-white tracking-tight">WEBNIXO AI</span>
              <span className="text-[9px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.2 rounded-full">v4.0</span>
            </div>
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="p-1 px-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-md transition-colors cursor-pointer"
              title="Close sidebar"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
          </div>

          {/* Workspace Switcher */}
          <div className="grid grid-cols-2 gap-1 bg-[#121212] p-1 rounded-xl border border-zinc-800/80">
            <button
              onClick={() => setActiveWorkspace("chat")}
              className={`flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeWorkspace === "chat" 
                  ? "bg-zinc-800 text-white shadow" 
                  : "text-zinc-500 hover:text-zinc-400 hover:bg-zinc-900/40"
              }`}
            >
              <MessageSquare className="h-3.5 w-3.5" />
              <span>AI Chat</span>
            </button>
            <button
              onClick={() => setActiveWorkspace("image")}
              className={`flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeWorkspace === "image" 
                  ? "bg-zinc-800 text-white shadow" 
                  : "text-zinc-500 hover:text-zinc-400 hover:bg-zinc-900/40"
              }`}
            >
              <ImageIcon className="h-3.5 w-3.5" />
              <span>Pixel Forge</span>
            </button>
          </div>

          {activeWorkspace === "chat" && (
            <button 
              id="btn-desktop-new-chat"
              onClick={() => createNewSession()}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg border border-zinc-800/80 hover:border-zinc-700 bg-zinc-900/40 hover:bg-[#212121] transition-all group shadow-sm text-left cursor-pointer"
            >
              <div className="w-5 h-5 rounded-md border border-zinc-700 flex items-center justify-center bg-zinc-800 group-hover:scale-105 transition-transform">
                <Plus className="h-3 w-3 text-white" />
              </div>
              <span className="text-sm font-medium text-zinc-250 font-sans">New chat</span>
            </button>
          )}
        </div>

        {/* Search */}
        <div className="px-3.5 mb-2 relative">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-zinc-500" />
          <input 
            type="text" 
            placeholder="Search discussions..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-zinc-900/60 hover:bg-zinc-900 border border-zinc-800/80 focus:border-zinc-700 rounded-md text-xs placeholder-zinc-500 text-zinc-200 outline-none transition-colors"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery("")}
              className="absolute right-6 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white text-xs cursor-pointer"
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </div>

        {/* Past Dialogs */}
        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1.5">
          <div className="px-2 text-[11px] font-semibold text-zinc-500 uppercase tracking-widest mb-1.5">
            <span>Conversations ({filteredSessions.length})</span>
          </div>

          {filteredSessions.length === 0 ? (
            <p className="text-xs text-zinc-600 px-3 py-4 italic text-center">No discussions match query</p>
          ) : (
            filteredSessions.map((s) => {
              const isActive = s.id === activeSessionId;
              const isEditing = s.id === isEditingSessionId;

              return (
                <div 
                  key={s.id}
                  onClick={() => {
                    setActiveSessionId(s.id);
                    setSelectedModel(s.selectedModel || "google/gemini-3.5-flash");
                    setPromptType(s.promptType || "general");
                  }}
                  className={`flex items-center justify-between px-3 py-2 text-sm rounded-lg cursor-pointer transition-all group ${
                    isActive 
                      ? "bg-[#212121] text-white border border-zinc-800/80 font-medium" 
                      : "text-zinc-400 hover:bg-zinc-900/50 hover:text-white"
                  }`}
                >
                  <div className="flex items-center gap-2.5 overflow-hidden flex-1">
                    <MessageSquare className={`h-3.5 w-3.5 flex-shrink-0 ${isActive ? 'text-zinc-200' : 'text-zinc-550'}`} />
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editTitleValue}
                        onChange={(e) => setEditTitleValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") saveSessionName(s.id);
                          if (e.key === "Escape") setIsEditingSessionId(null);
                        }}
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                        className="bg-zinc-850 text-white rounded px-1.5 py-0.5 text-xs outline-none border border-zinc-655 w-full"
                      />
                    ) : (
                      <span className="truncate text-xs font-sans tracking-wide">{s.title}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 ml-1 md:opacity-0 md:group-hover:opacity-100 opacity-100 transition-opacity">
                    {isEditing ? (
                      <button 
                        onClick={(e) => { e.stopPropagation(); saveSessionName(s.id); }}
                        className="text-emerald-400 hover:text-white cursor-pointer"
                      >
                        <Check className="h-3 w-3" />
                      </button>
                    ) : (
                      <>
                        <button 
                          onClick={(e) => startRenameSession(e, s)}
                          className="text-zinc-500 hover:text-white p-0.5 rounded cursor-pointer"
                          title="Rename conversation"
                        >
                          <Edit2 className="h-3 w-3" />
                        </button>
                        <button 
                          onClick={(e) => deleteSession(e, s.id)}
                          className="text-zinc-500 hover:text-red-400 p-0.5 rounded cursor-pointer"
                          title="Delete conversation"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Foot */}
        <div className="p-3 border-t border-zinc-800 bg-[#121212]">
          <div className="flex flex-col gap-2">
            
            <div className="flex items-center justify-between text-xs px-2.5 py-1.5 rounded bg-zinc-900 border border-zinc-800/60">
              <span className="text-zinc-500 font-medium">API System</span>
              {backendOperational === true ? (
                <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-400">
                  <CheckCircle className="h-3 w-3" /> Online
                </span>
              ) : backendOperational === false ? (
                <span className="flex items-center gap-1 text-[11px] font-medium text-amber-500">
                  <AlertCircle className="h-3 w-3" /> Setup Key
                </span>
              ) : (
                <button onClick={checkBackendHealth} className="text-zinc-400 hover:text-white cursor-pointer">
                  <RefreshCw className="h-3 w-3 animate-spin" />
                </button>
              )}
            </div>

            <div className="flex items-center justify-between text-xs px-2.5 py-1.5 rounded bg-zinc-900 border border-zinc-800/60">
              <span className="text-zinc-500 font-medium">Database</span>
              {dbStatus?.connected && dbStatus?.hasTables ? (
                <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400" title="Supabase Online">
                  <Database className="h-3 w-3" /> Synced
                </span>
              ) : dbStatus?.connected && !dbStatus?.hasTables ? (
                <button 
                  onClick={() => setShowDbInstallModal(true)} 
                  className="flex items-center gap-1.5 text-[11px] font-bold text-amber-400 hover:text-white hover:underline animate-pulse bg-amber-400/5 px-2 py-0.5 rounded border border-amber-400/20 cursor-pointer"
                >
                  <Database className="h-3 w-3" /> Fix Tables
                </button>
              ) : (
                <span className="flex items-center gap-1 text-[11px] font-bold text-red-500">
                  <AlertCircle className="h-3 w-3" /> Offline
                </span>
              )}
            </div>

            {creditsState && (
              <div 
                id="sidebar-credit-meter"
                onClick={() => {
                  if (profile?.full_name) {
                    setTempFullName(profile.full_name);
                  }
                  setShowAccountSettingsModal(true);
                }}
                className="flex flex-col gap-1.5 p-2 px-2.5 rounded-lg bg-zinc-950 border border-zinc-900 hover:border-indigo-500/20 hover:bg-zinc-950/80 transition-all cursor-pointer group text-left"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-zinc-500 font-medium group-hover:text-zinc-300 transition-colors">AI Usage Credits</span>
                  <span className="font-mono font-bold text-indigo-400 group-hover:text-indigo-300 transition-colors">
                    {creditsState.creditsRemaining} / {creditsState.totalCredits}
                  </span>
                </div>
                <div className="w-full bg-zinc-900 rounded-full h-1 overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${creditsState.isBelowTenPercent ? 'bg-amber-500' : 'bg-indigo-500'}`}
                    style={{ width: `${Math.min(100, Math.max(0, (creditsState.creditsRemaining / creditsState.totalCredits) * 100))}%` }}
                  />
                </div>
              </div>
            )}

            <button 
              onClick={() => {
                if (profile?.full_name) {
                  setTempFullName(profile.full_name);
                }
                setShowAccountSettingsModal(true);
              }}
              className="flex items-center gap-2 px-2.5 py-1.5 text-xs text-zinc-400 hover:text-emerald-400 transition-colors rounded-md hover:bg-zinc-850 border border-transparent hover:border-zinc-800/80 text-left cursor-pointer"
            >
              <Settings className="h-3.5 w-3.5 text-zinc-500" />
              <span className="flex-1">Account & Plan</span>
              <span className="text-[9px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded font-mono uppercase tracking-wider font-bold">
                {profile?.plan || "free"}
              </span>
            </button>



            <button 
              id="btn-desktop-clear-chats"
              onClick={handleClearAllSessions}
              className="flex items-center gap-2 px-2.5 py-1.5 text-xs text-zinc-500 hover:text-red-400 transition-colors rounded-md hover:bg-red-500/5 hover:border hover:border-red-500/10 text-left cursor-pointer"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Clear chat histories</span>
            </button>

            {/* Profile Sign-out footer wrapper */}
            <div className="flex items-center justify-between gap-2 px-2 py-1.5 mt-1 border-t border-zinc-800/80 pt-2.5">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center text-xs font-bold text-white uppercase shadow-sm flex-shrink-0 select-none">
                  {currentUser?.name ? currentUser.name.substring(0, 2) : "W"}
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-zinc-200 block truncate">{currentUser?.name || "WEBNIXO User"}</span>
                  <span className="text-[10px] text-zinc-500 block truncate">{currentUser?.email || "architect@webnixo.ai"}</span>
                </div>
              </div>
              <button 
                onClick={handleLogoutClick}
                className="p-1 px-1.5 text-zinc-500 hover:text-red-400 hover:bg-red-500/5 rounded transition-all flex-shrink-0 cursor-pointer"
                title="Sign out of panel"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>

          </div>
        </div>
      </aside>

      {/* MOBILE DRAWER */}
      {isMobileMenuOpen && (
        <div id="mobile-sidebar-modal" className="fixed inset-0 bg-black/60 z-50 md:hidden flex">
          <div className="w-[280px] bg-[#171717] h-full flex flex-col border-r border-zinc-800 p-4">
            <div className="flex items-center justify-between pb-4">
              <div className="flex items-center gap-2.5">
                <div 
                  className="w-6 h-6 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[1px] shrink-0" 
                  style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                >
                  <div 
                    className="w-full h-full bg-[#171717] flex items-center justify-center"
                    style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                      alt="Webnixo AI Logo" 
                      className="w-4 h-4 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
                <span className="font-sans font-semibold text-base text-white">WEBNIXO AI</span>
              </div>
              <button 
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-1 px-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-md transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-1 bg-[#121212] p-1 rounded-xl border border-zinc-800/80 mb-4">
              <button
                onClick={() => {
                  setActiveWorkspace("chat");
                  setIsMobileMenuOpen(false);
                }}
                className={`flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeWorkspace === "chat" 
                    ? "bg-zinc-800 text-white shadow" 
                    : "text-zinc-500 hover:text-zinc-450"
                }`}
              >
                <MessageSquare className="h-3.5 w-3.5" />
                <span>AI Chat</span>
              </button>
              <button
                onClick={() => {
                  setActiveWorkspace("image");
                  setIsMobileMenuOpen(false);
                }}
                className={`flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeWorkspace === "image" 
                    ? "bg-zinc-800 text-white shadow" 
                    : "text-zinc-500 hover:text-zinc-450"
                }`}
              >
                <ImageIcon className="h-3.5 w-3.5" />
                <span>Pixel Forge</span>
              </button>
            </div>

            {activeWorkspace === "chat" ? (
              <>
                <button 
                  id="btn-mobile-new-chat"
                  onClick={() => {
                    createNewSession();
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg border border-zinc-800 hover:bg-[#212121] transition-all text-left mb-4 cursor-pointer"
                >
                  <Plus className="h-4 w-4 text-white" />
                  <span className="text-sm font-medium">New Chat Space</span>
                </button>

                <div className="flex-1 overflow-y-auto space-y-1">
                  <div className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider mb-2">History</div>
                  {sessions.map(s => (
                    <div 
                      key={s.id}
                      onClick={() => {
                        setActiveSessionId(s.id);
                        setSelectedModel(s.selectedModel || "google/gemini-3.5-flash");
                        setPromptType(s.promptType || "general");
                        setIsMobileMenuOpen(false);
                      }}
                      className={`flex items-center justify-between px-3 py-2 text-xs rounded-lg cursor-pointer ${
                        s.id === activeSessionId ? "bg-[#212121] text-white" : "text-zinc-400 hover:bg-zinc-900"
                      }`}
                    >
                      <span className="truncate max-w-[210px]">{s.title}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col justify-center items-center text-center p-4 space-y-2 border border-zinc-800/45 rounded-2xl bg-zinc-900/10">
                <ImageIcon className="h-7 w-7 text-emerald-400 animate-pulse" />
                <h5 className="text-xs font-semibold text-white font-mono">Pixel Forge Active</h5>
                <p className="text-[10px] text-zinc-500 leading-relaxed">
                  Available in main dashboard view. Select preset formats and generate details.
                </p>
              </div>
            )}

            <div className="pt-4 border-t border-zinc-800 space-y-3">
              {creditsState && (
                <div 
                  id="mobile-credit-meter"
                  className="flex flex-col gap-1 p-2 px-2.5 rounded-lg bg-zinc-950 border border-zinc-900 group text-left"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-zinc-500 font-medium font-mono">Usage Credits</span>
                    <span className="font-mono font-bold text-indigo-400">
                      {creditsState.creditsRemaining} / {creditsState.totalCredits}
                    </span>
                  </div>
                  <div className="w-full bg-zinc-900 rounded-full h-1 overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${creditsState.isBelowTenPercent ? 'bg-amber-500' : 'bg-indigo-500'}`}
                      style={{ width: `${Math.min(100, Math.max(0, (creditsState.creditsRemaining / creditsState.totalCredits) * 100))}%` }}
                    />
                  </div>
                </div>
              )}

              <button 
                onClick={() => {
                  if (profile?.full_name) {
                    setTempFullName(profile.full_name);
                  }
                  setShowAccountSettingsModal(true);
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center gap-2 py-1.5 text-xs text-zinc-400 hover:text-emerald-400 w-full cursor-pointer text-left"
              >
                <Settings className="h-3.5 w-3.5 text-zinc-500" />
                <span className="flex-1">Account & Plan</span>
                <span className="text-[9px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded font-mono uppercase tracking-wider font-bold">
                  {profile?.plan || "free"}
                </span>
              </button>



              <button 
                id="btn-mobile-clear-chats"
                onClick={() => { handleClearAllSessions(); setIsMobileMenuOpen(false); }}
                className="flex items-center gap-2 py-1.5 text-xs text-zinc-500 hover:text-red-400 w-full cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Delete historical entries</span>
              </button>
              <div className="flex items-center justify-between gap-2 border-t border-zinc-800 pt-2.5">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 flex items-center justify-center text-[10px] font-bold text-white uppercase shadow-sm flex-shrink-0">
                    {currentUser?.name ? currentUser.name.substring(0, 2) : "W"}
                  </div>
                  <span className="text-xs text-zinc-300 truncate max-w-[140px]">{currentUser?.name || "WEBNIXO User"}</span>
                </div>
                <button 
                  onClick={handleLogoutClick}
                  className="p-1 text-zinc-500 hover:text-red-400 cursor-pointer"
                  title="Logout"
                >
                  <LogOut className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)}></div>
        </div>
      )}

      {/* FLOATING ACTION TO RESTORE SIDEBAR */}
      {!isSidebarOpen && (
        <button 
          id="btn-restore-sidebar"
          onClick={() => setIsSidebarOpen(true)}
          className="fixed left-3 top-3.5 z-40 bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 p-2 rounded-lg text-zinc-400 hover:text-white shadow-lg transition-transform hover:scale-105 hidden md:flex items-center justify-center cursor-pointer"
          title="Open sidebar"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      )}

      {/* CORE FRAME LAYOUT */}
      <main className="flex-1 flex flex-col relative bg-[#050508] overflow-hidden">
        
        {/* Subtle grid accent inside the main panel */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.007)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.007)_1px,transparent_1px)] bg-[size:2rem_2rem] pointer-events-none z-0" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(139,92,246,0.02)_0,transparent_50%)] pointer-events-none z-0" />
        
        {activeWorkspace === "image" ? (
          <>
            <header className="h-14 flex items-center justify-between px-4 border-b border-zinc-900 bg-[#0d0d0d]/90 backdrop-blur-md z-20 md:hidden animate-fade-in">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setIsMobileMenuOpen(true)}
                  className="p-1 px-1.5 text-zinc-400 hover:text-white rounded hover:bg-zinc-900 md:hidden flex items-center cursor-pointer"
                >
                  <Menu className="h-5 w-5" />
                </button>
                <div className="flex items-center gap-1.5">
                  <span className="font-sans font-semibold text-xs text-white tracking-widest uppercase">Pixel Forge</span>
                  <span className="text-[9px] bg-indigo-500/10 text-indigo-400 font-bold border border-indigo-500/20 px-1.5 py-0.2 rounded-full uppercase">Active</span>
                </div>
              </div>
            </header>
            <ImageStudio userEmail={currentUser?.email} />
          </>
        ) : (
          <>
            {/* Top Toolbar Header */}
            <header className="h-14 flex items-center justify-between px-4 border-b border-zinc-900 bg-[#0d0d0d]/90 backdrop-blur-md z-20">
              <div className="flex items-center gap-3">
                <button 
                  id="btn-mobile-sidebar-toggle"
                  onClick={() => setIsMobileMenuOpen(true)}
                  className="p-1 px-1.5 text-zinc-400 hover:text-white rounded hover:bg-zinc-900 md:hidden flex items-center cursor-pointer"
                >
                  <Menu className="h-5 w-5" />
                </button>

                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    {MODEL_OPTIONS.find(m => m.id === selectedModel)?.logo && (
                      <img 
                        src={MODEL_OPTIONS.find(m => m.id === selectedModel)?.logo} 
                        alt="" 
                        className="w-4.5 h-4.5 rounded-md object-contain border border-zinc-700 bg-white p-0.5 animate-fade-in select-none"
                        referrerPolicy="no-referrer"
                      />
                    )}
                    <div className="relative">
                      <select 
                        value={selectedModel}
                        onChange={(e) => {
                          const val = e.target.value;
                          const isAllowed = isModelAllowedOnPlan(val, creditsState?.plan || "free");
                          if (!isAllowed) {
                            alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === val)?.name || val}' requires upgrading!`);
                            setShowAccountSettingsModal(true);
                            return;
                          }
                          
                          setSelectedModel(val);
                          setSessions(prev => prev.map(s => {
                            if (s.id === activeSessionId) {
                              return { ...s, selectedModel: val };
                            }
                            return s;
                          }));
                        }}
                        className="bg-[#171717] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold rounded-xl pl-3 pr-7 py-1.5 border border-zinc-800 outline-none appearance-none cursor-pointer hover:border-zinc-700 hover:text-white transition-all shadow-sm focus:ring-1 focus:ring-indigo-500/30 max-w-[110px] sm:max-w-xs truncate font-medium"
                      >
                        {MODEL_GROUPS.map((group) => (
                          <optgroup key={group.label} label={group.label} className="bg-[#141414] text-zinc-400 font-sans font-bold text-[10px] uppercase tracking-wider not-italic py-2 border-b border-zinc-800">
                            {group.models.map((id) => {
                              const m = MODEL_OPTIONS.find(x => x.id === id);
                              if (!m) return null;
                              const isAllowed = isModelAllowedOnPlan(m.id, creditsState?.plan || "free");
                              const suffix = isAllowed ? "" : " 🔒";
                              return (
                                <option key={m.id} value={m.id} className="bg-[#141414] text-zinc-200 py-1 font-sans font-medium text-xs normal-case">
                                  {m.name}{suffix}
                                </option>
                              );
                            })}
                          </optgroup>
                        ))}
                      </select>
                      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2 text-zinc-500">
                        <ChevronDown className="h-3 w-3" />
                      </div>
                    </div>
                  </div>

                  {/* Toggle Side-by-Side compare Button */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button
                      onClick={() => {
                        const nextVal = !isSideBySideMode;
                        setIsSideBySideMode(nextVal);
                        if (!nextVal) {
                          setIsThreeModelMode(false);
                          setIsFourModelMode(false);
                        }
                      }}
                      className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold border transition-all cursor-pointer ${
                        isSideBySideMode 
                          ? "bg-indigo-600/20 border-indigo-500/30 text-indigo-400 hover:bg-indigo-600/30" 
                          : "bg-[#171717] border-zinc-800 text-zinc-400 hover:bg-zinc-850 hover:text-white"
                      }`}
                      title="Compare multiple models in parallel grids"
                    >
                      <Columns className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Compare</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsSideBySideMode(true);
                        setIsThreeModelMode(true);
                        setIsFourModelMode(true);
                        setSelectedModel("google/gemini-3.5-flash");
                        setComparisonModel("openai/gpt-4o");
                        setComparisonModelC("anthropic/claude-3-5-sonnet");
                        setComparisonModelD("deepseek/deepseek-chat");
                        setSessions(prev => prev.map(s => {
                          if (s.id === activeSessionId) {
                            return { ...s, selectedModel: "google/gemini-3.5-flash" };
                          }
                          return s;
                        }));
                      }}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold border transition-all cursor-pointer bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-purple-500/10 border-indigo-500/25 text-indigo-300 hover:border-indigo-500/40 hover:text-white"
                      title="Compare Gemini 3.5, GPT-4o, Claude 3.5, and DeepSeek side-by-side"
                    >
                      <GitCompare className="h-3.5 w-3.5 text-amber-400 animate-pulse" />
                      <span>Compare All Top Models</span>
                    </button>

                    {isSideBySideMode && (
                      <div className="flex items-center bg-zinc-950/80 border border-zinc-850 p-0.5 rounded-lg text-[10px] select-none">
                        <button
                          onClick={() => {
                            setIsThreeModelMode(false);
                            setIsFourModelMode(false);
                          }}
                          className={`px-2 py-1 rounded transition-all font-bold ${
                            !isThreeModelMode && !isFourModelMode 
                              ? "bg-zinc-800 text-white" 
                              : "text-zinc-500 hover:text-zinc-300"
                          }`}
                        >
                          2 Models
                        </button>
                        <button
                          onClick={() => {
                            setIsThreeModelMode(true);
                            setIsFourModelMode(false);
                          }}
                          className={`px-2 py-1 rounded transition-all font-bold ${
                            isThreeModelMode && !isFourModelMode 
                              ? "bg-zinc-800 text-white" 
                              : "text-zinc-500 hover:text-zinc-300"
                          }`}
                        >
                          3 Models
                        </button>
                        <button
                          onClick={() => {
                            setIsThreeModelMode(true);
                            setIsFourModelMode(true);
                          }}
                          className={`px-2 py-1 rounded transition-all font-bold ${
                            isThreeModelMode && isFourModelMode 
                              ? "bg-zinc-800 text-white" 
                              : "text-zinc-500 hover:text-zinc-300"
                          }`}
                        >
                          4 Models
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Second Selector for Side-by-Side Mode */}
                  {isSideBySideMode && (
                    <div className="flex items-center gap-1 animate-fade-in">
                      <span className="text-[10px] text-zinc-500 font-bold font-sans">VS</span>
                      {MODEL_OPTIONS.find(m => m.id === comparisonModel)?.logo && (
                        <img 
                          src={MODEL_OPTIONS.find(m => m.id === comparisonModel)?.logo} 
                          alt="" 
                          className="w-4.5 h-4.5 rounded-md object-contain border border-zinc-700 bg-white p-0.5 animate-fade-in select-none"
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <div className="relative">
                        <select 
                          value={comparisonModel}
                          onChange={(e) => {
                            const val = e.target.value;
                            const isAllowed = isModelAllowedOnPlan(val, creditsState?.plan || "free");
                            if (!isAllowed) {
                              alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === val)?.name || val}' requires upgrading!`);
                              setShowAccountSettingsModal(true);
                              return;
                            }
                            setComparisonModel(val);
                          }}
                          className="bg-[#171717] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold rounded-xl pl-3 pr-7 py-1.5 border border-zinc-800 outline-none appearance-none cursor-pointer hover:border-zinc-700 hover:text-white transition-all shadow-sm focus:ring-1 focus:ring-indigo-500/30 max-w-[110px] sm:max-w-xs truncate font-medium animate-fade-in"
                        >
                          {MODEL_GROUPS.map((group) => (
                            <optgroup key={group.label} label={group.label} className="bg-[#141414] text-zinc-400 font-sans font-bold text-[10px] uppercase tracking-wider not-italic py-2 border-b border-zinc-800">
                              {group.models.map((id) => {
                                const m = MODEL_OPTIONS.find(x => x.id === id);
                                if (!m) return null;
                                const isAllowed = isModelAllowedOnPlan(m.id, creditsState?.plan || "free");
                                const suffix = isAllowed ? "" : " 🔒";
                                return (
                                  <option key={m.id} value={m.id} className="bg-[#141414] text-zinc-200 py-1 font-sans font-medium text-xs normal-case">
                                    {m.name}{suffix}
                                  </option>
                                );
                              })}
                            </optgroup>
                          ))}
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2 text-zinc-500">
                          <ChevronDown className="h-3 w-3" />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Third Selector for Side-by-Side Mode */}
                  {isSideBySideMode && isThreeModelMode && (
                    <div className="flex items-center gap-1 animate-fade-in">
                      <span className="text-[10px] text-zinc-500 font-bold font-sans">and</span>
                      {MODEL_OPTIONS.find(m => m.id === comparisonModelC)?.logo && (
                        <img 
                          src={MODEL_OPTIONS.find(m => m.id === comparisonModelC)?.logo} 
                          alt="" 
                          className="w-4.5 h-4.5 rounded-md object-contain border border-zinc-700 bg-white p-0.5 animate-fade-in select-none"
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <div className="relative">
                        <select 
                          value={comparisonModelC}
                          onChange={(e) => {
                            const val = e.target.value;
                            const isAllowed = isModelAllowedOnPlan(val, creditsState?.plan || "free");
                            if (!isAllowed) {
                              alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === val)?.name || val}' requires upgrading!`);
                              setShowAccountSettingsModal(true);
                              return;
                            }
                            setComparisonModelC(val);
                          }}
                          className="bg-[#171717] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold rounded-xl pl-3 pr-7 py-1.5 border border-zinc-800 outline-none appearance-none cursor-pointer hover:border-zinc-700 hover:text-white transition-all shadow-sm focus:ring-1 focus:ring-indigo-500/30 max-w-[110px] sm:max-w-xs truncate font-medium animate-fade-in"
                        >
                          {MODEL_GROUPS.map((group) => (
                            <optgroup key={group.label} label={group.label} className="bg-[#141414] text-zinc-400 font-sans font-bold text-[10px] uppercase tracking-wider not-italic py-2 border-b border-zinc-800">
                              {group.models.map((id) => {
                                const m = MODEL_OPTIONS.find(x => x.id === id);
                                if (!m) return null;
                                const isAllowed = isModelAllowedOnPlan(m.id, creditsState?.plan || "free");
                                const suffix = isAllowed ? "" : " 🔒";
                                return (
                                  <option key={m.id} value={m.id} className="bg-[#141414] text-zinc-200 py-1 font-sans font-medium text-xs normal-case">
                                    {m.name}{suffix}
                                  </option>
                                );
                              })}
                            </optgroup>
                          ))}
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2 text-zinc-500">
                          <ChevronDown className="h-3 w-3" />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Fourth Selector for Side-by-Side Mode */}
                  {isSideBySideMode && isThreeModelMode && isFourModelMode && (
                    <div className="flex items-center gap-1 animate-fade-in">
                      <span className="text-[10px] text-zinc-500 font-bold font-sans">and</span>
                      {MODEL_OPTIONS.find(m => m.id === comparisonModelD)?.logo && (
                        <img 
                          src={MODEL_OPTIONS.find(m => m.id === comparisonModelD)?.logo} 
                          alt="" 
                          className="w-4.5 h-4.5 rounded-md object-contain border border-zinc-700 bg-white p-0.5 animate-fade-in select-none"
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <div className="relative">
                        <select 
                          value={comparisonModelD}
                          onChange={(e) => {
                            const val = e.target.value;
                            const isAllowed = isModelAllowedOnPlan(val, creditsState?.plan || "free");
                            if (!isAllowed) {
                              alert(`Model Locked: Access to '${MODEL_OPTIONS.find(m => m.id === val)?.name || val}' requires upgrading!`);
                              setShowAccountSettingsModal(true);
                              return;
                            }
                            setComparisonModelD(val);
                          }}
                          className="bg-[#171717] hover:bg-zinc-800 text-zinc-200 text-xs font-semibold rounded-xl pl-3 pr-7 py-1.5 border border-zinc-800 outline-none appearance-none cursor-pointer hover:border-zinc-700 hover:text-white transition-all shadow-sm focus:ring-1 focus:ring-indigo-500/30 max-w-[110px] sm:max-w-xs truncate font-medium animate-fade-in"
                        >
                          {MODEL_GROUPS.map((group) => (
                            <optgroup key={group.label} label={group.label} className="bg-[#141414] text-zinc-400 font-sans font-bold text-[10px] uppercase tracking-wider not-italic py-2 border-b border-zinc-800">
                              {group.models.map((id) => {
                                const m = MODEL_OPTIONS.find(x => x.id === id);
                                if (!m) return null;
                                const isAllowed = isModelAllowedOnPlan(m.id, creditsState?.plan || "free");
                                const suffix = isAllowed ? "" : " 🔒";
                                return (
                                  <option key={m.id} value={m.id} className="bg-[#141414] text-zinc-200 py-1 font-sans font-medium text-xs normal-case">
                                    {m.name}{suffix}
                                  </option>
                                );
                              })}
                            </optgroup>
                          ))}
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2 text-zinc-500">
                          <ChevronDown className="h-3 w-3" />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                {creditsState && (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900/60 border border-zinc-800 rounded-full text-[11px] font-mono select-none text-zinc-300">
                    <Zap className="h-3 w-3 text-indigo-400 fill-indigo-400/30 animate-pulse" />
                    <span>Credits: <strong className="text-white font-bold">{creditsState.creditsRemaining}</strong> / {creditsState.totalCredits}</span>
                  </div>
                )}

                {/* Upgrade Button */}
                <button
                  onClick={() => {
                    if (profile?.full_name) {
                      setTempFullName(profile.full_name);
                    }
                    setShowAccountSettingsModal(true);
                  }}
                  className="flex items-center gap-1 bg-gradient-to-r from-emerald-500 to-teal-500 text-zinc-950 font-bold text-xs px-3 py-1.5 rounded-full hover:opacity-90 active:scale-95 transition-all text-left cursor-pointer"
                >
                  <Sparkles className="h-3 w-3" />
                  Upgrade
                </button>
              </div>
            </header>

            <div className="px-4 py-2 bg-zinc-950 border-b border-zinc-900 flex justify-between items-center text-xs text-zinc-400">
              <div className="flex items-center gap-2.5">
                {MODEL_OPTIONS.find(m => m.id === selectedModel)?.logo && (
                  <img 
                    src={MODEL_OPTIONS.find(m => m.id === selectedModel)?.logo} 
                    alt="" 
                    className="w-5.5 h-5.5 rounded-md object-contain border border-zinc-200 bg-white p-0.5 select-none"
                    referrerPolicy="no-referrer"
                  />
                )}
                <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2">
                  <span className="font-semibold text-zinc-200">{MODEL_OPTIONS.find(m => m.id === selectedModel)?.name}</span>
                  <span className="text-[10px] text-zinc-500 hidden sm:inline">• Active Server Proxy</span>
                </div>
              </div>
              <span className="hidden md:inline text-[10px] text-zinc-500 max-w-xl truncate text-right font-sans">{MODEL_OPTIONS.find(m => m.id === selectedModel)?.description}</span>
            </div>

            {creditsState && creditsState.isBelowTenPercent && (
              <div id="credits-under-limit-warning" className="bg-amber-950/20 border-b border-amber-500/25 px-4 py-2 flex items-center justify-between text-xs text-amber-400 gap-3 animate-fade-in z-10 font-sans">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-amber-400 shrink-0" />
                  <span>
                    <strong>Balance Warning:</strong> You have consumed over 90% of your plan credit allocation. Remaining: <strong className="font-mono">{creditsState.creditsRemaining} / {creditsState.totalCredits}</strong>. Please upgrade to prevent service interruption.
                  </span>
                </div>
                <button 
                  onClick={() => setShowAccountSettingsModal(true)} 
                  className="px-2.5 py-1 bg-amber-500/15 hover:bg-amber-500/30 text-amber-300 rounded border border-amber-400/20 hover:border-amber-400/40 font-bold transition-all shrink-0 cursor-pointer text-[10px] uppercase font-mono"
                >
                  Upgrade Now
                </button>
              </div>
            )}

            {/* CHAT MESSAGES BODY */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden min-h-0 relative">
              
              {activeSession.messages.length === 0 ? (
                
                /* WELCOME TEMPLATES GRID */
                <div className="h-full flex flex-col items-center justify-center py-10 px-4 max-w-[760px] mx-auto">
                  
                  <div className="mb-4 flex flex-col items-center text-center animate-fade-in space-y-4">
                    <div 
                      className="w-16 h-16 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[1.5px] shrink-0 shadow-[0_0_30px_rgba(139,92,246,0.25)]" 
                      style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                    >
                      <div 
                        className="w-full h-full bg-[#050508] flex items-center justify-center"
                        style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                      >
                        <Sparkles className="h-6 w-6 text-indigo-400 animate-pulse" />
                      </div>
                    </div>
                    <h1 className="text-2xl md:text-3xl font-semibold text-white tracking-tight font-sans">
                      Start a Conversation
                    </h1>
                    <p className="text-zinc-400 text-xs mt-3 max-w-sm font-sans leading-relaxed">
                      Type your query or prompt in the input below to query the secure Webnixo AI multi-agent cloud models.
                    </p>
                  </div>


                </div>

              ) : (

                /* DIALOG WRAPPERS */
                <div className="w-full space-y-2 py-4">
                  {activeSession.messages.map((m) => {
                    const isUser = m.role === "user";
                    if (!isUser && m.isSideBySide) {
                      const logoA = MODEL_OPTIONS.find(x => x.id === m.modelA_id)?.logo;
                      const nameA = MODEL_OPTIONS.find(x => x.id === m.modelA_id)?.name || m.modelA_id;
                      
                      const logoB = MODEL_OPTIONS.find(x => x.id === m.modelB_id)?.logo;
                      const nameB = MODEL_OPTIONS.find(x => x.id === m.modelB_id)?.name || m.modelB_id;

                      const logoC = m.modelC_id ? MODEL_OPTIONS.find(x => x.id === m.modelC_id)?.logo : undefined;
                      const nameC = m.modelC_id ? (MODEL_OPTIONS.find(x => x.id === m.modelC_id)?.name || m.modelC_id) : "";

                      const logoD = m.modelD_id ? MODEL_OPTIONS.find(x => x.id === m.modelD_id)?.logo : undefined;
                      const nameD = m.modelD_id ? (MODEL_OPTIONS.find(x => x.id === m.modelD_id)?.name || m.modelD_id) : "";
                      
                      return (
                        <div key={m.id} className="w-full py-6 bg-[#171717]/30 border-y border-zinc-900/60 font-sans">
                          <div className="max-w-7xl mx-auto px-4">
                            
                            {/* Comparison Title Header */}
                            <div className="flex items-center justify-between text-zinc-500 text-xs mb-4">
                              <span className="font-semibold text-indigo-400 tracking-wider uppercase flex items-center gap-1.5 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20 text-[10px]">
                                <Columns className="h-3 w-3" /> {m.modelD_id ? "Multi-Model Parallel Comparison (Quadruple Grid)" : m.modelC_id ? "Multi-Model Parallel Comparison (Triple Grid)" : "Side-by-Side Model Comparison"}
                              </span>
                              <span>{m.timestamp}</span>
                            </div>
                            
                            {/* Dual / Triple / Quadruple Grid */}
                            <div className={`grid grid-cols-1 ${m.modelD_id ? "lg:grid-cols-4 md:grid-cols-2" : m.modelC_id ? "lg:grid-cols-3 md:grid-cols-3" : "md:grid-cols-2"} gap-4`}>
                              
                              {/* Model A Column Panel */}
                              <div className="bg-zinc-950/80 border border-zinc-900 rounded-2xl p-4.5 space-y-3 shadow-md flex flex-col justify-between min-h-[160px]">
                                <div className="space-y-3">
                                  <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                                    <div className="flex items-center gap-2">
                                      {logoA && (
                                        <img 
                                          src={logoA} 
                                          alt="" 
                                          className="w-4.5 h-4.5 object-contain rounded bg-white p-0.5" 
                                          referrerPolicy="no-referrer"
                                        />
                                      )}
                                      <span className="font-bold text-white text-xs">{nameA}</span>
                                    </div>
                                    {m.modelA_isStreaming && (
                                      <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                                        <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                                        Streaming A...
                                      </span>
                                    )}
                                  </div>
                                  
                                  <div className="prose prose-invert max-w-none text-zinc-250 text-xs leading-relaxed">
                                    {m.modelA_content ? (
                                      <MarkdownRenderer content={m.modelA_content} />
                                    ) : m.modelA_isStreaming ? (
                                      <div className="flex items-center gap-1.5 text-zinc-500">
                                        <span>Thinking</span>
                                        <span className="animate-pulse">...</span>
                                      </div>
                                    ) : (
                                      <span className="text-zinc-600 italic">Execution details not received.</span>
                                    )}
                                  </div>
                                </div>
                              </div>
                              
                              {/* Model B Column Panel */}
                              <div className="bg-zinc-950/80 border border-zinc-900 rounded-2xl p-4.5 space-y-3 shadow-md flex flex-col justify-between min-h-[160px]">
                                <div className="space-y-3">
                                  <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                                    <div className="flex items-center gap-2">
                                      {logoB && (
                                        <img 
                                          src={logoB} 
                                          alt="" 
                                          className="w-4.5 h-4.5 object-contain rounded bg-white p-0.5" 
                                          referrerPolicy="no-referrer"
                                        />
                                      )}
                                      <span className="font-bold text-white text-xs">{nameB}</span>
                                    </div>
                                    {m.modelB_isStreaming && (
                                      <span className="text-[10px] text-indigo-400 flex items-center gap-1 font-mono">
                                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping" />
                                        Streaming B...
                                      </span>
                                    )}
                                  </div>
                                  
                                  <div className="prose prose-invert max-w-none text-zinc-250 text-xs leading-relaxed">
                                    {m.modelB_content ? (
                                      <MarkdownRenderer content={m.modelB_content} />
                                    ) : m.modelB_isStreaming ? (
                                      <div className="flex items-center gap-1.5 text-zinc-500">
                                        <span>Thinking</span>
                                        <span className="animate-pulse">...</span>
                                      </div>
                                    ) : (
                                      <span className="text-zinc-600 italic">Execution details not received.</span>
                                    )}
                                  </div>
                                </div>
                              </div>

                              {/* Model C Column Panel */}
                              {m.modelC_id && (
                                <div className="bg-zinc-950/80 border border-zinc-900 rounded-2xl p-4.5 space-y-3 shadow-md flex flex-col justify-between min-h-[160px]">
                                  <div className="space-y-3">
                                    <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                                      <div className="flex items-center gap-2">
                                        {logoC && (
                                          <img 
                                            src={logoC} 
                                            alt="" 
                                            className="w-4.5 h-4.5 object-contain rounded bg-white p-0.5" 
                                            referrerPolicy="no-referrer"
                                          />
                                        )}
                                        <span className="font-bold text-white text-xs">{nameC}</span>
                                      </div>
                                      {m.modelC_isStreaming && (
                                        <span className="text-[10px] text-purple-400 flex items-center gap-1 font-mono">
                                          <span className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-ping" />
                                          Streaming C...
                                        </span>
                                      )}
                                    </div>
                                    
                                    <div className="prose prose-invert max-w-none text-zinc-250 text-xs leading-relaxed">
                                      {m.modelC_content ? (
                                        <MarkdownRenderer content={m.modelC_content} />
                                      ) : m.modelC_isStreaming ? (
                                        <div className="flex items-center gap-1.5 text-zinc-500">
                                          <span>Thinking</span>
                                          <span className="animate-pulse">...</span>
                                        </div>
                                      ) : (
                                        <span className="text-zinc-650 italic">Execution details not received.</span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              )}

                              {/* Model D Column Panel */}
                              {m.modelD_id && (
                                <div className="bg-zinc-950/80 border border-zinc-900 rounded-2xl p-4.5 space-y-3 shadow-md flex flex-col justify-between min-h-[160px]">
                                  <div className="space-y-3">
                                    <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                                      <div className="flex items-center gap-2">
                                        {logoD && (
                                          <img 
                                            src={logoD} 
                                            alt="" 
                                            className="w-4.5 h-4.5 object-contain rounded bg-white p-0.5" 
                                            referrerPolicy="no-referrer"
                                          />
                                        )}
                                        <span className="font-bold text-white text-xs">{nameD}</span>
                                      </div>
                                      {m.modelD_isStreaming && (
                                        <span className="text-[10px] text-teal-400 flex items-center gap-1 font-mono">
                                          <span className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-ping" />
                                          Streaming D...
                                        </span>
                                      )}
                                    </div>
                                    
                                    <div className="prose prose-invert max-w-none text-zinc-250 text-xs leading-relaxed">
                                      {m.modelD_content ? (
                                        <MarkdownRenderer content={m.modelD_content} />
                                      ) : m.modelD_isStreaming ? (
                                        <div className="flex items-center gap-1.5 text-zinc-500">
                                          <span>Thinking</span>
                                          <span className="animate-pulse">...</span>
                                        </div>
                                      ) : (
                                        <span className="text-zinc-650 italic">Execution details not received.</span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              )}
                              
                            </div>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div 
                        key={m.id}
                        className={`w-full py-5 ${
                          isUser ? "bg-transparent" : "bg-[#171717]/40 border-y border-zinc-900/50"
                        }`}
                      >
                        <div className="max-w-[760px] mx-auto px-4">
                          <div className={`space-y-1.5 overflow-hidden ${isUser ? 'text-right flex flex-col items-end' : 'text-left'}`}>
                            <div className={`flex items-center gap-2.5 text-xs text-zinc-550 ${isUser ? 'flex-row-reverse' : ''}`}>
                              <span className="font-semibold text-zinc-350">
                                {isUser ? "You" : "WEBNIXO AI"}
                              </span>
                              <span>•</span>
                              <span>{m.timestamp}</span>
                            </div>

                            <div className={`prose prose-invert max-w-none text-zinc-250 ${
                              isUser 
                                ? "bg-[#212121] border border-zinc-800 px-4.5 py-3 rounded-2xl rounded-tr-none text-left inline-block shadow-md max-w-[85%] md:max-w-[75%]" 
                                : ""
                            }`}>
                              {m.content ? (
                                <>
                                  <MarkdownRenderer content={m.content} />
                                  {m.files && m.files.length > 0 && (
                                    <div className="flex flex-wrap gap-2 mt-3.5 pt-2.5 border-t border-zinc-800/80">
                                      {m.files.map((file) => (
                                        <div 
                                          key={file.id} 
                                          className="flex items-center gap-2 bg-zinc-900/60 border border-zinc-850 rounded-xl p-1.5 px-2.5 text-xs text-zinc-300 max-w-xs truncate"
                                        >
                                          {file.isImage && file.base64 ? (
                                            <img 
                                              src={file.base64} 
                                              alt={file.name} 
                                              className="w-5 h-5 rounded object-cover border border-zinc-700/50" 
                                              referrerPolicy="no-referrer"
                                            />
                                          ) : (
                                            <Paperclip className="h-3.5 w-3.5 text-indigo-400" />
                                          )}
                                          <span className="truncate max-w-[150px] font-medium" title={file.name}>
                                            {file.name}
                                          </span>
                                          <span className="text-[10px] text-zinc-500 font-sans">
                                            ({(file.size / 1024).toFixed(1)} KB)
                                          </span>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </>
                              ) : (
                                <div className="flex items-center gap-2 text-zinc-550 py-2">
                                  <span className="text-xs italic">WEBNIXO AI is thinking</span>
                                  <div className="flex gap-1">
                                    <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                    <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                    <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce"></span>
                                  </div>
                                </div>
                              )}
                            </div>

                            {m.isStreaming && m.content && (
                              <div className="inline-block h-3.5 w-1.5 bg-emerald-400 ml-1 rounded animate-pulse"></div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  
                  <div ref={messageEndRef} className="h-32" />
                </div>

              )}

            </div>

            {/* MESSAGE PROMPT CONTROL TRAY */}
            <div className="p-4 pb-8 border-t border-zinc-900 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d] to-transparent z-10 animate-fade-in">
              <div className="max-w-[760px] mx-auto w-full flex flex-col items-center">
                
                <div className="w-full relative bg-[#171717] rounded-2xl border border-zinc-800 shadow-2xl p-2 focus-within:border-zinc-700 transition-colors">
                  
                  {attachedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2 p-2 pt-1 pb-2 border-b border-zinc-800/60 mb-2">
                      {attachedFiles.map((file) => (
                        <div 
                          key={file.id} 
                          className="flex items-center gap-2 bg-[#1f1f1f] border border-zinc-800 rounded-xl p-1.5 pl-2.5 pr-1.5 text-xs text-zinc-300"
                        >
                          {file.isImage && file.base64 ? (
                            <img 
                              src={file.base64} 
                              alt={file.name} 
                              className="w-5 h-5 rounded object-cover border border-zinc-700" 
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <Paperclip className="h-3.5 w-3.5 text-indigo-400" />
                          )}
                          <span className="truncate max-w-[120px] font-medium" title={file.name}>
                            {file.name}
                          </span>
                          <button 
                            onClick={() => removeAttachedFile(file.id)}
                            className="p-0.5 hover:bg-zinc-850 rounded-md text-zinc-500 hover:text-red-400 transition-colors cursor-pointer"
                            title="Remove file"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <textarea 
                    ref={inputRef}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={`Message WEBNIXO AI (${MODEL_OPTIONS.find(m => m.id === selectedModel)?.name || "AI"})...`}
                    className="w-full bg-transparent border-none text-zinc-100 text-sm placeholder-zinc-500 resize-none max-h-48 min-h-[36px] py-1.5 px-3 outline-none focus:ring-0 focus:border-transparent"
                    style={{ height: "auto" }}
                    disabled={activeSession.messages.some(m => m.isStreaming)}
                  />

                  <div className="flex items-center justify-between pt-2 px-2 mt-1 select-none">
                    
                    <div className="flex items-center gap-1.5">
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileChange} 
                        className="hidden" 
                        multiple 
                        id="chat-file-upload-input"
                      />
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="p-1.5 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                        title="Attach files (Text, Code, or Images)"
                      >
                        <Paperclip className="h-3.5 w-3.5" />
                      </button>
                      <button 
                        onClick={() => setInputText(prev => prev + " **bold** ")}
                        className="p-1 px-2 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white text-xs font-mono cursor-pointer"
                        title="Bold formatting"
                      >
                        B
                      </button>
                      <button 
                        onClick={() => setInputText(prev => prev + "\n```typescript\n\n```")}
                        className="p-1.5 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
                        title="Insert code block template"
                      >
                        <Terminal className="h-3.5 w-3.5" />
                      </button>
                      <button 
                        onClick={() => { setInputText(""); setAttachedFiles([]); }}
                        className="p-1.5 rounded hover:bg-zinc-800/60 text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer"
                        title="Clear prompt"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="hidden sm:inline text-[11px] text-zinc-650 font-medium whitespace-nowrap font-sans">
                        Press Enter to send
                      </span>
                      <button 
                        id="btn-send-message"
                        onClick={() => handleSendMessage()}
                        disabled={(!inputText.trim() && attachedFiles.length === 0) || activeSession.messages.some(m => m.isStreaming)}
                        className={`p-2 rounded-xl transition-all duration-200 ${
                          (inputText.trim() || attachedFiles.length > 0) && !activeSession.messages.some(m => m.isStreaming)
                            ? "bg-white text-black hover:scale-105 active:scale-95 shadow-md cursor-pointer" 
                            : "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                        }`}
                        title="Send message"
                      >
                        <Send className="h-3.5 w-3.5" />
                      </button>
                    </div>

                  </div>

                </div>

                <p className="text-[10px] text-zinc-650 text-center mt-3 tracking-wide">
                  WEBNIXO AI can make mistakes. Consider verifying highly sensitive guidelines, technical programs, or database schemas.
                </p>

              </div>
            </div>
          </>
        )}
      </main>

      {/* DATABASE DIAGNOSTIC MODAL */}
      <AnimatePresence>
        {showDbInstallModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 animate-fade-in" onClick={() => setShowDbInstallModal(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#121212] border border-zinc-800 rounded-2xl w-full max-w-2xl shadow-2xl relative z-10 flex flex-col max-h-[90vh] overflow-hidden"
            >
              <div className="p-5 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Database className="h-5 w-5 text-emerald-400" />
                  <div>
                    <h3 className="font-bold text-white text-base tracking-tight font-sans">Supabase Table Installation</h3>
                    <p className="text-[11px] text-zinc-500 mt-0.5">Automated connection established! Setup your remote database schema below.</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowDbInstallModal(false)}
                  className="p-1 px-2 rounded hover:bg-zinc-800 text-zinc-500 hover:text-white text-xs transition-colors cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="p-6 overflow-y-auto space-y-4">
                <div className="bg-emerald-500/5 border border-emerald-500/15 p-4 rounded-xl text-left text-xs text-zinc-300 leading-relaxed space-y-2 font-sans">
                  <p className="font-semibold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle className="h-4 w-4" /> Credentials are fully authenticated!
                  </p>
                  <p>
                    WEBNIXO AI has successfully connected to your Supabase instance. However, the custom database tables do not yet exist.
                  </p>
                  <p>
                    Please paste and execute the following SQL script inside your <strong>Supabase SQL Editor</strong> to complete the real-time syncing, full-stack schema, and RLS security setup:
                  </p>
                </div>

                <div className="space-y-1 text-left">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] text-zinc-400 uppercase tracking-widest font-mono font-bold">PostgreSQL Schema</label>
                    <button
                      onClick={() => {
                        const sqlText = `-- Create profiles table linked to auth.users
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT,
  avatar_url TEXT,
  plan TEXT DEFAULT 'free',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create conversations table
CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create messages table
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE,
  role TEXT CHECK (role IN ('user', 'assistant')) NOT NULL,
  content TEXT NOT NULL,
  model_used TEXT,
  tokens_used INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create user_usage table for tracking limits
CREATE TABLE IF NOT EXISTS public.user_usage (
  id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  prompts_used_today INTEGER DEFAULT 0,
  images_generated_today INTEGER DEFAULT 0,
  last_reset_date DATE DEFAULT CURRENT_DATE
);

-- Create subscriptions table
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  plan_name TEXT DEFAULT 'free',
  payment_status TEXT,
  start_date TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
  expiry_date TIMESTAMP WITH TIME ZONE
);

-- Create payments records table
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  payment_gateway TEXT,
  transaction_id TEXT,
  status TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create generated_content table
CREATE TABLE IF NOT EXISTS public.generated_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  content_type TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create uploaded_files table
CREATE TABLE IF NOT EXISTS public.uploaded_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable Row Level Security (RLS) on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generated_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.uploaded_files ENABLE ROW LEVEL SECURITY;

-- 1. Profiles Policies
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- 2. Conversations Policies
CREATE POLICY "Users can manage own conversations" ON public.conversations FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all conversations" ON public.conversations FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- 3. Messages Policies
CREATE POLICY "Users can manage own messages" ON public.messages FOR ALL USING (EXISTS (SELECT 1 FROM public.conversations WHERE conversations.id = messages.conversation_id AND conversations.user_id = auth.uid()));
CREATE POLICY "Admins can view all messages" ON public.messages FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- 4. User Usage Policies
CREATE POLICY "Users can manage own usage" ON public.user_usage FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Admins can view and edit usage" ON public.user_usage FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- 5. Subscriptions Policies
CREATE POLICY "Users can view own subscription" ON public.subscriptions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage subscriptions" ON public.subscriptions FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- 6. Payments Policies
CREATE POLICY "Users can view own payments" ON public.payments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage payments" ON public.payments FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- 7. Generated Content Policies
CREATE POLICY "Users can manage own dynamic content" ON public.generated_content FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage all dynamic content" ON public.generated_content FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- 8. Uploaded Files Policies
CREATE POLICY "Users can manage own uploaded files" ON public.uploaded_files FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage all files" ON public.uploaded_files FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND plan = 'admin'));

-- Define trigger for automatically establishing profile/limit entries
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, avatar_url, plan)
  VALUES (
    new.id,
    COALESCE(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''),
    new.email,
    COALESCE(new.raw_user_meta_data->>'avatar_url', ''),
    'free'
  );

  INSERT INTO public.user_usage (id, user_id, prompts_used_today, images_generated_today, last_reset_date)
  VALUES (
    new.id,
    new.id,
    0,
    0,
    CURRENT_DATE
  );
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();`;
                        navigator.clipboard.writeText(sqlText);
                        alert("Upgrade SQL creation script successfully copied to your clipboard!");
                      }}
                      className="px-2.5 py-1 rounded bg-zinc-800 text-zinc-305 hover:text-white text-[11px] font-medium transition-colors cursor-pointer"
                    >
                      Copy SQL Code
                    </button>
                  </div>
                  <pre className="bg-zinc-950 p-4 rounded-xl text-[11px] text-zinc-500 font-mono select-text border border-zinc-850 overflow-x-auto text-left leading-relaxed max-h-60">
{`-- SQL script to create Webnixo AI backend schema tables
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT,
  avatar_url TEXT,
  plan TEXT DEFAULT 'free',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Conversations and limits schema...
-- (Click 'Copy SQL Code' to copy the complete setup script and execute in Supabase)`}
                  </pre>
                </div>
              </div>

              <div className="p-4 border-t border-zinc-850 bg-[#141414] flex items-center justify-end gap-3 font-sans">
                <button
                  onClick={() => setShowDbInstallModal(false)}
                  className="px-4 py-2 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white text-xs font-semibold rounded-lg transition-all cursor-pointer"
                >
                  Configure Later
                </button>
                <button
                  onClick={async () => {
                    await fetchSupabaseStatus();
                    if (dbStatus?.connected && dbStatus?.hasTables) {
                      alert("🎉 Verification successful! Your Supabase database is now fully synced and operational.");
                      setShowDbInstallModal(false);
                      if (currentUser?.email) {
                        loadSessionsFromDb(currentUser.email);
                      }
                    } else {
                      alert("⚠️ Table structure not found yet. Please make sure to execute the SQL query block above inside your Supabase SQL editor and try again.");
                    }
                  }}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-450 text-black text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  <RefreshCw className="h-3.5 w-3.5 animate-spin-slow" />
                  Verify Table Structure
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {showAccountSettingsModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto font-sans">
            <div className="absolute inset-0" onClick={() => setShowAccountSettingsModal(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#121212] border border-zinc-800 rounded-2xl w-full max-w-xl shadow-2xl relative z-10 flex flex-col overflow-hidden text-left"
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <User className="h-5 w-5 text-indigo-400" />
                  <div>
                    <h3 className="font-bold text-white text-base tracking-tight font-sans">Account & Billing Settings</h3>
                    <p className="text-[11px] text-zinc-500 mt-0.5">Manage your profile details and upgrade plan allocations.</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowAccountSettingsModal(false)}
                  className="p-1 px-2 rounded hover:bg-zinc-800 text-zinc-500 hover:text-white text-xs transition-colors cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-6 overflow-y-auto max-h-[75vh]">
                
                {/* Section A: Profile Management */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                    <User className="h-3.5 w-3.5 text-indigo-400" /> User Profile Settings
                  </h4>
                  <form onSubmit={handleUpdateProfile} className="bg-zinc-950/40 border border-zinc-900 rounded-xl p-4 space-y-4">
                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-500 font-mono">ACCOUNT EMAIL (SENSITIVE)</label>
                      <input
                        type="text"
                        disabled
                        value={user?.email || "architect@webnixo.ai"}
                        className="w-full bg-zinc-900/50 border border-zinc-850/60 rounded-lg px-3 py-2 text-xs text-zinc-500 select-all cursor-not-allowed"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-400 font-mono font-bold">FULL NAME</label>
                      <input
                        type="text"
                        required
                        value={tempFullName}
                        onChange={(e) => setTempFullName(e.target.value)}
                        placeholder="e.g. Atharva Patil"
                        className="w-full bg-zinc-900 border border-zinc-805 border-zinc-800 focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-white outline-none transition-all"
                      />
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      {profileSaveSuccess ? (
                        <span className="text-emerald-400 text-xs font-semibold animate-fade-in">
                          ✓ {profileSaveSuccess}
                        </span>
                      ) : <span />}

                      <button
                        type="submit"
                        disabled={profileSaving}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer disabled:bg-zinc-800 disabled:text-zinc-500"
                      >
                        {profileSaving ? "Saving Name..." : "Save Profile"}
                      </button>
                    </div>
                  </form>
                </div>

                {/* Section B: Current Subscription Status */}
                <div className="space-y-3 border-t border-zinc-800/85 pt-5 font-sans">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                      <CreditCard className="h-3.5 w-3.5 text-indigo-400" /> Active Subscription Plan
                    </h4>
                    
                    <span className="text-[10px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider font-extrabold flex items-center gap-1">
                      <ShieldCheck className="h-3 w-3 text-indigo-400" /> {(creditsState?.plan || profile?.plan || "free").toUpperCase()} active
                    </span>
                  </div>

                  <div className="bg-zinc-950/40 border border-zinc-900 p-4 rounded-xl flex items-center justify-between gap-4">
                    <div className="flex-1">
                      <p className="text-xs font-extrabold text-white">
                        {(creditsState?.plan || profile?.plan) === "pro" 
                          ? "Developer Pro Member Pass" 
                          : (creditsState?.plan || profile?.plan) === "starter" 
                          ? "Starter Sandbox Membership" 
                          : "Free Tier Visitor"}
                      </p>
                      <p className="text-[11px] text-zinc-400 mt-1.5 leading-relaxed">
                        {(creditsState?.plan || profile?.plan) === "pro" 
                          ? "Unlimited elite API power. Access to Google Gemini Flash, DeepSeek, Mistral, Grok, Perplexity Search, GPT, and Claude. Allocation: 3,000 monthly credits." 
                          : (creditsState?.plan || profile?.plan) === "starter" 
                          ? "Refined intermediate access. Fully unlocks Gemini Flash, DeepSeek, and Mistral. Allocation: 1,000 monthly credits." 
                          : "Basic playground visitor pass. Unlocks Gemini Flash & DeepSeek Chat. Limits: 3 credits per day."}
                      </p>
                      {creditsState && (
                        <div className="mt-3 pt-2.5 border-t border-zinc-900 flex items-center justify-between text-[11px]">
                          <span className="text-zinc-500 font-medium">Credits balance:</span>
                          <span className="font-mono font-bold text-indigo-400">
                            {creditsState.creditsRemaining} / {creditsState.totalCredits} remaining ({creditsState.period})
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Section C: Upgrade Options with Promo Code */}
                <div className="space-y-4 border-t border-zinc-800/85 pt-5 font-sans">
                  <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">
                    Upgrade Your Account Plan
                  </h4>

                  {/* Promo Input frame */}
                  <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-900 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-zinc-400 font-bold uppercase font-mono">use coupon code(optional)</span>
                      <span className="text-[9px] text-zinc-500">Try coupon <code className="text-emerald-400 bg-zinc-900 px-1 py-0.5 rounded">LAUNCH50</code></span>
                    </div>

                    <form onSubmit={handleApplyUpgradeCoupon} className="flex gap-2">
                      <input
                        type="text"
                        placeholder="ENTER OPTIONAL COUPON CODE"
                        value={upgradeCoupon}
                        onChange={(e) => setUpgradeCoupon(e.target.value)}
                        className="flex-1 bg-zinc-900 border border-zinc-800 focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-white outline-none transition-all uppercase placeholder-zinc-700 font-mono"
                      />
                      <button
                        type="submit"
                        className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors cursor-pointer"
                      >
                        Apply Code
                      </button>
                    </form>

                    {upgradeCouponError && (
                      <p className="text-rose-400 text-[11px] animate-pulse">⚠️ {upgradeCouponError}</p>
                    )}
                    {upgradeCouponSuccess && (
                      <p className="text-emerald-400 text-[11px] font-medium">🎉 {upgradeCouponSuccess}</p>
                    )}
                  </div>

                  {/* Pricing grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Starter upgrade card */}
                    <div className="p-4 rounded-xl bg-[#141416]/40 border border-zinc-800 flex flex-col justify-between space-y-4">
                      <div>
                        <span className="text-[9px] text-indigo-400 font-bold tracking-widest block uppercase">Intermediate</span>
                        <h5 className="text-white font-bold text-sm mt-0.5">Starter Pass</h5>
                        
                        <ul className="text-[10px] text-zinc-400 mt-2 space-y-1 list-disc pl-3">
                          <li>1,000 monthly credits</li>
                          <li>Access: Gemini, DeepSeek, Mistral</li>
                          <li className="text-zinc-650">No GPT, Claude, Grok, Perplexity</li>
                        </ul>
                        
                        <div className="pt-3">
                          {upgradeDiscount > 0 ? (
                            <div>
                              <span className="text-xs text-zinc-500 line-through">₹199</span>
                              <div className="text-xl font-black text-emerald-400">
                                ₹{Math.max(0, 199 - upgradeDiscount)}
                                <span className="text-[10px] text-zinc-500 font-normal">/mo</span>
                              </div>
                            </div>
                          ) : (
                            <div className="text-xl font-black text-white">
                              ₹199
                              <span className="text-[10px] text-zinc-500 font-normal">/mo</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleUpgradePlan("starter")}
                        disabled={isProcessingUpgrade || (creditsState?.plan || profile?.plan) === "starter" || (creditsState?.plan || profile?.plan) === "pro" || (creditsState?.plan || profile?.plan) === "pro_yearly"}
                        className="w-full py-2 bg-zinc-850 hover:bg-zinc-805 disabled:bg-zinc-900 disabled:text-zinc-500 disabled:border-transparent text-white text-xs font-semibold rounded-lg transition-all transform active:scale-[0.98] cursor-pointer text-center"
                      >
                        {isProcessingUpgrade 
                          ? "Verifying..." 
                          : (creditsState?.plan || profile?.plan) === "starter" 
                          ? "Starter Member" 
                          : ((creditsState?.plan || profile?.plan) === "pro" || (creditsState?.plan || profile?.plan) === "pro_yearly")
                          ? "Active / Higher Tier"
                          : "Get Starter Plan"}
                      </button>
                    </div>

                    {/* Pro tier upgrade card */}
                    <div className="p-4 rounded-xl bg-[#17171e]/40 border border-indigo-500/20 flex flex-col justify-between space-y-4">
                      <div>
                        <span className="text-[9px] text-indigo-400 font-bold tracking-widest block uppercase">Elite Power</span>
                        <h5 className="text-white font-bold text-sm mt-0.5">Developer Pro</h5>
                        
                        <ul className="text-[10px] text-zinc-400 mt-2 space-y-1 list-disc pl-3">
                          <li>3,000 monthly credits</li>
                          <li>All models unlocked</li>
                          <li>Access: Gemini, DeepSeek, Mistral, Grok, Perplexity, GPT & Claude</li>
                        </ul>
                        
                        <div className="pt-3">
                          {upgradeDiscount > 0 ? (
                            <div>
                              <span className="text-xs text-zinc-500 line-through">₹499</span>
                              <div className="text-xl font-black text-emerald-400">
                                ₹{Math.max(0, 499 - upgradeDiscount)}
                                <span className="text-[10px] text-zinc-500 font-normal">/mo</span>
                              </div>
                            </div>
                          ) : (
                            <div className="text-xl font-black text-white">
                              ₹499
                              <span className="text-[10px] text-zinc-500 font-normal">/mo</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleUpgradePlan("pro")}
                        disabled={isProcessingUpgrade || (creditsState?.plan || profile?.plan) === "pro" || (creditsState?.plan || profile?.plan) === "pro_yearly"}
                        className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-zinc-900 disabled:text-zinc-500 disabled:border-transparent text-white text-xs font-semibold rounded-lg transition-all transform active:scale-[0.98] cursor-pointer text-center"
                      >
                        {isProcessingUpgrade 
                          ? "Verifying..." 
                          : (creditsState?.plan || profile?.plan) === "pro" 
                          ? "Pro Member" 
                          : (creditsState?.plan || profile?.plan) === "pro_yearly"
                          ? "Active / Higher Tier"
                          : "Get Pro Plan"}
                      </button>
                    </div>

                    {/* Pro Yearly tier upgrade card */}
                    <div className="p-4 rounded-xl bg-[#1b1724]/40 border border-violet-500/30 flex flex-col justify-between space-y-4 relative overflow-hidden">
                      <div className="absolute top-2 right-2 bg-violet-600/30 text-violet-300 text-[8px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider">
                        Best Value
                      </div>
                      <div>
                        <span className="text-[9px] text-violet-400 font-bold tracking-widest block uppercase">Annual Membership</span>
                        <h5 className="text-white font-bold text-sm mt-0.5 font-sans">Pro Yearly Pass</h5>
                        
                        <ul className="text-[10px] text-zinc-400 mt-2 space-y-1 list-disc pl-3">
                          <li>40,000 yearly credits</li>
                          <li>Savings of over 30%</li>
                          <li>Access: Gemini, DeepSeek, Mistral, Grok, Perplexity, GPT & Claude</li>
                        </ul>
                        
                        <div className="pt-3">
                          {upgradeDiscount > 0 ? (
                            <div>
                              <span className="text-xs text-zinc-500 line-through">₹3,999</span>
                              <div className="text-xl font-black text-emerald-400">
                                ₹{Math.max(0, 3999 - upgradeDiscount)}
                                <span className="text-[10px] text-zinc-500 font-normal">/yr</span>
                              </div>
                            </div>
                          ) : (
                            <div className="text-xl font-black text-white">
                              ₹3,999
                              <span className="text-[10px] text-zinc-500 font-normal">/yr</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleUpgradePlan("pro_yearly")}
                        disabled={isProcessingUpgrade || (creditsState?.plan || profile?.plan) === "pro_yearly"}
                        className="w-full py-2 bg-violet-600 hover:bg-violet-500 disabled:bg-zinc-900 disabled:text-zinc-500 disabled:border-transparent text-white text-xs font-semibold rounded-lg transition-all transform active:scale-[0.98] cursor-pointer text-center"
                      >
                        {isProcessingUpgrade 
                          ? "Verifying..." 
                          : (creditsState?.plan || profile?.plan) === "pro_yearly" 
                          ? "Pro Yearly Member" 
                          : "Get Yearly Plan"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}


      </AnimatePresence>
    </div>
  );
};
