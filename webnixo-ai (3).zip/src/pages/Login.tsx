import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { 
  Sparkles, 
  AlertCircle, 
  Loader2, 
  ArrowRight, 
  ArrowLeft, 
  Shield, 
  Users, 
  IndianRupee, 
  Link as LinkIcon, 
  DollarSign, 
  Percent,
  CreditCard,
  CheckCircle,
  FileText,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate } from "react-router-dom";

/**
 * Login Component
 * Renders a clean, aesthetic, and welcoming landing portal for signing in with WEBNIXO AI.
 */
export const Login: React.FC = () => {
  const { user, signOut, signInWithGoogle, error: authError } = useAuth();
  const [isRedirecting, setIsRedirecting] = useState<boolean>(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const navigate = useNavigate();

  // Affiliate simulation states
  const urlParams = new URLSearchParams(window.location.search);
  const isAffiliateMode = urlParams.get("role") === "affiliate" || urlParams.get("type") === "affiliate";
  
  const [affiliateCodeInput, setAffiliateCodeInput] = useState<string>("");
  const [isAffiliateLoggedIn, setIsAffiliateLoggedIn] = useState<boolean>(false);
  const [activeAffiliateCode, setActiveAffiliateCode] = useState<string>("PARTNER50");
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [requestedCashout, setRequestedCashout] = useState<boolean>(false);

  // Bank Info form details
  const [bankHolderName, setBankHolderName] = useState<string>(() => localStorage.getItem("bank_holder_name") || "");
  const [bankAccountNumber, setBankAccountNumber] = useState<string>(() => localStorage.getItem("bank_account_number") || "");
  const [bankIfscCode, setBankIfscCode] = useState<string>(() => localStorage.getItem("bank_ifsc_code") || "");
  const [bankUpiId, setBankUpiId] = useState<string>(() => localStorage.getItem("bank_upi_id") || "");
  const [isBankDetailsSaved, setIsBankDetailsSaved] = useState<boolean>(false);
  const [showTerms, setShowTerms] = useState<boolean>(false);

  // Live Payout custom amount & token tracking systems
  const [payoutAmount, setPayoutAmount] = useState<string>("");
  const [payoutError, setPayoutError] = useState<string | null>(null);
  const [payoutHistory, setPayoutHistory] = useState<Array<{
    token: string;
    amount: number;
    date: string;
    status: "Processing" | "Credited" | "Returned";
  }>>(() => {
    const historical = localStorage.getItem("payout_history");
    if (historical) {
      try {
        return JSON.parse(historical);
      } catch (e) {
        // Fallback default mock history
      }
    }
    return [
      { token: "TXN-WNX-72A91D", amount: 13000, date: "12 Jun 2026", status: "Credited" },
      { token: "TXN-WNX-31B45F", amount: 4800, date: "02 May 2026", status: "Credited" }
    ];
  });

  // Automatically sync to localstorage on update
  useEffect(() => {
    localStorage.setItem("payout_history", JSON.stringify(payoutHistory));
  }, [payoutHistory]);

  // Admin Portal state structures
  const adminEmails = ["spatil23012008@gmail.com", "shivanagouda.012@gmail.com", "ytshivu8@gmail.com"];
  const isAdminUser = user?.email ? adminEmails.includes(user.email.trim().toLowerCase()) : false;

  const [isAdminTabActive, setIsAdminTabActive] = useState<boolean>(false);
  const [adminPayoutRequests, setAdminPayoutRequests] = useState<any[]>([]);
  const [isLoadingAdminPayouts, setIsLoadingAdminPayouts] = useState<boolean>(false);
  
  // Update state details
  const [selectedPayoutViewToken, setSelectedPayoutViewToken] = useState<string | null>(null);
  const [statusUpdateVal, setStatusUpdateVal] = useState<"Processing" | "Credited" | "Returned">("Processing");
  const [txnIdUpdateVal, setTxnIdUpdateVal] = useState<string>("");
  const [notesUpdateVal, setNotesUpdateVal] = useState<string>("");

  // Plan Prices Admin states
  const [starterPriceVal, setStarterPriceVal] = useState<number>(199);
  const [starterLimitVal, setStarterLimitVal] = useState<number>(1000);
  const [proPriceVal, setProPriceVal] = useState<number>(499);
  const [proLimitVal, setProLimitVal] = useState<number>(3000);
  const [proYearlyPriceVal, setProYearlyPriceVal] = useState<number>(3999);
  const [proYearlyLimitVal, setProYearlyLimitVal] = useState<number>(40000);
  const [customerDiscountVal, setCustomerDiscountVal] = useState<number>(50);
  const [affiliateCommissionVal, setAffiliateCommissionVal] = useState<number>(50);
  const [validCouponsVal, setValidCouponsVal] = useState<string>("LAUNCH50, AFFILIATE50, WEBNIXO50, START50");

  const [isSavingPricingSettings, setIsSavingPricingSettings] = useState<boolean>(false);
  const [pricingSaveSuccess, setPricingSaveSuccess] = useState<boolean>(false);

  // Administrative functions
  const loadAdminPayouts = async () => {
    if (!user?.email) return;
    setIsLoadingAdminPayouts(true);
    try {
      const res = await fetch(`/api/admin/payouts?email=${encodeURIComponent(user.email)}`);
      if (res.ok) {
        const data = await res.json();
        setAdminPayoutRequests(data.payouts || []);
      }
    } catch (err) {
      console.error("[ADMIN] Failed loading payouts from API", err);
    } finally {
      setIsLoadingAdminPayouts(false);
    }
  };

  const loadAdminPricing = async () => {
    try {
      const res = await fetch("/api/pricing");
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setStarterPriceVal(data.plans.starter.price);
          setStarterLimitVal(data.plans.starter.limit);
          setProPriceVal(data.plans.pro.price);
          setProLimitVal(data.plans.pro.limit);
          setProYearlyPriceVal(data.plans.pro_yearly.price);
          setProYearlyLimitVal(data.plans.pro_yearly.limit);
          setCustomerDiscountVal(data.settings.customerDiscount);
          setAffiliateCommissionVal(data.settings.affiliateCommission);
          setValidCouponsVal(data.settings.validCoupons.join(", "));
        }
      }
    } catch (err) {
      console.error("[ADMIN] Failed to load config pricing parameters", err);
    }
  };

  const handleUpdatePayoutStatus = async (tokenOnCall: string) => {
    if (!user?.email) return;
    try {
      const res = await fetch("/api/admin/payouts/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: user.email,
          token: tokenOnCall,
          status: statusUpdateVal,
          transactionId: txnIdUpdateVal,
          notes: notesUpdateVal
        })
      });
      if (res.ok) {
        alert(`✓ Payout request status for "${tokenOnCall}" successfully updated to ${statusUpdateVal}!`);
        setSelectedPayoutViewToken(null);
        setTxnIdUpdateVal("");
        setNotesUpdateVal("");
        loadAdminPayouts();
      } else {
        const err = await res.json();
        alert(`Error updating status: ${err.error || "Request failed"}`);
      }
    } catch (err: any) {
      alert(`Failed to save payout status update: ${err.message}`);
    }
  };

  const saveAdminPricingSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.email) return;
    setIsSavingPricingSettings(true);
    setPricingSaveSuccess(false);
    try {
      const res = await fetch("/api/admin/pricing/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: user.email,
          starterPrice: Number(starterPriceVal),
          starterLimit: Number(starterLimitVal),
          proPrice: Number(proPriceVal),
          proLimit: Number(proLimitVal),
          proYearlyPrice: Number(proYearlyPriceVal),
          proYearlyLimit: Number(proYearlyLimitVal),
          customerDiscount: Number(customerDiscountVal),
          affiliateCommission: Number(affiliateCommissionVal),
          validCoupons: validCouponsVal
        })
      });
      if (res.ok) {
        setPricingSaveSuccess(true);
        setTimeout(() => setPricingSaveSuccess(false), 3000);
      } else {
        const err = await res.json();
        alert(`Failed to save settings: ${err.error || "No response"}`);
      }
    } catch (err: any) {
      alert(`Request exception: ${err.message}`);
    } finally {
      setIsSavingPricingSettings(false);
    }
  };

  // Sync state if user arrives already authenticated from Google in affiliate mode
  useEffect(() => {
    if (user && isAffiliateMode) {
      localStorage.setItem("login_as", "affiliate");
      setIsAffiliateLoggedIn(true);
      const emailPrefix = user.email ? user.email.split("@")[0].toUpperCase() : "PARTNER";
      setActiveAffiliateCode(emailPrefix + "50");
      
      // Auto pre-load admin details if they are admins on access
      const emailLower = user.email ? user.email.trim().toLowerCase() : "";
      if (adminEmails.includes(emailLower)) {
        loadAdminPayouts();
        loadAdminPricing();
      }
    }
  }, [user, isAffiliateMode]);

  const handleGoogleLogin = async () => {
    try {
      setIsRedirecting(true);
      setLocalError(null);
      if (isAffiliateMode) {
        localStorage.setItem("login_as", "affiliate");
      } else {
        localStorage.removeItem("login_as");
      }
      await signInWithGoogle();
    } catch (err: any) {
      console.error("Authentication error:", err);
      setLocalError(err.message || "Failed to authenticate. Please try again.");
      setIsRedirecting(false);
    }
  };

  const handleSaveBankDetails = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem("bank_holder_name", bankHolderName);
    localStorage.setItem("bank_account_number", bankAccountNumber);
    localStorage.setItem("bank_ifsc_code", bankIfscCode);
    localStorage.setItem("bank_upi_id", bankUpiId);
    setIsBankDetailsSaved(true);
    setTimeout(() => setIsBankDetailsSaved(false), 3000);
  };

  const handleAffiliateCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    const code = affiliateCodeInput.trim().toUpperCase();
    if (!code) {
      setLocalError("Please enter a valid partner affiliate code.");
      return;
    }
    setActiveAffiliateCode(code);
    setIsAffiliateLoggedIn(true);
  };

  const handleCopyLink = () => {
    const affiliateLink = `${window.location.origin}/?ref=${activeAffiliateCode}`;
    navigator.clipboard.writeText(affiliateLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const displayedError = localError || authError;

  return (
    <div className="min-h-screen w-full bg-[#050508] text-[#ececec] font-sans flex flex-col justify-between relative overflow-y-auto select-none">
      
      {/* Decorative premium dark grid background with color matrix accents */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(99,102,241,0.015)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.015)_1px,transparent_1px)] bg-[size:3.5rem_3.5rem] pointer-events-none z-0" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,#050508_90%)] pointer-events-none z-0" />

      {/* Cyber ambient gradient glowing glowing design layers and color blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 select-none">
        {/* Neon Emerald Blob - bottom left */}
        <div className="absolute bottom-[-100px] left-[-150px] w-[700px] h-[700px] bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.08)_0,transparent_70%)] blur-[90px] rounded-full transform-gpu animate-blob-slow-1" />
        
        {/* Vibrant Violet Cosmic Core Blob - center upper */}
        <div className="absolute top-[-100px] left-[30%] w-[800px] h-[800px] bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.08)_0,transparent_75%)] blur-[100px] rounded-full transform-gpu animate-blob-slow-2" />
        
        {/* Electric Indigo Deep Blob - right middle */}
        <div className="absolute top-[20%] right-[-150px] w-[750px] h-[750px] bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.08)_0,transparent_70%)] blur-[100px] rounded-full transform-gpu animate-blob-slow-3" />
      </div>

      {/* Top Header */}
      <header className="w-full max-w-5xl mx-auto px-6 py-6 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2.5">
          <div 
            className="w-8 h-8 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[1.5px] shrink-0" 
            style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
          >
            <div 
              className="w-full h-full bg-[#050508] flex items-center justify-center p-1"
              style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
            >
              <img 
                src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                alt="Webnixo AI Logo" 
                className="w-5 h-5 object-contain" 
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <span className="font-sans font-black text-xl text-white tracking-tight">WEBNIXO AI</span>
          <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
        </div>

        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-zinc-400 hover:text-white transition-all text-xs font-semibold px-4 py-2 bg-zinc-950 border border-zinc-900 rounded-xl hover:border-zinc-800 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </button>
      </header>

      {/* Main Form Center */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="w-full max-w-xl space-y-8 text-center"
        >
          {/* Welcome Text, utilizing corporate Logo */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <div 
                className="w-20 h-20 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[2px] shrink-0 Filter drop-shadow-[0_0_15px_rgba(139,92,246,0.3)]" 
                style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
              >
                <div 
                  className="w-full h-full bg-[#0c0c10] flex items-center justify-center p-3"
                  style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                >
                  <img 
                    src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                    alt="Webnixo AI Corporate Brand Logo" 
                    className="w-12 h-12 object-contain" 
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold rounded-full tracking-wide">
                <Sparkles className="h-3 w-3 text-indigo-400" />
                <span>{isAffiliateMode ? "Exclusive Partner Network" : "Next-Gen Creation Suite"}</span>
              </div>
              
              <h1 className="text-3xl font-extrabold text-white tracking-tight leading-none">
                {isAffiliateMode ? "Affiliate Partner Portal" : "Welcome to WEBNIXO AI"}
              </h1>
              <p className="text-zinc-400 text-sm max-w-sm mx-auto leading-relaxed">
                {isAffiliateMode 
                  ? "Track metrics, customize referral campaigns, and check real-time commission payouts for bringing users to WEBNIXO AI."
                  : "Create intelligent text content, generate high-fidelity pixel artwork, and explore multiple frontier AI models in one interface."}
              </p>
            </div>
          </div>

          {/* Separate Affiliate Dashboard Simulator */}
          {isAffiliateMode && isAffiliateLoggedIn ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-[#0f0f13] border border-emerald-500/20 rounded-2xl p-6 sm:p-8 shadow-2xl relative text-left space-y-6"
            >
              <div className="flex items-center justify-between border-b border-zinc-900/60 pb-4">
                <div>
                  <span className="text-[9px] font-bold text-emerald-400 shortcut-tag uppercase tracking-widest block font-mono">ACTIVE PARTNER ACCOUNT</span>
                  <p className="text-sm font-bold text-white uppercase">{activeAffiliateCode} PORTAL</p>
                </div>
                <button
                  onClick={() => {
                    localStorage.removeItem("login_as");
                    setIsAffiliateLoggedIn(false);
                    signOut();
                  }}
                  className="text-xs text-zinc-500 hover:text-white transition-colors underline cursor-pointer"
                >
                  Logout Panel
                </button>
              </div>

              {/* If admin is logged in, show tabs toggle */}
              {isAdminUser && (
                <div className="flex bg-zinc-950 p-1 rounded-xl border border-zinc-900 font-mono text-[10px] sm:text-xs">
                  <button
                    onClick={() => setIsAdminTabActive(false)}
                    className={`flex-1 py-1.5 rounded-lg font-bold uppercase tracking-wider transition-all cursor-pointer text-center ${!isAdminTabActive ? "bg-emerald-500 text-black shadow-lg shadow-emerald-500/5 font-sans" : "text-zinc-400 hover:text-white"}`}
                  >
                    Partner Portfolio
                  </button>
                  <button
                    onClick={() => {
                      setIsAdminTabActive(true);
                      loadAdminPayouts();
                      loadAdminPricing();
                    }}
                    className={`flex-1 py-1.5 rounded-lg font-bold uppercase tracking-wider transition-all cursor-pointer text-center ${isAdminTabActive ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/10 font-sans" : "text-zinc-400 hover:text-white"}`}
                  >
                    🛡️ System Admin Console
                  </button>
                </div>
              )}

              {isAdminTabActive && isAdminUser ? (
                // --- ADMIN PORTAL UI CARD CONTENT ---
                <div className="space-y-6">
                  {/* Payout Management Section */}
                  <div className="border-t border-zinc-900/60 pt-4 space-y-4 text-left">
                    <div className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4 text-[#A855F7]" />
                      <span className="text-[10px] text-zinc-300 font-bold uppercase tracking-wider">Affiliate Cashout Requests (File DB)</span>
                    </div>

                    {isLoadingAdminPayouts ? (
                      <div className="flex items-center justify-center p-8 bg-zinc-950/40 border border-zinc-900 rounded-xl">
                        <Loader2 className="h-5 w-5 animate-spin text-indigo-400" />
                      </div>
                    ) : adminPayoutRequests.length === 0 ? (
                      <p className="text-xs text-zinc-500 text-center py-6 bg-zinc-950/40 border border-zinc-900 rounded-xl">
                        No requested payout lines on the file registry.
                      </p>
                    ) : (
                      <div className="space-y-3">
                        {adminPayoutRequests.map((reqItem: any) => (
                          <div 
                            key={reqItem.token} 
                            className="bg-zinc-950/90 border border-zinc-900 rounded-xl p-4 hover:border-zinc-800 transition-colors text-left"
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-zinc-900/60">
                              <div className="space-y-0.5">
                                <span className="text-[10px] text-indigo-400 font-mono font-bold select-all leading-none">{reqItem.token}</span>
                                <p className="text-xs font-bold text-white pr-2">{reqItem.email} ({reqItem.affiliateCode || "N/A"})</p>
                              </div>
                              <div className="flex items-center gap-2.5 shrink-0">
                                <span className="font-mono text-xs font-black text-white bg-zinc-900 px-2.5 py-1 rounded border border-zinc-800">
                                  ₹{Number(reqItem.amount).toLocaleString("en-IN")}
                                </span>
                                {reqItem.status === "Credited" ? (
                                  <span className="inline-flex items-center gap-1 text-[8px] font-extrabold font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/25 px-2 py-0.5 rounded-full uppercase leading-none">
                                    Credited
                                  </span>
                                ) : reqItem.status === "Returned" ? (
                                  <span className="inline-flex items-center gap-1 text-[8px] font-extrabold font-mono text-red-400 bg-red-950/45 border border-red-550/25 px-2 py-0.5 rounded-full uppercase leading-none">
                                    Returned
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-[8px] font-extrabold font-mono text-amber-400 bg-amber-950/45 border border-amber-500/25 px-2 py-0.5 rounded-full uppercase leading-none animate-pulse">
                                    Processing
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Bank Details section */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px] py-2.5 text-zinc-400 border-b border-zinc-900/60 font-sans">
                              <div>
                                <p><span className="text-zinc-500 font-semibold">Beneficiary Name:</span> <span className="text-zinc-200 select-all font-mono font-medium">{reqItem.bankDetails?.holderName || "Not Provided"}</span></p>
                                <p><span className="text-zinc-500 font-semibold">Account Number:</span> <span className="text-zinc-200 select-all font-mono font-medium">{reqItem.bankDetails?.accountNumber || "Not Provided"}</span></p>
                              </div>
                              <div>
                                <p><span className="text-zinc-500 font-semibold">IFSC Code:</span> <span className="text-zinc-200 select-all font-mono font-medium">{reqItem.bankDetails?.ifscCode || "Not Provided"}</span></p>
                                <p><span className="text-zinc-500 font-semibold">UPI ID:</span> <span className="text-zinc-200 select-all font-mono font-medium">{reqItem.bankDetails?.upiId || "Not Provided"}</span></p>
                              </div>
                              <div className="sm:col-span-2 mt-1 flex flex-col gap-1 text-[9px] text-zinc-500 pt-1">
                                <p><span className="text-zinc-500 font-semibold">Transaction ID:</span> <span className="text-indigo-400 font-mono font-semibold">{reqItem.transactionId || "None"}</span></p>
                                {reqItem.notes && <p><span className="text-zinc-500 font-semibold">Admin Notes:</span> <span className="text-zinc-300 italic">{reqItem.notes}</span></p>}
                              </div>
                            </div>

                            {/* Inline Edit Form toggle */}
                            {selectedPayoutViewToken === reqItem.token ? (
                              <div className="pt-3 space-y-3 bg-[#0c0c10] p-3 rounded-lg border border-zinc-900 mt-2 text-left">
                                <div className="text-[10px] font-bold text-zinc-300 uppercase tracking-widest block font-mono">Configure Status Token</div>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                  <div className="space-y-1 text-left">
                                    <label className="text-[9px] text-zinc-500 font-semibold block">Payout Status</label>
                                    <select 
                                      value={statusUpdateVal} 
                                      onChange={(e: any) => setStatusUpdateVal(e.target.value)}
                                      className="w-full text-[11px] font-sans bg-zinc-950 border border-zinc-805 rounded px-2 py-1.5 text-white outline-none"
                                    >
                                      <option value="Processing">Processing</option>
                                      <option value="Credited">Credited</option>
                                      <option value="Returned">Returned</option>
                                    </select>
                                  </div>

                                  <div className="sm:col-span-2 space-y-1 text-left">
                                    <label className="text-[9px] text-zinc-500 font-semibold block">Transaction ID / Reference Token</label>
                                    <input 
                                      type="text" 
                                      value={txnIdUpdateVal}
                                      onChange={(e) => setTxnIdUpdateVal(e.target.value)}
                                      placeholder="e.g. CF_TXN_7162531"
                                      className="w-full text-xs font-mono bg-zinc-950 border border-zinc-805 rounded px-2.5 py-1.5 text-white outline-none"
                                    />
                                  </div>

                                  <div className="sm:col-span-3 space-y-1 text-left">
                                    <label className="text-[9px] text-zinc-500 font-semibold block">Internal Notes / Feedback</label>
                                    <input 
                                      type="text" 
                                      value={notesUpdateVal}
                                      onChange={(e) => setNotesUpdateVal(e.target.value)}
                                      placeholder="e.g. Sent via Immediate IMPS bank clearance"
                                      className="w-full text-xs font-sans bg-zinc-950 border border-zinc-805 rounded px-2.5 py-1.5 text-white outline-none"
                                    />
                                  </div>
                                </div>

                                <div className="flex gap-2 pt-1 justify-end font-mono">
                                  <button 
                                    onClick={() => setSelectedPayoutViewToken(null)}
                                    className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded text-[10px] font-bold cursor-pointer"
                                  >
                                    Cancel
                                  </button>
                                  <button 
                                    onClick={() => handleUpdatePayoutStatus(reqItem.token)}
                                    className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-[10px] font-bold cursor-pointer"
                                  >
                                    Save Settlement
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <div className="flex justify-end pt-2">
                                <button 
                                  onClick={() => {
                                    setSelectedPayoutViewToken(reqItem.token);
                                    setStatusUpdateVal(reqItem.status);
                                    setTxnIdUpdateVal(reqItem.transactionId || "");
                                    setNotesUpdateVal(reqItem.notes || "");
                                  }}
                                  className="px-3 py-1 bg-zinc-900 border border-zinc-850 hover:border-zinc-700 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded text-[10px] font-bold flex items-center gap-1.5 cursor-pointer font-mono"
                                >
                                  ✒️ Edit Status & Ref
                                </button>
                              </div>
                            )}

                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Pricing Overrides Section */}
                  <form onSubmit={saveAdminPricingSettings} className="border-t border-zinc-900/60 pt-6 space-y-4 text-left">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-[#10B981]" />
                      <span className="text-[10px] text-zinc-300 font-bold uppercase tracking-wider">Dynamic Plan Pricing Adjustments</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Starter pricing */}
                      <div className="p-3.5 bg-zinc-950 border border-zinc-900 rounded-xl space-y-3">
                        <div className="text-[10px] font-bold text-zinc-400 uppercase font-mono border-b border-zinc-900 pb-1 flex justify-between">
                          <span>Starter Plan</span>
                          <span className="text-zinc-500">Day/Month</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-left">
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Price (₹ INR)</label>
                            <input 
                              type="number" 
                              value={starterPriceVal}
                              onChange={(e) => setStarterPriceVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-800 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Credit Limit</label>
                            <input 
                              type="number" 
                              value={starterLimitVal}
                              onChange={(e) => setStarterLimitVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-800 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Pro pricing */}
                      <div className="p-3.5 bg-zinc-950 border border-zinc-900 rounded-xl space-y-3">
                        <div className="text-[10px] font-bold text-zinc-400 uppercase font-mono border-b border-zinc-900 pb-1 flex justify-between">
                          <span>Pro Plan</span>
                          <span className="text-zinc-500">Monthly</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-left">
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Price (₹ INR)</label>
                            <input 
                              type="number" 
                              value={proPriceVal}
                              onChange={(e) => setProPriceVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-800 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Credit Limit</label>
                            <input 
                              type="number" 
                              value={proLimitVal}
                              onChange={(e) => setProLimitVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-800 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Pro Yearly pricing */}
                      <div className="p-3.5 bg-zinc-950 border border-zinc-900 rounded-xl space-y-3 sm:col-span-2">
                        <div className="text-[10px] font-bold text-zinc-400 uppercase font-mono border-b border-zinc-900 pb-1 flex justify-between">
                          <span>Developer Pro (Yearly Plan Pass)</span>
                          <span className="text-emerald-400">Best Value Tier</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Price (₹ INR)</label>
                            <input 
                              type="number" 
                              value={proYearlyPriceVal}
                              onChange={(e) => setProYearlyPriceVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-800 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Credit Limit (Usage credits value)</label>
                            <input 
                              type="number" 
                              value={proYearlyLimitVal}
                              onChange={(e) => setProYearlyLimitVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-800 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* System parameters */}
                      <div className="p-3.5 bg-zinc-950 border border-zinc-900 rounded-xl space-y-3 sm:col-span-2">
                        <div className="text-[10px] font-bold text-zinc-400 uppercase font-mono border-b border-zinc-900 pb-1 flex justify-between">
                          <span>Marketing Commission & Coupon Specifications</span>
                          <span className="text-zinc-500">Affiliate Engine</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Partner Reward Commission (₹ INR per sign up)</label>
                            <input 
                              type="number" 
                              value={affiliateCommissionVal}
                              onChange={(e) => setAffiliateCommissionVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-805 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Buyer/Customer Discount (₹ INR deduction)</label>
                            <input 
                              type="number" 
                              value={customerDiscountVal}
                              onChange={(e) => setCustomerDiscountVal(Number(e.target.value))}
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-850 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                          <div className="sm:col-span-2 space-y-1">
                            <label className="text-[9px] text-zinc-500 font-semibold block">Valid Eligible Coupons (Comma-separated uppercase strings)</label>
                            <input 
                              type="text" 
                              value={validCouponsVal}
                              onChange={(e) => setValidCouponsVal(e.target.value)}
                              placeholder="LAUNCH50, AFFILIATE50, WEBNIXO50"
                              className="w-full text-xs font-mono bg-zinc-900 border border-zinc-805 focus:border-indigo-500/50 rounded px-2.5 py-1.5 text-white outline-none"
                            />
                          </div>
                        </div>
                      </div>

                    </div>

                    <div className="pt-2 flex flex-col gap-2">
                      <button
                        type="submit"
                        disabled={isSavingPricingSettings}
                        className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-zinc-900 disabled:text-zinc-600 text-white text-xs font-bold rounded-lg transition-all cursor-pointer text-center flex items-center justify-center gap-1.5 font-sans"
                      >
                        {isSavingPricingSettings ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin" />
                            <span>Updating Configuration Store...</span>
                          </>
                        ) : (
                          "Apply & Sync System Settings"
                        )}
                      </button>

                      <AnimatePresence>
                        {pricingSaveSuccess && (
                          <motion.p
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="text-[10px] text-emerald-400 text-center font-semibold bg-emerald-950/20 border border-emerald-500/20 py-2 rounded-lg"
                          >
                            ✓ Configuration database successfully synced. Core active pricing overrides applied!
                          </motion.p>
                        )}
                      </AnimatePresence>
                    </div>

                  </form>
                </div>
              ) : (
                <>
                  {/* Grid with statistics */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-zinc-950 border border-zinc-900 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-zinc-400 font-bold uppercase">Referrals</span>
                    <Users className="h-4 w-4 text-indigo-400" />
                  </div>
                  <h3 className="text-xl font-black text-white">42 Active</h3>
                  <p className="text-[9px] text-zinc-500">18.4% conversion rate</p>
                </div>

                <div className="p-4 bg-zinc-950 border border-zinc-900 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-zinc-400 font-bold uppercase">Commission</span>
                    <Percent className="h-4 w-4 text-emerald-400" />
                  </div>
                  <h3 className="text-xl font-black text-emerald-400">20% Tier</h3>
                  <p className="text-[9px] text-zinc-500">Industry leading rate</p>
                </div>

                <div className="p-4 bg-zinc-950 border border-zinc-900 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-zinc-400 font-bold uppercase">Total Earnings</span>
                    <IndianRupee className="h-4 w-4 text-indigo-400" />
                  </div>
                  <h3 className="text-xl font-black text-white">₹18,400</h3>
                  <p className="text-[9px] text-emerald-400 font-medium">₹5,400 pending</p>
                </div>
              </div>

              {/* Custom Invite Link tool */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-900 space-y-3">
                <span className="text-[10px] text-zinc-400 font-bold uppercase block">Your Personal Referral Link:</span>
                <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-lg p-2.5">
                  <span className="text-xs text-zinc-400 flex-1 truncate select-all">
                    {window.location.origin}/?ref={activeAffiliateCode}
                  </span>
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-black text-[11px] font-bold rounded-md transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <LinkIcon className="h-3 w-3" />
                    <span>{copiedLink ? "Copied!" : "Copy Link"}</span>
                  </button>
                </div>
                <p className="text-[10px] text-zinc-500 leading-relaxed">
                  Anyone who registers or upgrades under this link will receive an instant 20% system-wide pre-applied coupon discount, and you earn commissions.
                </p>
              </div>

              {/* Bank Account Details For Payout Section */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-900 space-y-4">
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-emerald-400" />
                  <span className="text-[10px] text-zinc-300 font-bold uppercase tracking-wider">Bank Account Details for Payout</span>
                </div>
                
                <form onSubmit={handleSaveBankDetails} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-500 font-semibold block">Account Holder Name</label>
                      <input 
                        type="text" 
                        required
                        value={bankHolderName}
                        onChange={(e) => setBankHolderName(e.target.value)}
                        placeholder="John Doe" 
                        className="w-full text-xs bg-zinc-900 border border-zinc-800 focus:border-emerald-500/50 rounded-lg px-2.5 py-2 text-white placeholder-zinc-600 outline-none transition-colors"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-500 font-semibold block">UPI ID / VPA</label>
                      <input 
                        type="text" 
                        required
                        value={bankUpiId}
                        onChange={(e) => setBankUpiId(e.target.value)}
                        placeholder="john@okaxis" 
                        className="w-full text-xs bg-zinc-900 border border-zinc-800 focus:border-emerald-500/50 rounded-lg px-2.5 py-2 text-white placeholder-zinc-600 outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-500 font-semibold block">Account Number</label>
                      <input 
                        type="text" 
                        required
                        value={bankAccountNumber}
                        onChange={(e) => setBankAccountNumber(e.target.value)}
                        placeholder="35091029103" 
                        className="w-full text-xs bg-zinc-900 border border-zinc-800 focus:border-emerald-500/50 rounded-lg px-2.5 py-2 text-white placeholder-zinc-600 outline-none transition-colors"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-500 font-semibold block">Bank IFSC Code</label>
                      <input 
                        type="text" 
                        required
                        value={bankIfscCode}
                        onChange={(e) => setBankIfscCode(e.target.value)}
                        placeholder="SBIN0001830" 
                        className="w-full text-xs bg-zinc-900 border border-zinc-800 focus:border-emerald-500/50 rounded-lg px-2.5 py-2 text-white placeholder-zinc-600 outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="pt-1 flex items-center justify-between gap-2">
                    <p className="text-[9px] text-[#A855F7] font-medium leading-relaxed max-w-[70%]">
                      ⚡ *Standard payout turnaround:* All requested funds are processed and securely dispatched directly to this account within **2-3 working days**.
                    </p>
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500 hover:text-black border border-emerald-500/20 text-emerald-400 hover:border-transparent text-[11px] font-bold rounded-lg transition-all cursor-pointer whitespace-nowrap"
                    >
                      Save Bank Details
                    </button>
                  </div>
                </form>

                <AnimatePresence>
                  {isBankDetailsSaved && (
                    <motion.p 
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="text-[10px] text-emerald-400 text-center font-semibold bg-emerald-950/20 border border-emerald-500/20 py-2 rounded-lg"
                    >
                      ✓ Bank account & UPI payout settings saved securely.
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>

              {/* High-Fidelity Interactive Payout Console */}
              <div className="pt-4 border-t border-zinc-900/60 space-y-4">
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-[#A855F7]" />
                  <span className="text-[10px] text-zinc-300 font-bold uppercase tracking-wider">Execute Commission Payout</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                  <div className="sm:col-span-2 space-y-1">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] text-zinc-500 font-semibold block">Enter Payout Settlement Amount</label>
                      <span className="text-[9px] text-zinc-500">Limit: ₹1,000 - ₹50,050</span>
                    </div>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-bold font-mono">₹</span>
                      <input 
                        type="number"
                        min="1000"
                        max="50000"
                        value={payoutAmount}
                        onChange={(e) => {
                          setPayoutAmount(e.target.value);
                          setPayoutError(null);
                        }}
                        placeholder="5400" 
                        className="w-full text-xs font-mono bg-zinc-950 border border-zinc-800 focus:border-indigo-500/50 rounded-lg pl-6 pr-3 py-2 text-white placeholder-zinc-700 outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setPayoutError(null);
                      const amt = parseFloat(payoutAmount);
                      if (isNaN(amt) || amt < 1000) {
                        setPayoutError("Minimum payout threshold is ₹1,000.");
                        return;
                      }
                      if (amt > 50000) {
                        setPayoutError("Maximum single transaction limit is ₹50,000.");
                        return;
                      }
                      if (!bankHolderName || !bankAccountNumber || !bankUpiId) {
                        setPayoutError("Please enter & save your bank account / UPI details above first.");
                        return;
                      }

                      setRequestedCashout(true);
                      
                      // Perform real post to payout registry
                      fetch("/api/payout/request", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          email: user?.email || "anonymous_partner@webnixo.ai",
                          affiliateCode: activeAffiliateCode,
                          amount: amt,
                          bankDetails: {
                            holderName: bankHolderName,
                            accountNumber: bankAccountNumber,
                            ifscCode: bankIfscCode,
                            upiId: bankUpiId
                          }
                        })
                      })
                      .then(res => res.json())
                      .then(data => {
                        if (data.success && data.payout) {
                          setPayoutHistory(prev => [data.payout, ...prev]);
                        } else {
                          // Fallback local registry if offline
                          const generatedId = "TXN-WNX-" + Math.random().toString(36).substring(2, 8).toUpperCase();
                          setPayoutHistory(prev => [{
                            token: generatedId,
                            amount: amt,
                            date: new Date().toLocaleDateString("en-IN", { day: 'numeric', month: 'short', year: 'numeric' }),
                            status: "Processing" as const
                          }, ...prev]);
                        }
                      })
                      .catch(err => {
                        console.warn("[PAYOUT] Fallback simulation active due to offline endpoint:", err);
                        const generatedId = "TXN-WNX-" + Math.random().toString(36).substring(2, 8).toUpperCase();
                        setPayoutHistory(prev => [{
                          token: generatedId,
                          amount: amt,
                          date: new Date().toLocaleDateString("en-IN", { day: 'numeric', month: 'short', year: 'numeric' }),
                          status: "Processing" as const
                        }, ...prev]);
                      })
                      .finally(() => {
                        setPayoutAmount("");
                        setRequestedCashout(false);
                      });
                    }}
                    disabled={requestedCashout}
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-zinc-900 disabled:text-zinc-600 text-white text-xs font-bold rounded-lg transition-all cursor-pointer text-center flex items-center justify-center gap-1.5 font-sans"
                  >
                    {requestedCashout ? (
                      <>
                        <Loader2 className="h-3 w-3 animate-spin" />
                        <span>Clearing Token...</span>
                      </>
                    ) : (
                      "Request Payout"
                    )}
                  </button>
                </div>

                {payoutError && (
                  <p className="text-[10px] text-red-400 bg-red-950/25 border border-red-550/20 py-1.5 px-3 rounded-lg font-semibold text-center mt-1">
                    ⚠️ {payoutError}
                  </p>
                )}

                {/* Real-time Ledger Tracking System */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-1.5">
                    <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider font-mono">Ledger Token / Transaction Registry</span>
                    <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider font-mono">Credit status</span>
                  </div>

                  <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                    {payoutHistory.map((item) => (
                      <div 
                        key={item.token}
                        className="flex items-center justify-between p-2.5 bg-zinc-950/80 border border-zinc-900 rounded-lg hover:border-zinc-800 transition-colors"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[10px] font-black text-indigo-400 select-all">{item.token}</span>
                            <span className="text-[9px] text-zinc-600">{item.date}</span>
                          </div>
                          <p className="text-[9px] text-zinc-500">Beneficiary: <span className="text-zinc-400 font-medium">{bankHolderName || "Pre-Verified Partner"}</span></p>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="font-mono text-xs font-extrabold text-white">₹{item.amount.toLocaleString("en-IN")}</span>
                          
                          {item.status === "Credited" ? (
                            <span className="inline-flex items-center gap-1 text-[8px] font-extrabold font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/25 px-2 py-0.5 rounded-full uppercase leading-none tracking-widest">
                              <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
                              Credited
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[8px] font-extrabold font-mono text-amber-400 bg-amber-950/45 border border-amber-500/25 px-2 py-0.5 rounded-full uppercase leading-none tracking-widest animate-pulse">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                              Processing
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  <p className="text-[9px] text-zinc-600 text-center">
                    🔒 Securing dispatches with end-to-end cryptographic checks. Instant status refresh active.
                  </p>
                </div>
              </div>

              {/* Terms and Conditions Accordion Panel */}
              <div className="border border-zinc-900 rounded-xl overflow-hidden bg-zinc-950">
                <button
                  onClick={() => setShowTerms(!showTerms)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-zinc-900/40 text-xs font-bold text-zinc-300 hover:text-white transition-colors cursor-pointer select-none"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-zinc-400" />
                    <span>Affiliate Program Partner Terms & Conditions</span>
                  </div>
                  {showTerms ? <ChevronUp className="h-4 w-4 text-zinc-400" /> : <ChevronDown className="h-4 w-4 text-zinc-400" />}
                </button>

                <AnimatePresence>
                  {showTerms && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden border-t border-zinc-900"
                    >
                      <div className="p-4 text-[10px] text-zinc-500 space-y-2.5 max-h-[160px] overflow-y-auto leading-relaxed">
                        <p className="font-bold text-zinc-400 border-b border-zinc-900 pb-1">WEBNIXO AI AFFILIATE AGREEMENT</p>
                        <p>
                          1. **Eligibility**: Partners must utilize unique, authentic web channels to share their affiliate code. Self-referrals (registering your own discount using your own referral code) are strictly audited, system-rejected, and can lead to immediate account termination.
                        </p>
                        <p>
                          2. **Commission & Attribution**: A standard 20% recurring commission is applied on every primary customer purchase or recurrent plan upgrade. Cookie lifetime tracks client signups for exactly 45 days.
                        </p>
                        <p>
                          3. **Payout Settling**: The standard minimal threshold for requestable settlement payouts is ₹1,000. All authorized settlements will be disbursed to the Designated Bank Account or registered UPI ID within **2-3 working days** from the request date.
                        </p>
                        <p>
                          4. **Traffic Rules**: Sending search engine ads (e.g., bidding on "WEBNIXO AI" branded terms or SEO trademark hijacking) is strictly forbidden. Spontaneous spam email, comment posting, or deceptive marketing acts are instantly banned.
                        </p>
                        <p>
                          5. **Disclosures**: You agree to explicitly state that you are earning affiliate promotional rewards whenever publishing your personal invite links to users, satisfying transparency rules.
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </>
          )}

            </motion.div>
          ) : (
            /* Standard Authorization Card & Affiliate Custom Options */
            <div className="bg-[#111115]/80 border border-zinc-800/80 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-sm relative overflow-hidden">
              
              <div className="space-y-6">
                
                <div className="space-y-1 text-center">
                  <h2 className="text-sm font-semibold text-zinc-300">
                    {isAffiliateMode ? "Affiliate Code Authorization" : "Sign in to start creating"}
                  </h2>
                  <p className="text-xs text-zinc-500">
                    {isAffiliateMode 
                      ? "Enter your pre-registered Affiliate Partner Code below to enter" 
                      : "Access your synchronized workspaces and chat logs"}
                  </p>
                </div>

                {/* Error Frame */}
                {displayedError && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-red-500/5 text-red-400 border border-red-500/20 p-3.5 rounded-xl text-xs flex gap-3 text-left"
                  >
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Access Denied:</span>
                      <p className="text-zinc-400 mt-0.5 leading-relaxed">{displayedError}</p>
                    </div>
                  </motion.div>
                )}

                {isAffiliateMode ? (
                  /* Custom Partner Login with Google */
                  <div className="space-y-4 text-left">
                    <p className="text-zinc-400 text-xs text-center pb-1">
                      Sign in using your Google account. Your email will be securely matched against our partner registration database.
                    </p>

                    <button
                      disabled={isRedirecting}
                      onClick={handleGoogleLogin}
                      className="w-full flex items-center justify-center gap-3 bg-emerald-500 hover:bg-emerald-400 disabled:bg-zinc-800 disabled:text-zinc-500 text-black font-extrabold py-3.5 px-4 rounded-xl transition-all duration-200 shadow-lg shadow-emerald-500/10 cursor-pointer transform active:scale-[0.98] select-none text-sm group"
                    >
                      {isRedirecting ? (
                        <Loader2 className="h-5 w-5 animate-spin text-black" />
                      ) : (
                        <svg className="w-5 h-5 shrink-0 transition-transform duration-200 group-hover:scale-105" viewBox="0 0 24 24">
                          <path
                            fill="#000000"
                            d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114-3.41 0-6.173-2.762-6.173-6.17 0-3.41 2.763-6.172 6.173-6.172 1.465 0 2.805.511 3.864 1.353l3.14-3.14C19.066 2.052 15.897 1 12.24 1 6.033 1 1 6.033 1 12.24s5.033 11.24 11.24 11.24c5.898 0 10.963-4.215 10.963-11.24 0-.756-.08-1.488-.22-2.195H12.24z"
                          />
                        </svg>
                      )}
                      <span>{isRedirecting ? "Connecting safe session..." : "Sign in to Affiliate with Google"}</span>
                    </button>

                    <div className="pt-2 text-center border-t border-zinc-900 mt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveAffiliateCode("LAUNCH50");
                          setIsAffiliateLoggedIn(true);
                        }}
                        className="text-[10px] text-zinc-500 hover:text-emerald-400 underline"
                      >
                        ⚡ Simulate Demo Partner Dashboard Sandbox
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Standard Google Login button */
                  <button
                    disabled={isRedirecting}
                    onClick={handleGoogleLogin}
                    className="w-full flex items-center justify-center gap-3 bg-white hover:bg-neutral-100 disabled:bg-zinc-800 disabled:text-zinc-500 text-black font-semibold py-3 px-4 rounded-xl transition-all duration-200 shadow-md cursor-pointer transform active:scale-[0.98] select-none text-sm group"
                  >
                    {isRedirecting ? (
                      <Loader2 className="h-5 w-5 animate-spin text-zinc-500" />
                    ) : (
                      <svg className="w-4 h-4 shrink-0 transition-transform duration-200 group-hover:scale-105" viewBox="0 0 24 24">
                        <path
                          fill="#EA4335"
                          d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114-3.41 0-6.173-2.762-6.173-6.17 0-3.41 2.763-6.172 6.173-6.172 1.465 0 2.805.511 3.864 1.353l3.14-3.14C19.066 2.052 15.897 1 12.24 1 6.033 1 1 6.033 1 12.24s5.033 11.24 11.24 11.24c5.898 0 10.963-4.215 10.963-11.24 0-.756-.08-1.488-.22-2.195H12.24z"
                        />
                      </svg>
                    )}
                    <span>{isRedirecting ? "Connecting safe session..." : "Continue with Google"}</span>
                  </button>
                )}

              </div>
            </div>
          )}

          <p className="text-xs text-zinc-500">
            Secure, private authentication powered by verified industry protocols.
          </p>

        </motion.div>
      </main>

      {/* Bottom Footer */}
      <footer className="w-full max-w-5xl mx-auto px-6 py-6 text-center text-xs text-zinc-700 border-t border-zinc-900/60 relative z-10">
        <p>© 2026 WEBNIXO AI. Created and refined for frictionless production.</p>
      </footer>

    </div>
  );
};

