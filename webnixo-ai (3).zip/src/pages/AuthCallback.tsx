import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { Loader2, AlertCircle, ArrowRight } from "lucide-react";

/**
 * Dedicated Auth Callback Page
 * Intercepts auth code verifications and PKCE callback events.
 * Outputs detailed logs in console for debug tracing.
 */
export const AuthCallback: React.FC = () => {
  const navigate = useNavigate();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);

  useEffect(() => {
    console.log("=== [DEBUG] AUTH CALLBACK INITIATED ===");
    console.log("Current URL:", window.location.href);
    console.log("Current Origin:", window.location.origin);
    console.log("Search Parameters:", window.location.search);
    console.log("Hash Parameters:", window.location.hash);

    const checkKeys = Object.keys(localStorage).filter(
      key => key.includes("supabase") || key.includes("verifier") || key.includes("state")
    );
    console.log("Detected LocalStorage Keys:", checkKeys);
    checkKeys.forEach(k => {
      console.log(`LocalStorage key [${k}]:`, localStorage.getItem(k)?.substring(0, 40) + "...");
    });

    const processOAuthExchange = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const error = params.get("error");
        const errorCode = params.get("error_code");
        const errorDescription = params.get("error_description") || params.get("error_message");

        if (error) {
          console.error("AuthCallback: Received explicit error parameter from Supabase OAuth server:", {
            error,
            errorCode,
            errorDescription
          });
          setErrorMsg(errorDescription || `OAuth Error: ${error}`);
          setErrorDetails(`Code: ${errorCode || "none"}`);
          return;
        }

        // Trigger session loading / code exchange via retrieve or refresh
        console.log("AuthCallback: Querying Supabase auth.getSession() to verify exchange...");
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (sessionError) {
          console.error("AuthCallback: getSession error:", sessionError);
          throw sessionError;
        }

        if (session) {
          console.log("AuthCallback: Verification success! Session established for email:", session.user?.email);
          if (localStorage.getItem("login_as") === "affiliate") {
            navigate("/login?role=affiliate", { replace: true });
          } else {
            navigate("/dashboard", { replace: true });
          }
        } else {
          console.warn("AuthCallback: No session returned immediately. Subscribing to onAuthStateChange fallback...");
          
          // Use auth state change listener to watch for deferred exchange success
          const { data: { subscription } } = supabase.auth.onAuthStateChange((event, currentSession) => {
            console.log(`AuthCallback (Fallback listener): Auth state event [${event}] triggered.`);
            if (currentSession) {
              console.log("AuthCallback: Session resolved via callback listener.");
              subscription.unsubscribe();
              if (localStorage.getItem("login_as") === "affiliate") {
                navigate("/login?role=affiliate", { replace: true });
              } else {
                navigate("/dashboard", { replace: true });
              }
            }
          });

          // Timeout fallback to prevent hanging page
          const timer = setTimeout(() => {
            subscription.unsubscribe();
            console.error("AuthCallback: Verification timer elapsed. No session established.");
            setErrorMsg("Verification timeout. No active session could be established.");
            setErrorDetails("Ensure third-party cookies are enabled, and the domain port matches Supabase redirect configurations.");
          }, 4500);

          return () => {
            clearTimeout(timer);
            subscription.unsubscribe();
          };
        }
      } catch (err: any) {
        console.error("AuthCallback: Exception handled in processOAuthExchange block:", err);
        setErrorMsg(err.message || "An exception occurred verifying OAuth hashes.");
        setErrorDetails(JSON.stringify(err));
      }
    };

    processOAuthExchange();
  }, [navigate]);

  return (
    <div className="min-h-screen w-full bg-[#08080a] text-[#ececec] font-sans flex flex-col items-center justify-center p-6 relative overflow-hidden select-none">
      
      {/* Soft background ambient glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.03)_0,rgba(0,0,0,0)_100%)] pointer-events-none z-0" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-indigo-500/5 blur-[120px] rounded-full pointer-events-none z-0" />

      <div className="w-full max-w-md relative z-10 space-y-8 text-center">
        <div className="flex flex-col items-center gap-2">
          <span className="font-sans font-black text-2xl text-white tracking-tight">WEBNIXO AI</span>
          <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
        </div>

        <div className="bg-[#111115]/80 border border-zinc-800/80 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-sm relative overflow-hidden">
          {errorMsg ? (
            <div className="space-y-6">
              <div className="flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-red-500/10 flex items-center justify-center text-red-400">
                  <AlertCircle className="h-6 w-6" />
                </div>
              </div>

              <div className="space-y-2">
                <h2 className="text-lg font-bold text-white">OAuth Verification Mismatch</h2>
                <p className="text-zinc-400 text-xs leading-relaxed">
                  The authentication state or verifier was not recognized. This is usually caused by an origin/port mismatch or a temporary cookie blockage.
                </p>
              </div>

              <div className="p-4 bg-zinc-900/60 rounded-xl text-left border border-zinc-800/80 text-xs space-y-2">
                <p className="font-semibold text-red-400">Message:</p>
                <p className="text-zinc-300 font-mono text-[11px] break-words">{errorMsg}</p>
                {errorDetails && (
                  <>
                    <p className="font-semibold text-zinc-400 mt-2">Diagnosis details:</p>
                    <p className="text-zinc-500 font-mono text-[10px] break-words leading-relaxed">{errorDetails}</p>
                  </>
                )}
              </div>

              <button
                onClick={() => navigate("/login", { replace: true })}
                className="w-full flex items-center justify-center gap-2 bg-white hover:bg-neutral-150 text-black font-semibold py-2.5 rounded-xl transition-all active:scale-[0.98] text-xs cursor-pointer shadow"
              >
                <span>Return to Login Portal</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <div className="space-y-6 py-4">
              <div className="flex items-center justify-center">
                <Loader2 className="h-10 w-10 animate-spin text-indigo-500" />
              </div>
              <div className="space-y-2">
                <h2 className="text-sm font-semibold text-zinc-200">Verifying safe tokens...</h2>
                <p className="text-xs text-zinc-500">
                  Establishing secure cryptographic channel with Supabase.
                </p>
              </div>
            </div>
          )}
        </div>

        <p className="text-xs text-zinc-600">
          This window will proceed automatically upon secure token verification.
        </p>
      </div>
    </div>
  );
};
