import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * ProtectedRoute Component
 * Restricts access to authenticated users only.
 * Unauthenticated requests are redirected with location state to allow graceful login-back.
 */
export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  // If AuthContext is still fetching or verifying state, show beautiful loading spinner
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen w-full bg-[#0d0d0d] text-zinc-405 font-sans select-none gap-4">
        <div className="relative flex items-center justify-center">
          {/* Custom pulsing and rotating loaders */}
          <Loader2 className="w-10 h-10 text-emerald-400 animate-spin" />
          <div className="absolute w-14 h-14 border border-emerald-500/20 rounded-full animate-ping opacity-75" />
        </div>
        <div className="flex flex-col items-center gap-1 text-center">
          <h2 className="text-sm font-bold text-white tracking-widest uppercase font-mono">Securing Gateway</h2>
          <p className="text-xs text-zinc-500 font-mono">Webnixo Proxy Sandbox Isolation Active...</p>
        </div>
      </div>
    );
  }

  // If no user is logged in, redirect them to the /login page
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // User is authenticated, proceed to render protected node children
  return <>{children}</>;
};
