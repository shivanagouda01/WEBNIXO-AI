import React, { useState, useEffect } from "react";
import { 
  Image as ImageIcon, 
  Sparkles, 
  Download, 
  Maximize2, 
  RefreshCw, 
  Sliders, 
  Grid, 
  Trash2, 
  Layers, 
  Zap, 
  CheckCircle2, 
  Info, 
  Eye, 
  Copy, 
  Check 
} from "lucide-react";

interface SavedGeneration {
  id: string;
  prompt: string;
  url: string;
  model: string;
  aspectRatio: string;
  artStyle: string;
  cfgScale: number;
  steps: number;
  seed: number;
  createdAt: string;
}

const IMAGE_MODELS = [
  {
    id: "nano-banana-flux",
    name: "Nano Banana FLUX 2.4-Meme",
    description: "Highly responsive, witty, and pop-culture optimized. Excels at high-contrast layouts and amusing graphic novel aesthetics.",
    badge: "Experimental",
    accent: "border-yellow-500/30 text-yellow-500 bg-yellow-500/5 hover:border-yellow-500/50"
  },
  {
    id: "imagen-3-ultra",
    name: "Google Imagen 3 Ultra",
    description: "Google's flagship generative studio. Superior photorealistic precision, crisp edges, and stellar text integration.",
    badge: "Pro",
    accent: "border-indigo-500/30 text-indigo-400 bg-indigo-500/5 hover:border-indigo-500/50"
  },
  {
    id: "dalle-3-turbo",
    name: "DALL-E 3 Turbo",
    description: "OpenAI's legendary designer. Handles descriptive, verbose prompts with master-class structural planning and vectors.",
    badge: "OpenAI",
    accent: "border-emerald-500/30 text-emerald-400 bg-emerald-500/5 hover:border-emerald-500/50"
  },
  {
    id: "midjourney-v6",
    name: "Midjourney v6 Core",
    description: "Legendary artistic capability. Excels at cinematically-lit portraits, fantasy worldbuilding, and detailed oil textures.",
    badge: "Artistic",
    accent: "border-purple-500/30 text-purple-400 bg-purple-500/5 hover:border-purple-500/50"
  },
  {
    id: "sdxl-3.5",
    name: "Stable Diffusion XL 3.5",
    description: "Open-weights powerhouse. Supports infinite customizable stylings, highly detailed backgrounds, and digital illustrations.",
    badge: "OpenSource",
    accent: "border-sky-500/30 text-sky-400 bg-sky-500/5 hover:border-sky-500/50"
  }
];

const ASPECT_RATIOS = [
  { label: "1:1 Square", value: "1:1", desc: "Profile / Avatars" },
  { label: "16:9 Landscape", value: "16:9", desc: "Web Headers" },
  { label: "9:16 Portrait", value: "9:16", desc: "Stories / Reels" },
  { label: "4:3 Standard", value: "4:3", desc: "Feature Thumbnails" },
  { label: "3:4 Editorial", value: "3:4", desc: "Product Cards" }
];

const ART_STYLES = [
  { id: "realistic", name: "Cinematic Realistic", suffix: ", photorealistic portrait, sharp focus, 8k resolution, cinematic lighting, hyper-detailed" },
  { id: "watercolor", name: "Dreamy Watercolor", suffix: ", watercolor sketch, soft washes of color, detailed ink linework, organic textures, hand-painted" },
  { id: "cyberpunk", name: "Cyberpunk Neon", suffix: ", cyberpunk aesthetic, vivid neon lights, dark gloomy background, rain-slicked concrete, high futuristic detail" },
  { id: "pixar", name: "3D Cartoon Pixar", suffix: ", isometric 3d render, adorable claymation style, colorful background, cute character design, warm ambient occlusion" },
  { id: "lineart", name: "Minimalist Line Art", suffix: ", clean vector outline, minimalist, high contrast, elegant continuous line typography, white background" },
  { id: "retro", name: "Retro Pixel-Art", suffix: ", cute 16-bit pixel art, vibrant color palettes, classic arcade styling, retro indie video-game scene" },
  { id: "steampunk", name: "Steampunk Brass", suffix: ", steampunk clockwork gears, brass pipes, atmospheric smoke, coppery highlights, vintage mechanical details" },
  { id: "oil", name: "Impressionist Oil", suffix: ", classical oil painting texture, thick paint strokes, dramatic lighting, expressive impasto canvas style" }
];

// Beautiful high quality image catalog to represent amazing seed-based outcomes
const INSPIRED_PROMPTS_GALLERY = [
  {
    prompt: "A neon-glowing cybernetic banana core on an isometric testing platform, laboratory aesthetic",
    url: "https://images.unsplash.com/photo-1566371486490-560ded239fe6?q=80&w=800&auto=format&fit=crop",
    model: "nano-banana-flux",
    aspectRatio: "1:1",
    artStyle: "cyberpunk"
  },
  {
    prompt: "A beautiful hidden wood-paneled tea house nestled beside a rushing river in Kyoto, during peak autumn",
    url: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=800&auto=format&fit=crop",
    model: "imagen-3-ultra",
    aspectRatio: "16:9",
    artStyle: "realistic"
  },
  {
    prompt: "An majestic owl dressed as a Victorian scholar analyzing celestial charts, cozy oil painting",
    url: "https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=800&auto=format&fit=crop",
    model: "midjourney-v6",
    aspectRatio: "3:4",
    artStyle: "oil"
  }
];

interface ImageStudioProps {
  userEmail?: string;
}

export function ImageStudio({ userEmail }: ImageStudioProps) {
  const [prompt, setPrompt] = useState("");
  const [selectedModel, setSelectedModel] = useState("nano-banana-flux");
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [artStyle, setArtStyle] = useState("");
  const [cfgScale, setCfgScale] = useState(7.5);
  const [steps, setSteps] = useState(30);
  const [seed, setSeed] = useState(42069);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Loading pipeline stages
  const [pipelineStage, setPipelineStage] = useState(0);
  const [pipelineText, setPipelineText] = useState("");

  const [savedGallery, setSavedGallery] = useState<SavedGeneration[]>([]);
  const [selectedImage, setSelectedImage] = useState<SavedGeneration | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Load and pre-populate gallery
  useEffect(() => {
    if (userEmail) {
      const loadFromDb = async () => {
        try {
          const res = await fetch(`/api/generations?email=${encodeURIComponent(userEmail)}`);
          if (res.ok) {
            const data = await res.json();
            if (Array.isArray(data) && data.length > 0) {
              const mapped = data.map((item: any) => ({
                id: item.id,
                prompt: item.prompt,
                url: item.url,
                model: item.model,
                aspectRatio: item.aspectRatio || item.aspect_ratio,
                artStyle: item.artStyle || item.art_style,
                cfgScale: Number(item.cfgScale || item.cfg_scale) || 7.5,
                steps: item.steps || 30,
                seed: item.seed || 12345,
                createdAt: item.createdAt || item.created_at
              }));
              setSavedGallery(mapped);
              return;
            }
          }
          // Fallback if no DB images exist but local storage has some
          const saved = localStorage.getItem("webnixo_images");
          if (saved) {
            const parsed = JSON.parse(saved);
            setSavedGallery(parsed);
            for (const img of parsed) {
              await fetch("/api/generations", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ generation: img, email: userEmail })
              });
            }
          }
        } catch (e) {
          console.error("Failed to load saved visual assets from DB:", e);
        }
      };
      loadFromDb();
    } else {
      const saved = localStorage.getItem("webnixo_images");
      if (saved) {
        try {
          setSavedGallery(JSON.parse(saved));
        } catch (e) {
          console.error("Failed to parse saved visual assets:", e);
        }
      } else {
        // Prepopulate default gallery
        const defaults: SavedGeneration[] = INSPIRED_PROMPTS_GALLERY.map((item, idx) => ({
          id: `img-default-${idx}`,
          prompt: item.prompt,
          url: item.url,
          model: item.model,
          aspectRatio: item.aspectRatio,
          artStyle: item.artStyle,
          cfgScale: 7.5,
          steps: 30,
          seed: Math.floor(Math.random() * 99999),
          createdAt: new Date(Date.now() - (idx + 1) * 3600000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }));
        setSavedGallery(defaults);
        localStorage.setItem("webnixo_images", JSON.stringify(defaults));
      }
    }
  }, [userEmail]);

  // Function to randomize seed
  const randomizeSeed = () => {
    setSeed(Math.floor(Math.random() * 999999));
  };

  // Enhance prompt with additional artistic keywords
  const handleEnhancePrompt = () => {
    if (!prompt.trim()) return;
    setIsEnhancing(true);
    setTimeout(() => {
      let suffix = "";
      if (selectedModel === "nano-banana-flux") {
        suffix = ", vibrant yellow accents, stylized cartoon sticker design, whimsical organic pop art, highly detailed, bold black outlines, 8k render, banana-themed";
      } else {
        suffix = ", hyper-realistic, intricate details, moody ambient light cast, golden hour atmospheric volumetric lighting, cinematic photography framing";
      }
      setPrompt(prev => prev.trim() + suffix);
      setIsEnhancing(false);
    }, 850);
  };

  // Pipeline simulation stages
  const pipelineStages = [
    "Analyzing text prompt vectors & intent...",
    `Loading structural weights for model [${selectedModel.toUpperCase()}]...`,
    "Evaluating prompt style weight matrices...",
    "Running latent denoising steps (10/50)...",
    "Running latent denoising steps (30/50)...",
    "Up-scaling resolution buffer to fit " + aspectRatio + " aspect ratio...",
    "Formatting output visual metadata container...",
    "Compilation completed. Exporting image matrix..."
  ];

  // Map user query to premium Unsplash tags for amazing real outcomes
  const generateVisualAsset = () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    setPipelineStage(0);
    setPipelineText(pipelineStages[0]);

    // Fast pipeline progression
    let currentStage = 0;
    const interval = setInterval(() => {
      currentStage++;
      if (currentStage < pipelineStages.length) {
        setPipelineStage(currentStage);
        setPipelineText(pipelineStages[currentStage]);
      } else {
        clearInterval(interval);
        finalizeGeneration();
      }
    }, 600);
  };

  const finalizeGeneration = () => {
    // Pick dimensions based on aspect ratio
    let w = 512;
    let h = 512;
    if (aspectRatio === "16:9") { w = 768; h = 432; }
    else if (aspectRatio === "9:16") { w = 432; h = 768; }
    else if (aspectRatio === "4:3") { w = 640; h = 480; }
    else if (aspectRatio === "3:4") { w = 480; h = 640; }

    // Apply the chosen style suffix to the prompt for records
    const finalStyle = ART_STYLES.find(s => s.id === artStyle);
    const finalPromptText = prompt + (finalStyle ? finalStyle.suffix : "");

    // Real-time Pollinations AI Generative Forge matching prompt exactly
    const generatedUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(finalPromptText)}?width=${w}&height=${h}&seed=${seed}&nologo=true`;

    const newGen: SavedGeneration = {
      id: `img-${Date.now()}`,
      prompt: finalPromptText,
      url: generatedUrl,
      model: selectedModel,
      aspectRatio: aspectRatio,
      artStyle: artStyle || "none",
      cfgScale: cfgScale,
      steps: steps,
      seed: seed,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedGallery = [newGen, ...savedGallery];
    setSavedGallery(updatedGallery);
    localStorage.setItem("webnixo_images", JSON.stringify(updatedGallery));

    if (userEmail) {
      fetch("/api/generations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ generation: newGen, email: userEmail })
      }).catch(err => console.error("Failed to save asset to database:", err));
    }

    // Reset generator parameters
    setIsGenerating(false);
    setSelectedImage(newGen);
  };

  const deleteGeneration = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedGallery.filter(img => img.id !== id);
    setSavedGallery(updated);
    localStorage.setItem("webnixo_images", JSON.stringify(updated));
    if (selectedImage?.id === id) {
      setSelectedImage(null);
    }
    if (userEmail) {
      fetch(`/api/generations/${id}?email=${encodeURIComponent(userEmail)}`, {
        method: "DELETE"
      }).catch(err => console.error("Failed to delete asset from database:", err));
    }
  };

  const handleCopyPrompt = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = async (img: SavedGeneration) => {
    try {
      // Open in broad safe new window or fetch as blob
      const link = document.createElement("a");
      link.href = img.url;
      link.target = "_blank";
      link.download = `webnixo-creation-${img.id}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      window.open(img.url, "_blank");
    }
  };

  const handleReuseSettings = (img: SavedGeneration) => {
    // Extract base prompt if there was a suffix
    let basePrompt = img.prompt;
    ART_STYLES.forEach(style => {
      if (basePrompt.endsWith(style.suffix)) {
        basePrompt = basePrompt.replace(style.suffix, "");
      }
    });

    setPrompt(basePrompt);
    setSelectedModel(img.model);
    setAspectRatio(img.aspectRatio);
    setArtStyle(img.artStyle === "none" ? "" : img.artStyle);
    setCfgScale(img.cfgScale);
    setSteps(img.steps);
    setSeed(img.seed);
    setSelectedImage(null);
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden bg-[#0a0a0a]">
      
      {/* LEFT COLUMN: CONTROLS & PARAMS PANEL */}
      <div className="w-full md:w-[360px] border-b md:border-b-0 md:border-r border-zinc-900 bg-[#0d0d0d] flex-shrink-0 flex flex-col h-1/2 md:h-full overflow-y-auto">
        <div className="p-4 border-b border-zinc-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-500">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white">Pixel Forge</h2>
              <p className="text-[10px] text-zinc-550">Synthesizer Studio</p>
            </div>
          </div>
          <span className="text-[10px] bg-yellow-400/10 text-yellow-400 font-bold border border-yellow-400/20 px-2 py-0.5 rounded-full uppercase tracking-wider">
            Active
          </span>
        </div>

        <div className="p-4 space-y-5 flex-1">
          
          {/* Main User prompt textbox */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest">
                Describe your image
              </label>
              <button 
                onClick={handleEnhancePrompt}
                disabled={!prompt.trim() || isEnhancing}
                className="text-[10px] text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-40"
                title="Boost your inputs with descriptors"
              >
                <Zap className="h-3 w-3" />
                <span>{isEnhancing ? "Boosting..." : "Enhance"}</span>
              </button>
            </div>

            <div className="relative">
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="A high-contrast neon banana reflecting in dark chrome, pixel art vectors..."
                className="w-full p-3 h-24 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-zinc-700 outline-none text-xs text-zinc-200 placeholder-zinc-550 resize-none leading-relaxed transition-all focus:ring-1 focus:ring-indigo-500/20"
              />
              {prompt && (
                <button 
                  onClick={() => setPrompt("")}
                  className="absolute right-2 bottom-2 p-1 hover:bg-zinc-900 text-zinc-500 transition-colors rounded-md"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Core Generative Model dropdown select */}
          <div className="space-y-2">
            <label className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest block">
              Generative Engine / AI Model
            </label>
            <div className="space-y-1.5">
              {IMAGE_MODELS.map((model) => {
                const isSelected = selectedModel === model.id;
                return (
                  <button
                    key={model.id}
                    onClick={() => setSelectedModel(model.id)}
                    className={`w-full p-2.5 rounded-xl border text-left text-xs transition-all relative flex flex-col justify-between cursor-pointer ${
                      isSelected 
                        ? `bg-zinc-900 border-zinc-700 shadow-md ${model.accent}` 
                        : "bg-zinc-950 border-zinc-900 hover:border-zinc-800 text-zinc-400"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className={`font-semibold ${isSelected ? "text-white" : "text-zinc-300"}`}>
                        {model.name}
                      </span>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        isSelected ? "bg-zinc-800 text-white border border-zinc-700" : "bg-zinc-900/60 text-zinc-500"
                      }`}>
                        {model.badge}
                      </span>
                    </div>
                    {isSelected && (
                      <p className="text-[10px] text-zinc-400 mt-1 lines-clamp-2 leading-relaxed">
                        {model.description}
                      </p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Aspect Ratios triggers list */}
          <div className="space-y-2">
            <label className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest block">
              Aspect Ratio
            </label>
            <div className="grid grid-cols-5 gap-1.5">
              {ASPECT_RATIOS.map((ratio) => {
                const isSelected = aspectRatio === ratio.value;
                return (
                  <button
                    key={ratio.value}
                    onClick={() => setAspectRatio(ratio.value)}
                    className={`p-2 rounded-lg border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                      isSelected 
                        ? "bg-zinc-900 border-indigo-500/50 text-indigo-400 font-semibold" 
                        : "bg-zinc-950 border-zinc-900 text-zinc-400 hover:border-zinc-800 hover:text-white"
                    }`}
                    title={ratio.desc}
                  >
                    <span className="text-[11px] font-mono block">{ratio.value}</span>
                    <span className="text-[8px] text-zinc-500 truncate block scale-90 w-full">{ratio.label.split(" ")[1]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Style presets grid */}
          <div className="space-y-2">
            <label className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest block">
              Aesthetic Theme Style
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => setArtStyle("")}
                className={`p-2 rounded-xl text-left text-xs border truncate cursor-pointer transition-colors ${
                  artStyle === "" 
                    ? "bg-zinc-900 border-zinc-700 text-white font-medium shadow-sm" 
                    : "bg-zinc-950 border-zinc-900 text-zinc-400 hover:text-white"
                }`}
              >
                None (Standard)
              </button>
              {ART_STYLES.map((style) => {
                const isSelected = artStyle === style.id;
                return (
                  <button
                    key={style.id}
                    onClick={() => setArtStyle(style.id)}
                    className={`p-2 rounded-xl text-left text-xs border truncate cursor-pointer transition-colors ${
                      isSelected 
                        ? "bg-zinc-900 border-zinc-700 text-white font-medium shadow-sm" 
                        : "bg-zinc-950 border-zinc-900 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {style.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Advanced Sliders segment */}
          <div className="space-y-4 pt-2 border-t border-zinc-900">
            <h3 className="text-[10px] font-bold text-zinc-550 uppercase tracking-widest flex items-center gap-1.5">
              <Sliders className="h-3 w-3" />
              <span>Advanced Synth Pipeline Parameters</span>
            </h3>

            {/* CFG Scale */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-400 font-medium">Prompt Guidance (CFG Scale)</span>
                <span className="text-indigo-400 font-mono font-semibold">{cfgScale}</span>
              </div>
              <input 
                type="range"
                min="1"
                max="20"
                step="0.5"
                value={cfgScale}
                onChange={(e) => setCfgScale(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 h-1 bg-zinc-800 rounded-lg outline-none cursor-pointer"
              />
              <p className="text-[9px] text-zinc-550">Higher forces adherence to input words literal alignment.</p>
            </div>

            {/* Steps */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-400 font-medium">Sampling Steps</span>
                <span className="text-indigo-400 font-mono font-semibold">{steps}</span>
              </div>
              <input 
                type="range"
                min="10"
                max="150"
                step="5"
                value={steps}
                onChange={(e) => setSteps(parseInt(e.target.value))}
                className="w-full accent-indigo-500 h-1 bg-zinc-800 rounded-lg outline-none cursor-pointer"
              />
              <p className="text-[9px] text-zinc-550">More cycles yield refined details but lengthens matrix processing.</p>
            </div>

            {/* Seed */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-400 font-medium font-sans">Denoising Seed</span>
                <button 
                  onClick={randomizeSeed}
                  className="text-[10px] text-zinc-500 hover:text-indigo-400 font-semibold cursor-pointer"
                >
                  Randomize
                </button>
              </div>
              <input 
                type="number"
                value={seed}
                onChange={(e) => setSeed(parseInt(e.target.value) || 0)}
                className="w-full p-2 h-8 rounded-lg bg-zinc-950 border border-zinc-800 outline-none text-xs text-zinc-300 font-mono text-center focus:border-zinc-700"
              />
            </div>

          </div>

        </div>

        {/* Generate triggers section */}
        <div className="p-4 border-t border-zinc-900 bg-zinc-950/70 sticky bottom-0 z-20">
          <button 
            onClick={generateVisualAsset}
            disabled={!prompt.trim() || isGenerating}
            className="w-full py-3 px-4 rounded-xl bg-yellow-500 hover:bg-yellow-400 disabled:bg-zinc-800 disabled:text-zinc-500 text-zinc-950 text-sm font-bold tracking-wide transition-all shadow-lg shadow-yellow-500/5 flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin text-zinc-950" />
                <span>Forging Matrix...</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 text-zinc-950 fill-zinc-950/20 animate-pulse" />
                <span>Generate Asset with {IMAGE_MODELS.find(m => m.id === selectedModel)?.name.split(" ")[0]}</span>
              </>
            )}
          </button>
        </div>

      </div>

      {/* RIGHT COLUMN: ACTIVE OUTPUT STREAM & CHRONOLOGICAL HISTORY GALLERY */}
      <div className="flex-1 flex flex-col h-1/2 md:h-full bg-[#0a0a0a] overflow-hidden min-w-0">
        
        {/* Gallery Subheader / Stats bar */}
        <div className="p-4 border-b border-zinc-900 flex items-center justify-between bg-[#0d0d0d]">
          <div className="flex items-center gap-2">
            <Grid className="h-4 w-4 text-indigo-400" />
            <h3 className="text-xs font-semibold text-white tracking-wider uppercase font-display">
              Saved Masterpieces Directory ({savedGallery.length})
            </h3>
          </div>
          <div className="text-[10px] text-zinc-500 font-mono">
            Requires active local storage caching
          </div>
        </div>

        {/* Primary Screen Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-8 relative">
          
          {/* Active Generation Loader / Focus Window */}
          {isGenerating ? (
            <div className="p-8 rounded-2xl bg-zinc-950 border border-zinc-900 max-w-2xl mx-auto flex flex-col items-center justify-center space-y-6 text-center shadow-2xl relative overflow-hidden animate-pulse">
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-yellow-500/5 to-indigo-500/5 opacity-45"></div>
              
              <div className="relative w-16 h-16 rounded-full border-2 border-indigo-500/20 flex items-center justify-center bg-indigo-500/10">
                <RefreshCw className="h-8 w-8 text-indigo-400 animate-spin" />
              </div>

              <div className="space-y-2 relative z-10">
                <span className="text-[10px] tracking-wider bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 px-3 py-1 rounded-full uppercase font-bold">
                  Stage {pipelineStage + 1} of 8
                </span>
                <p className="text-zinc-200 text-sm font-mono mt-2 min-h-[20px]">
                  {pipelineText}
                </p>
                <div className="w-56 h-1.5 bg-zinc-900 rounded-full overflow-hidden mx-auto border border-zinc-850">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 to-yellow-500 transition-all duration-300 rounded-full" 
                    style={{ width: `${((pipelineStage + 1) / 8) * 100}%` }}
                  />
                </div>
              </div>

              <div className="text-[11px] text-zinc-500 font-sans max-w-sm">
                Compiling multi-layered graphic representations at {aspectRatio} using guidance matrix {cfgScale}. This mock GPU pipeline is simulating model outputs.
              </div>
            </div>
          ) : selectedImage ? (
            
            /* DYNAMICALLY EXPANDED DETAIL VIEW */
            <div className="max-w-4xl mx-auto rounded-3xl bg-zinc-950 border border-zinc-900/80 shadow-2xl overflow-hidden animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-12">
                
                {/* Image side */}
                <div className="md:col-span-7 bg-[#0f0f0f] flex items-center justify-center p-3 md:p-6 border-b md:border-b-0 md:border-r border-zinc-900 relative group">
                  <img 
                    src={selectedImage.url} 
                    alt={selectedImage.prompt} 
                    referrerPolicy="no-referrer"
                    className="rounded-2xl shadow-xl max-h-[460px] object-contain w-full transition-transform duration-300 group-hover:scale-[1.01]"
                  />
                  <div className="absolute top-6 right-6 flex gap-1.5 md:opacity-0 md:group-hover:opacity-100 opacity-100 transition-opacity">
                    <button 
                      onClick={() => handleCopyPrompt(selectedImage.prompt, selectedImage.id)}
                      className="p-2 cursor-pointer bg-black/70 backdrop-blur-md text-white rounded-lg hover:bg-black/90 transition-all"
                      title="Copy prompt text"
                    >
                      {copiedId === selectedImage.id ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                    </button>
                    <button 
                      onClick={() => handleDownload(selectedImage)}
                      className="p-2 cursor-pointer bg-black/70 backdrop-blur-md text-white rounded-lg hover:bg-black/90 transition-all"
                      title="Native High-Res Download"
                    >
                      <Download className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Metadata Side */}
                <div className="md:col-span-5 p-6 flex flex-col justify-between space-y-6">
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-zinc-500 tracking-widest block">
                        Masterpiece Metadata
                      </span>
                      <button 
                        onClick={() => setSelectedImage(null)}
                        className="text-xs text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-900 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                      >
                        Minimize
                      </button>
                    </div>

                    <div className="space-y-1.5">
                      <h4 className="text-xs font-semibold text-zinc-400">Prompt</h4>
                      <p className="text-xs text-zinc-200 leading-relaxed bg-[#0d0d0d] p-3 rounded-xl border border-zinc-900/60 font-medium italic">
                        &quot;{selectedImage.prompt}&quot;
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <div className="p-2.5 rounded-xl bg-[#0d0d0d] border border-zinc-900/50">
                        <span className="text-[9px] text-zinc-550 uppercase tracking-widest block font-bold">Aesthetic style</span>
                        <span className="text-xs text-zinc-300 font-semibold uppercase">{selectedImage.artStyle || "None"}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0d0d0d] border border-zinc-900/50">
                        <span className="text-[9px] text-zinc-550 uppercase tracking-widest block font-bold">Aspect Proportions</span>
                        <span className="text-xs text-zinc-300 font-semibold">{selectedImage.aspectRatio}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0d0d0d] border border-zinc-900/50">
                        <span className="text-[9px] text-zinc-550 uppercase tracking-widest block font-bold">CFG guidance</span>
                        <span className="text-xs text-zinc-300 font-semibold font-mono">{selectedImage.cfgScale}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0d0d0d] border border-zinc-900/50">
                        <span className="text-[9px] text-zinc-550 uppercase tracking-widest block font-bold">Denoise steps</span>
                        <span className="text-xs text-zinc-300 font-semibold font-mono">{selectedImage.steps}</span>
                      </div>
                    </div>

                    <div className="p-3 bg-[#0d0d0d] rounded-xl border border-zinc-900/50 flex items-center justify-between text-xs">
                      <div className="flex flex-col">
                        <span className="text-[9px] text-zinc-550 uppercase tracking-widest font-bold">Engine Seed ID</span>
                        <span className="text-zinc-350 font-mono text-[11px] font-semibold">{selectedImage.seed}</span>
                      </div>
                      <span className="text-[10px] text-zinc-500">Model: {selectedImage.model.toUpperCase()}</span>
                    </div>

                    <div className="text-[10px] text-zinc-550 flex items-center gap-1.5">
                      <Info className="h-3 w-3 text-indigo-400" />
                      <span>Forged on server cluster at {selectedImage.createdAt}</span>
                    </div>

                  </div>

                  <div className="pt-4 border-t border-zinc-905 flex items-center gap-2">
                    <button 
                      onClick={() => handleReuseSettings(selectedImage)}
                      className="flex-1 py-2 px-3 rounded-lg bg-[#212121] hover:bg-zinc-800 text-white text-xs font-semibold text-center cursor-pointer transition-colors border border-zinc-800"
                    >
                      Reuse Synthesis Configurations
                    </button>
                    <button 
                      onClick={(e) => deleteGeneration(selectedImage.id, e)}
                      className="p-2 hover:bg-red-500/10 text-zinc-500 hover:text-red-400 rounded-lg transition-colors border border-zinc-900 hover:border-red-500/25 cursor-pointer"
                      title="Delete asset"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                </div>
              </div>
            </div>

          ) : null}

          {/* Master Directory Grid Gallery */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest">
                Explore Your Gallery Collection
              </h4>
              {savedGallery.length > 0 && (
                <button 
                  onClick={() => {
                    if (window.confirm("Do you want to wipe clean your entire generated image gallery? This works irreversibly.")) {
                      setSavedGallery([]);
                      localStorage.removeItem("webnixo_images");
                      setSelectedImage(null);
                      if (userEmail) {
                        fetch(`/api/generations?email=${encodeURIComponent(userEmail)}`, {
                          method: "DELETE"
                        }).catch(err => console.error("Failed to clear directory from database:", err));
                      }
                    }
                  }}
                  className="text-[10px] text-zinc-650 hover:text-red-400 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Trash2 className="h-3 w-3" />
                  <span>Clear Saved Directory</span>
                </button>
              )}
            </div>

            {savedGallery.length === 0 ? (
              <div className="p-12 text-center rounded-2xl bg-zinc-950 border border-zinc-900 space-y-3">
                <ImageIcon className="h-8 w-8 text-zinc-600 mx-auto" />
                <h5 className="text-zinc-300 font-semibold text-sm">Your visual cabinet is empty</h5>
                <p className="text-zinc-550 text-xs max-w-sm mx-auto leading-relaxed">
                  Start writing prompts in the left configuration workspace to build real-time visual streams with pixel forge.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {savedGallery.map((img) => (
                  <div 
                    key={img.id}
                    onClick={() => setSelectedImage(img)}
                    className={`group/card rounded-2xl bg-[#0d0d0d] border overflow-hidden cursor-pointer transition-all hover:-translate-y-1 relative aspect-square ${
                      selectedImage?.id === img.id ? "border-indigo-500 ring-2 ring-indigo-500/20 shadow-lg" : "border-zinc-900 hover:border-zinc-800"
                    }`}
                  >
                    <img 
                      src={img.url} 
                      alt={img.prompt} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-300 group-hover/card:scale-105"
                      loading="lazy"
                    />
                    
                    {/* Hover detail masking overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent md:opacity-0 md:group-hover/card:opacity-100 opacity-80 pointer-events-none transition-all flex flex-col justify-end p-3 space-y-1.5">
                      <span className="text-[10px] font-mono text-indigo-400 font-bold block">{img.model.toUpperCase()}</span>
                      <p className="text-[10px] text-zinc-200 line-clamp-2 leading-snug font-medium italic">
                        &quot;{img.prompt}&quot;
                      </p>
                      
                      <div className="flex items-center justify-between pt-1 text-[8px] text-zinc-500 font-mono border-t border-zinc-800">
                        <span>Aspect: {img.aspectRatio}</span>
                        <span>{img.createdAt}</span>
                      </div>
                    </div>

                    {/* Simple quick actions overlay corner indicators */}
                    <div className="absolute top-2 right-2 flex gap-1 transform md:translate-y-1 md:opacity-0 md:group-hover/card:opacity-100 md:group-hover/card:translate-y-0 translate-y-0 opacity-100 transition-all">
                      <button 
                        onClick={(e) => { e.stopPropagation(); setSelectedImage(img); }}
                        className="p-1.5 rounded-lg bg-black/60 shadow-lg border border-zinc-800 backdrop-blur-md text-white hover:bg-black"
                        title="Display credentials"
                      >
                        <Eye className="h-3 w-3" />
                      </button>
                      <button 
                        onClick={(e) => deleteGeneration(img.id, e)}
                        className="p-1.5 rounded-lg bg-black/60 shadow-lg border border-zinc-800 backdrop-blur-md text-zinc-400 hover:text-red-404 hover:bg-black"
                        title="Delete visual asset"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
