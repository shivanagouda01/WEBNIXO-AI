import React, { useState } from "react";
import { Check, Copy } from "lucide-react";

interface CopyButtonProps {
  text: string;
}

const CopyButton: React.FC<CopyButtonProps> = ({ text }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy text: ", err);
    }
  };

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200 transition-colors bg-zinc-800/60 hover:bg-zinc-800 px-2.5 py-1 rounded-md border border-zinc-700/50"
      title="Copy to clipboard"
    >
      {copied ? (
        <>
          <Check className="h-3 w-3 text-emerald-400" />
          <span className="text-emerald-400 font-medium">Copied!</span>
        </>
      ) : (
        <>
          <Copy className="h-3 w-3" />
          <span>Copy</span>
        </>
      )}
    </button>
  );
};

export function MarkdownRenderer({ content }: { content: string }) {
  if (!content) return null;

  // Split content by code blocks: ```lang\ncode```
  const blocks = content.split(/(```[\s\S]*?```)/g);

  return (
    <div id="markdown-container" className="space-y-4 text-zinc-100 leading-relaxed font-sans text-sm md:text-[15px]">
      {blocks.map((block, index) => {
        // Render a code block
        if (block.startsWith("```") && block.endsWith("```")) {
          const rawCode = block.slice(3, -3);
          const firstNewLineIndex = rawCode.indexOf("\n");
          let language = "code";
          let codeText = rawCode;

          if (firstNewLineIndex !== -1) {
            language = rawCode.slice(0, firstNewLineIndex).trim() || "code";
            codeText = rawCode.slice(firstNewLineIndex + 1);
          }

          return (
            <div key={index} className="my-5 rounded-lg border border-zinc-800 bg-[#0d0d0d] overflow-hidden shadow-md">
              {/* Header bar of the code block */}
              <div className="flex items-center justify-between px-4 py-2 bg-zinc-900 border-b border-zinc-800/80">
                <span className="text-xs font-mono text-zinc-400 uppercase tracking-wider">{language}</span>
                <CopyButton text={codeText.trim()} />
              </div>
              {/* Content of the code block */}
              <pre className="p-4 overflow-x-auto text-zinc-200 font-mono text-[13px] leading-relaxed bg-[#0d0d0d]">
                <code>{codeText.trim()}</code>
              </pre>
            </div>
          );
        }

        // Render standard prose blocks
        return (
          <div key={index} className="space-y-3">
            {block.split("\n\n").map((para, pIdx) => {
              const trimmed = para.trim();
              if (!trimmed) return null;

              // Render Headings
              if (trimmed.startsWith("# ")) {
                return (
                  <h1 key={pIdx} className="text-2xl font-bold font-display text-white mt-6 mb-2 tracking-tight">
                    {renderInline(trimmed.substring(2))}
                  </h1>
                );
              }
              if (trimmed.startsWith("## ")) {
                return (
                  <h2 key={pIdx} className="text-xl font-semibold font-display text-white mt-5 mb-2 tracking-tight">
                    {renderInline(trimmed.substring(3))}
                  </h2>
                );
              }
              if (trimmed.startsWith("### ")) {
                return (
                  <h3 key={pIdx} className="text-lg font-medium font-display text-white mt-4 mb-2 tracking-tight">
                    {renderInline(trimmed.substring(4))}
                  </h3>
                );
              }

              // Render Blockquotes
              if (trimmed.startsWith("> ")) {
                return (
                  <blockquote key={pIdx} className="border-l-4 border-zinc-500 bg-zinc-900/30 pl-4 py-1.5 pr-2 rounded-r italic text-zinc-300">
                    {renderInline(trimmed.substring(2))}
                  </blockquote>
                );
              }

              // Render Bullet Lists
              if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
                const items = trimmed.split(/\n[-*]\s+/);
                return (
                  <ul key={pIdx} className="list-disc pl-6 space-y-1.5 my-3 text-zinc-200">
                    {items.map((item, iIdx) => {
                      // Remove leading bullet if the split left it
                      const contentItem = iIdx === 0 ? item.replace(/^[-*]\s+/, "") : item;
                      return <li key={iIdx}>{renderInline(contentItem)}</li>;
                    })}
                  </ul>
                );
              }

              // Render Numbered Lists
              if (/^\d+\.\s+/.test(trimmed)) {
                const items = trimmed.split(/\n\d+\.\s+/);
                return (
                  <ol key={pIdx} className="list-decimal pl-6 space-y-1.5 my-3 text-zinc-200">
                    {items.map((item, iIdx) => {
                      const contentItem = iIdx === 0 ? item.replace(/^\d+\.\s+/, "") : item;
                      return <li key={iIdx}>{renderInline(contentItem)}</li>;
                    })}
                  </ol>
                );
              }

              // Render Tables (Basic Support)
              if (trimmed.includes("|") && trimmed.includes("-|-")) {
                const lines = trimmed.split("\n");
                const headers = lines[0].split("|").map(h => h.trim()).filter(Boolean);
                const rows = lines.slice(2).map(l => l.split("|").map(r => r.trim()).filter(Boolean)).filter(r => r.length > 0);

                return (
                  <div key={pIdx} className="overflow-x-auto my-4 rounded border border-zinc-800">
                    <table className="min-w-full divide-y divide-zinc-800 bg-zinc-900/20">
                      <thead className="bg-zinc-900">
                        <tr>
                          {headers.map((h, hIdx) => (
                            <th key={hIdx} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-zinc-300">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-800">
                        {rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-zinc-900/30 transition-colors">
                            {row.map((cell, cIdx) => (
                              <td key={cIdx} className="px-4 py-2 text-zinc-200 text-sm">
                                {renderInline(cell)}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              }

              // Normal paragraph text
              return (
                <p key={pIdx} className="text-zinc-200 leading-relaxed break-words">
                  {renderInline(trimmed)}
                </p>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

// Render Inline styles such as bold, italics, inline code highlights
function renderInline(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  let remainingText = text;
  let keyCounter = 0;

  // Let's parse with a standard inline processor
  // Bold match: **text**
  // Inline code match: `code`
  // A simplified parser that works line-by-line using index boundaries
  let i = 0;
  while (i < remainingText.length) {
    // 1. Check for inline code `` `code` ``
    if (remainingText[i] === "`") {
      const nextBacktick = remainingText.indexOf("`", i + 1);
      if (nextBacktick !== -1) {
        if (i > 0) {
          parts.push(remainingText.substring(0, i));
        }
        const codeVal = remainingText.substring(i + 1, nextBacktick);
        parts.push(
          <code key={`code-${keyCounter++}-${i}`} className="bg-zinc-800/80 text-zinc-100 font-mono text-xs px-1.5 py-0.5 rounded border border-zinc-700/40 animate-fade-in">
            {codeVal}
          </code>
        );
        remainingText = remainingText.substring(nextBacktick + 1);
        i = 0;
        continue;
      }
    }

    // 2. Check for bold `**bold**`
    if (remainingText.startsWith("**", i)) {
      const nextBold = remainingText.indexOf("**", i + 2);
      if (nextBold !== -1) {
        if (i > 0) {
          parts.push(remainingText.substring(0, i));
        }
        const boldVal = remainingText.substring(i + 2, nextBold);
        parts.push(
          <strong key={`bold-${keyCounter++}-${i}`} className="font-semibold text-white">
            {boldVal}
          </strong>
        );
        remainingText = remainingText.substring(nextBold + 2);
        i = 0;
        continue;
      }
    }

    i++;
  }

  if (remainingText.length > 0) {
    parts.push(remainingText);
  }

  return parts;
}
