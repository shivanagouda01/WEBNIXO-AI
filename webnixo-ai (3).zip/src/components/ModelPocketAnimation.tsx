import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Zap, Pocket } from "lucide-react";

interface ModelItem {
  id: string;
  name: string;
  company: string;
  logo: string;
  color: string;
  glowColor: string;
  angle: number; // in degrees
}

export const ModelPocketAnimation: React.FC = () => {
  const [animationPhase, setAnimationPhase] = useState<'orbit' | 'suck' | 'pulse' | 'reemerge'>('orbit');
  const [activeModel, setActiveModel] = useState<string | null>(null);
  const [showRipples, setShowRipples] = useState<boolean>(false);
  const [rotationOffset, setRotationOffset] = useState<number>(0);
  
  // Extra large model logo sizes and responsive radius coordinates
  const [dimensions, setDimensions] = useState({ radius: 310, centerSize: 150, logoSize: 100 });

  // Update layout sizes responsively for outstanding viewing on any device size
  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      if (width < 640) {
        // Mobile
        setDimensions({ radius: 135, centerSize: 95, logoSize: 64 });
      } else if (width < 1024) {
        // Tablet
        setDimensions({ radius: 220, centerSize: 125, logoSize: 84 });
      } else {
        // Desktop
        setDimensions({ radius: 310, centerSize: 155, logoSize: 100 });
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Continuous orbital rotation floating state
  useEffect(() => {
    let animationId: number;
    let lastTime = performance.now();

    const updateRotation = (time: number) => {
      const delta = (time - lastTime) / 1000;
      lastTime = time;

      // Models rotate elegantly in wide spaces - extra fast energized speed
      setRotationOffset((prev) => (prev + delta * 55) % 360);

      animationId = requestAnimationFrame(updateRotation);
    };

    animationId = requestAnimationFrame(updateRotation);
    return () => cancelAnimationFrame(animationId);
  }, []);

  // Infinite automated consolidation sequence with long rotation durations
  useEffect(() => {
    let timerPulse: NodeJS.Timeout | undefined;
    let timerClearRipples: NodeJS.Timeout | undefined;
    let timerReemerge: NodeJS.Timeout | undefined;
    let timerRest: NodeJS.Timeout | undefined;

    const runSequence = () => {
      // 1. Draw all models into the center with spiral torque
      setAnimationPhase("suck");

      // 2. Blast glowing shockwave waves when fully absorbed
      timerPulse = setTimeout(() => {
        setAnimationPhase("pulse");
        setShowRipples(true);
      }, 700);

      // 3. Calm physical space down
      timerClearRipples = setTimeout(() => {
        setShowRipples(false);
      }, 1500);

      // 4. Re-emerge nodes from pocket core safely
      timerReemerge = setTimeout(() => {
        setAnimationPhase("reemerge");
      }, 2300);

      // 5. Restore full interactive orbital rotation
      timerRest = setTimeout(() => {
        setAnimationPhase("orbit");
      }, 2900);
    };

    // Repeat the full automatic cycle every 22 seconds (allowing 19 seconds of nonstop beautiful rotation!)
    const intervalId = setInterval(runSequence, 22000);

    // Initial sequence trigger after 15 seconds
    const initialDelay = setTimeout(runSequence, 15000);

    return () => {
      clearInterval(intervalId);
      clearTimeout(initialDelay);
      if (timerPulse) clearTimeout(timerPulse);
      if (timerClearRipples) clearTimeout(timerClearRipples);
      if (timerReemerge) clearTimeout(timerReemerge);
      if (timerRest) clearTimeout(timerRest);
    };
  }, []);

  // 6 World-Class Advanced Generative AI Models with large sizes
  const models: ModelItem[] = [
    {
      id: "gemini",
      name: "Gemini 2.5 Pro",
      company: "Google Ultra",
      logo: "https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw",
      color: "rgba(59, 130, 246, 0.18)",
      glowColor: "rgba(59, 130, 246, 0.85)",
      angle: 0,
    },
    {
      id: "gpt4",
      name: "GPT-4o Enterprise",
      company: "OpenAI Labs",
      logo: "https://lh3.googleusercontent.com/d/1YwA9adPBxxiSJho0oitmi8eAxR_JZ5Q9",
      color: "rgba(16, 185, 129, 0.18)",
      glowColor: "rgba(16, 185, 129, 0.85)",
      angle: 60,
    },
    {
      id: "claude",
      name: "Claude 3.5 Sonnet",
      company: "Anthropic",
      logo: "https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m",
      color: "rgba(239, 104, 38, 0.18)",
      glowColor: "rgba(239, 104, 38, 0.85)",
      angle: 120,
    },
    {
      id: "deepseek",
      name: "DeepSeek-V3",
      company: "DeepSeek AI",
      logo: "https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa",
      color: "rgba(29, 78, 216, 0.18)",
      glowColor: "rgba(59, 130, 246, 0.85)",
      angle: 180,
    },
    {
      id: "llama",
      name: "Llama 3.2 Vision",
      company: "Meta OpenSource",
      logo: "https://lh3.googleusercontent.com/d/1Fbg0NTwHIIcYDrsMx66sE9PB1FbnpfvZ",
      color: "rgba(139, 92, 246, 0.18)",
      glowColor: "rgba(139, 92, 246, 0.85)",
      angle: 240,
    },
    {
      id: "qwen",
      name: "Qwen 2.5 Coder",
      company: "Alibaba Cloud",
      logo: "https://lh3.googleusercontent.com/d/1yfqzyKb6799thhOSIN7V7a_6V78mo57h",
      color: "rgba(217, 70, 239, 0.18)",
      glowColor: "rgba(217, 70, 239, 0.85)",
      angle: 300,
    },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto bg-[#07070a]/90 rounded-3xl p-6 sm:p-10 space-y-8 text-center relative overflow-hidden select-none shadow-2xl">
      
      {/* Premium ambient backdrop lines */}
      <div className="absolute inset-x-0 top-0 h-40 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.06)_0,rgba(0,0,0,0)_70%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none opacity-15" />

      {/* Header details */}
      <div className="space-y-3 relative z-10 max-w-3xl mx-auto">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono tracking-widest uppercase rounded-full">
          <Sparkles className="h-3 w-3 text-emerald-400" />
          Unmatched Value Singularity
        </span>
        <h3 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
          Stop Paying for Multiple Separate AI Subscriptions
        </h3>
        <p className="text-zinc-300 text-xs sm:text-base leading-relaxed max-w-2xl mx-auto font-sans">
          Connect seamlessly with GPT-4o, Claude 3.5, Gemini 2.5, ultra-fast Grok-2, and DeepSeek. Ask questions, analyze files, build crisp websites, and write content inside a clean, privacy-focused dashboard.
        </p>
      </div>

      {/* Outer View Canvas */}
      <div className="h-[390px] sm:h-[620px] lg:h-[780px] w-full flex items-center justify-center relative z-10 bg-[#050507] rounded-3xl overflow-hidden py-10">
        
        {/* Soft background orbit rings */}
        <div 
          className="absolute rounded-full border border-zinc-900/60 pointer-events-none transition-all duration-700"
          style={{ 
            width: dimensions.radius * 2, 
            height: dimensions.radius * 2,
            opacity: animationPhase === "suck" ? 0.05 : 0.65
          }} 
        />
        
        <div 
          className="absolute rounded-full border border-dashed border-zinc-950 pointer-events-none animate-spin"
          style={{ 
            width: dimensions.radius * 1.5, 
            height: dimensions.radius * 1.5,
            animationDuration: "60s"
          }} 
        />

        {/* Pulse Shockwave Ring Waves */}
        <AnimatePresence>
          {showRipples && (
            <>
              <motion.div 
                initial={{ scale: 0.7, opacity: 0.9 }}
                animate={{ scale: 2.9, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                className="absolute rounded-full border-2 border-emerald-500/50 bg-emerald-500/5 pointer-events-none z-0"
                style={{ width: dimensions.centerSize, height: dimensions.centerSize }}
              />
              <motion.div 
                initial={{ scale: 0.5, opacity: 0.9 }}
                animate={{ scale: 2.3, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.9, ease: "easeOut", delay: 0.2 }}
                className="absolute rounded-full border border-purple-500/60 bg-purple-500/5 pointer-events-none z-0"
                style={{ width: dimensions.centerSize, height: dimensions.centerSize }}
              />
              <motion.div 
                initial={{ scale: 0.9, opacity: 0.6 }}
                animate={{ scale: 3.6, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 2.2, ease: "easeOut", delay: 0.4 }}
                className="absolute rounded-full border border-indigo-400/25 pointer-events-none z-0"
                style={{ width: dimensions.centerSize, height: dimensions.centerSize }}
              />
            </>
          )}
        </AnimatePresence>

        {/* 6 AI SUPERCOMPUTING BRANDS orbiting continuously */}
        {models.map((m) => {
          const isSucked = animationPhase === "suck" || animationPhase === "pulse";
          const isReemerging = animationPhase === "reemerge";

          // Calculate current dynamically offset angles
          const currentAngle = (m.angle + rotationOffset) % 360;
          const angleRad = (currentAngle * Math.PI) / 180;
          
          // Outer radius float coordinates
          const targetX = dimensions.radius * Math.cos(angleRad);
          const targetY = dimensions.radius * Math.sin(angleRad);

          return (
            <motion.div
              key={m.id}
              initial={{ x: targetX, y: targetY, rotate: currentAngle, scale: 1, opacity: 1 }}
              animate={{
                x: isSucked ? 0 : targetX,
                y: isSucked ? 0 : targetY,
                rotate: isSucked ? currentAngle + 360 : currentAngle,
                scale: isSucked ? 0 : isReemerging ? [0.15, 1] : activeModel === m.id ? 1.12 : 1,
                opacity: isSucked ? 0 : isReemerging ? [0, 1] : 1,
              }}
              transition={{
                x: isSucked 
                  ? { type: "spring", stiffness: 120, damping: 18 } 
                  : { type: "tween", ease: "linear", duration: 0.01 },
                y: isSucked 
                  ? { type: "spring", stiffness: 120, damping: 18 } 
                  : { type: "tween", ease: "linear", duration: 0.01 },
                rotate: isSucked 
                  ? { type: "spring", stiffness: 120, damping: 18 } 
                  : { type: "tween", ease: "linear", duration: 0.01 },
                scale: { type: "spring", stiffness: 120, damping: 12 },
                opacity: { duration: 0.3 },
              }}
              onMouseEnter={() => {
                if (!isSucked) setActiveModel(m.id);
              }}
              onMouseLeave={() => {
                if (activeModel === m.id) setActiveModel(null);
              }}
              style={{
                width: dimensions.logoSize,
                height: dimensions.logoSize,
                backgroundColor: m.color,
                boxShadow: activeModel === m.id 
                  ? `0 0 35px ${m.glowColor}, inset 0 0 15px ${m.glowColor}` 
                  : `0 8px 30px rgba(0,0,0,0.5)`,
                left: `calc(50% - ${dimensions.logoSize / 2}px)`,
                top: `calc(50% - ${dimensions.logoSize / 2}px)`,
              }}
              className="absolute rounded-full border border-zinc-800/80 flex items-center justify-center p-4 sm:p-5 cursor-pointer backdrop-blur-md z-20 group select-none hover:border-zinc-700 hover:shadow-2xl"
            >
              {/* Massive model custom illustrations logo */}
              <img
                src={m.logo}
                alt={m.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter drop-shadow-lg select-none transition-transform duration-300 group-hover:scale-105 pointer-events-none"
              />

              {/* Float name identifier tags */}
              <AnimatePresence>
                {activeModel === m.id && !isSucked && (
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    style={{ backdropFilter: "blur(8px)" }}
                    className="absolute -bottom-14 left-1/2 -translate-x-1/2 bg-zinc-950/95 border border-zinc-800 text-white font-extrabold text-[11px] px-3 py-1.5 rounded-xl shadow-2xl whitespace-nowrap z-50 pointer-events-none uppercase font-mono tracking-wider"
                  >
                    {m.name} <span className="text-zinc-550 font-medium">by {m.company}</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}

        {/* CENTRAL WEBNIXO POCKET POWERCORE CORES */}
        <motion.div
          animate={{
            scale: animationPhase === "pulse" ? [1, 1.25, 0.95, 1.15, 1] : 1,
            rotate: animationPhase === "pulse" ? [0, -12, 15, -6, 0] : 0,
          }}
          transition={{ duration: 1.2, ease: "easeInOut" }}
          style={{
            width: dimensions.centerSize,
            height: dimensions.centerSize,
          }}
          className="absolute flex items-center justify-center z-30 group relative"
        >
          {/* Outer glowing hexagon border with animated pulse */}
          <div 
            className="absolute inset-0 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 animate-pulse transition-all duration-500"
            style={{
              clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
              boxShadow: "0 0 30px rgba(168, 85, 247, 0.4)"
            }}
          />
          {/* Inner dark hexagon space */}
          <div 
            className="absolute inset-[2px] bg-[#09090d] flex items-center justify-center p-4"
            style={{
              clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)"
            }}
          >
            {/* Pulsing neon state glow aura inside the inner space */}
            <div className="absolute inset-0 bg-indigo-500/10 animate-pulse blur-xl pointer-events-none" />

            {/* Central logo */}
            <img
              src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512"
              alt="Webnixo Core"
              referrerPolicy="no-referrer"
              className="w-4/5 h-4/5 object-contain relative z-10 filter drop-shadow-[0_0_20px_rgba(139,92,246,0.35)] select-none pointer-events-none"
            />
          </div>
        </motion.div>

      </div>

    </div>
  );
};
