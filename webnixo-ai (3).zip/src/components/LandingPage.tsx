import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { ModelPocketAnimation } from "./ModelPocketAnimation";
import {
  Compass,
  Terminal,
  Sparkles,
  Zap,
  Shield,
  Activity,
  Cpu,
  LogIn,
  UserPlus,
  ArrowRight,
  CheckCircle2,
  Lock,
  Mail,
  User,
  Info,
  Server,
  Key,
  Menu,
  X,
  HelpCircle,
  Search
} from "lucide-react";

export function LandingPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"home" | "features" | "pricing" | "advantages" | "security" | "faq">("home");
  const [activeSlide, setActiveSlide] = useState(0);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState<boolean>(false);

  // Landing Page FAQ Accordion States
  const [landingFaqSearchQuery, setLandingFaqSearchQuery] = useState("");
  const [openedLandingFaqIndex, setOpenedLandingFaqIndex] = useState<number | null>(null);

  // Discount Coupons & Affiliate Marketing States
  const [couponInput, setCouponInput] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState("");
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponError, setCouponError] = useState("");
  const [couponSuccess, setCouponSuccess] = useState("");
  const [customAffiliateCode, setCustomAffiliateCode] = useState("");
  const [generatedAffiliateLink, setGeneratedAffiliateLink] = useState("");

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError("");
    setCouponSuccess("");
    const cleanCode = couponInput.trim().toUpperCase();
    if (!cleanCode) {
      setCouponError("Please type a valid coupon code first.");
      return;
    }

    if (cleanCode === "WEBNIXO20" || cleanCode === "AFFILIATE20" || cleanCode === "START20") {
      setDiscountPercent(20);
      setAppliedCoupon(cleanCode);
      setCouponSuccess(`Success! 20% discount coupon '${cleanCode}' applied.`);
    } else if (cleanCode === "PARTNER50" || cleanCode === "LAUNCH50" || cleanCode === "AFFILIATESECRET") {
      setDiscountPercent(50);
      setAppliedCoupon(cleanCode);
      setCouponSuccess(`Sensational! Partner coupon '${cleanCode}' applied successfully: 50% discount activated!`);
    } else if (cleanCode === "FREEVIP") {
      setDiscountPercent(100);
      setAppliedCoupon(cleanCode);
      setCouponSuccess(`Holy smokes! VIP Access coupon '${cleanCode}' applied: 100% discount. Grab Pro for ₹0!`);
    } else {
      setCouponError("Invalid or expired coupon code. Try 'LAUNCH50' or 'WEBNIXO20'.");
    }
  };

  const handleCreateAffiliateCode = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAff = customAffiliateCode.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!cleanAff) {
      alert("Please enter a valid alphanumeric code name first.");
      return;
    }
    const upAff = cleanAff.toUpperCase();
    setGeneratedAffiliateLink(`${window.location.origin}?ref=${cleanAff}`);
    alert(`🎉 Success! Your custom affiliate coupon code '${upAff}' is activated. Share your link to start earning 40% recurring payouts!`);
  };

  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);

  const resetAutoPlay = () => {
    if (autoPlayRef.current) {
      clearInterval(autoPlayRef.current);
    }
    autoPlayRef.current = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % modelsData.length);
    }, 4500);
  };

  useEffect(() => {
    resetAutoPlay();

    // Auto-detect affiliate referral ref parameters
    const urlParams = new URLSearchParams(window.location.search);
    const refParam = urlParams.get("ref");
    if (refParam) {
      const affiliateCode = refParam.toUpperCase();
      setDiscountPercent(20);
      setAppliedCoupon(affiliateCode);
      setCouponInput(affiliateCode);
      setCouponSuccess(`Referral code '${affiliateCode}' activated! 20% discount has been pre-applied to your plans.`);
    }

    return () => {
      if (autoPlayRef.current) clearInterval(autoPlayRef.current);
    };
  }, []);

  const scrollToSection = (sectionId: "home" | "features" | "pricing" | "advantages" | "security" | "faq") => {
    setActiveTab(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      const topOffset = element.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top: topOffset, behavior: "smooth" });
    }
  };
  
  const modelsData = [
    {
      id: "claude-opus",
      name: "Claude Opus 4.8",
      company: "Anthropic",
      logo: "https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw",
      color: "border-[#ff6e4a]/30 hover:border-[#ff6e4a]/60 bg-[#ff6e4a]/[0.02]",
      brandColor: "#ff6e4a",
      desc: "Flagship supercomputing model for advanced architectural layouts and complex multi-step reasoning.",
      extra: "Claude Opus 4.8 stands at the pinnacle of semantic comprehension, delivering rich conceptual logic, long-form creative prose, and deep mechanical analysis.",
      limits: "4,000 Token premium context • Exclusive Premium lane"
    },
    {
      id: "gpt-5-5",
      name: "GPT 5.5",
      company: "OpenAI",
      logo: "https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa",
      color: "border-[#10a37f]/30 hover:border-[#10a37f]/60 bg-[#10a37f]/[0.02]",
      brandColor: "#10a37f",
      desc: "The next-generation production powerhouse. Pinnacle logical performance and layout crafting.",
      extra: "GPT 5.5 introduces revolutionary logical depth and deep multi-disciplinary expertise. Excellent for synthesizing complex application configurations.",
      limits: "4,000 Token premium allowance • High-frequency SSE lanes"
    },
    {
      id: "claude-sonnet-4-5",
      name: "Claude Sonnet 4.5",
      company: "Anthropic",
      logo: "https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw",
      color: "border-[#ff6e4a]/20 hover:border-[#ff6e4a]/45 bg-[#ff6e4a]/[0.01]",
      brandColor: "#ff6e4a",
      desc: "Precision-tuned sonnet. Industry-defining speed, linguistic clarity, and modular web code.",
      extra: "Claude Sonnet 4.5 delivers rapid design blueprints and fluid conversation flows, balancing speed and deep logical inference beautifully.",
      limits: "3,500 Token premium context • Exclusive Premium lane"
    },
    {
      id: "claude",
      name: "Claude 3.5 Sonnet",
      company: "Anthropic",
      logo: "https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw",
      color: "border-[#ff6e4a]/20 hover:border-[#ff6e4a]/40 bg-[#ff6e4a]/[0.01]",
      brandColor: "#ff6e4a",
      desc: "Superb writing nuance, code structures, and structured explanations.",
      extra: "Claude 3.5 Sonnet sets industry-defining standards for complex reasoning, code refactoring, and logical dialogue with advanced linguistic elegance.",
      limits: "2,500 Token window proxy overlay • Standard system caching"
    },
    {
      id: "gemini",
      name: "Gemini 2.5 Flash",
      company: "Google",
      logo: "https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m",
      color: "border-[#4484FC]/20 hover:border-[#4484FC]/40 bg-[#4484FC]/[0.01]",
      brandColor: "#4484FC",
      desc: "Blazing-fast speeds, large context capacity, and strong general reasoning.",
      extra: "Google's flagship multimodal champion engineered for maximum generation efficiency, massive context window parsing, and ultra-low streaming latency.",
      limits: "3,000 Token context envelope • SSE concurrency priority"
    },
    {
      id: "grok",
      name: "xAI Grok-2",
      company: "xAI",
      logo: "https://lh3.googleusercontent.com/d/1YwA9adPBxxiSJho0oitmi8eAxR_JZ5Q9",
      color: "border-zinc-500/20 hover:border-zinc-500/40 bg-zinc-500/[0.01]",
      brandColor: "#ffffff",
      desc: "Witty, analytical and highly aware real-time search knowledge.",
      extra: "Grok is an AI assistant with native integration on the X information index, offering witty, direct answers and comprehensive world-wide data inputs.",
      limits: "1,550 Token query allocation • Custom query layers"
    },
    {
      id: "chatgpt",
      name: "GPT-4o",
      company: "OpenAI",
      logo: "https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa",
      color: "border-[#10a37f]/20 hover:border-[#10a37f]/40 bg-[#10a37f]/[0.01]",
      brandColor: "#10a37f",
      desc: "Highly intelligent conversational flagship for coding and mathematics.",
      extra: "GPT-4o provides marvelous analytical depth, structural planning, and advanced programming functions built on premium deep-learning pipelines.",
      limits: "2,500 Token sandbox allowance • Real-time stream bypass"
    },
    {
      id: "deepseek",
      name: "DeepSeek Chat",
      company: "DeepSeek",
      logo: "https://lh3.googleusercontent.com/d/1Fbg0NTwHIIcYDrsMx66sE9PB1FbnpfvZ",
      color: "border-[#2F61FF]/20 hover:border-[#2F61FF]/40 bg-[#2F61FF]/[0.01]",
      brandColor: "#2F61FF",
      desc: "Advanced open-weights alternative with exceptional value and query precision.",
      extra: "DeepSeek stands as an state-of-the-art open coding and math powerhouse, with deep scientific reasoning and elegant payload compression.",
      limits: "1,550 Token core context • Optimized developer parameters"
    },
    {
      id: "mistral",
      name: "Mistral Large 2",
      company: "Mistral AI",
      logo: "https://lh3.googleusercontent.com/d/1yfqzyKb6799thhOSIN7V7a_6V78mo57h",
      color: "border-[#FD5320]/20 hover:border-[#FD5320]/40 bg-[#FD5320]/[0.01]",
      brandColor: "#FD5320",
      desc: "European flagship power boasting rich multilingual execution parameters.",
      extra: "Mistral Large is an advanced European model optimized for rich multi-language parsing, low latency, and highly precise operational instructions.",
      limits: "2,000 Token context • Standard multi-language proxy"
    }
  ];

  return (
    <div className="min-h-screen w-full bg-[#050508] text-[#ececec] font-sans flex flex-col relative overflow-x-hidden">
      
      {/* Decorative premium dark grid background with color matrix accents */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(244,63,94,0.015)_1px,transparent_1px),linear-gradient(to_bottom,rgba(99,102,241,0.015)_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none z-0" />
      <div className="absolute inset-x-0 top-0 h-[600px] bg-gradient-to-b from-indigo-500/10 via-purple-500/5 to-transparent blur-3xl pointer-events-none -z-10" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,#050508_95%)] pointer-events-none z-0" />

      {/* Cyber ambient gradient glowing glowing design layers and color blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 select-none">
        {/* Neon Emerald Blob - top left */}
        <div className="absolute top-[-250px] left-[-150px] w-[800px] h-[800px] bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.08)_0,transparent_70%)] blur-[100px] rounded-full transform-gpu animate-blob-slow-1" />
        
        {/* Vibrant Violet Cosmic Core Blob - center upper */}
        <div className="absolute top-[10%] left-[25%] w-[900px] h-[900px] bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.07)_0,transparent_75%)] blur-[120px] rounded-full transform-gpu animate-blob-slow-2" />
        
        {/* Electric Indigo Deep Blob - right middle */}
        <div className="absolute top-[40%] right-[-100px] w-[750px] h-[750px] bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.07)_0,transparent_70%)] blur-[90px] rounded-full transform-gpu animate-blob-slow-3" />
        
        {/* Hot Rose Flame Accent Blob - bottom left */}
        <div className="absolute bottom-[-10%] left-[-100px] w-[650px] h-[650px] bg-[radial-gradient(circle_at_center,rgba(244,63,94,0.06)_0,transparent_70%)] blur-[110px] rounded-full transform-gpu animate-blob-slow-1" />

        {/* Extra Gold Sunshine Accent Blob */}
        <div className="absolute top-[60%] left-[60%] w-[500px] h-[500px] bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.04)_0,transparent_70%)] blur-[100px] rounded-full transform-gpu animate-blob-slow-2" />

        {/* Dynamic Abstract Tech Lines */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.03] stroke-indigo-500" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="cyber-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="50%" stopColor="#8b5cf6" />
              <stop offset="100%" stopColor="#3b82f6" />
            </linearGradient>
          </defs>
          <path d="M-100,200 Q300,50 800,400 T1800,100" fill="none" strokeWidth="2" stroke="url(#cyber-grad)" />
          <path d="M-50,600 Q400,900 1000,500 T2100,950" fill="none" strokeWidth="1.5" stroke="url(#cyber-grad)" />
        </svg>
      </div>

      {/* 1. TOP HEADER / BRAND NAVIGATION */}
      <header className="w-full border-b border-zinc-900 bg-[#0d0d0d]/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div 
              className="w-8 h-8 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[1.5px] shrink-0" 
              style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
            >
              <div 
                className="w-full h-full bg-[#0d0d0d] flex items-center justify-center"
                style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
              >
                <img 
                  src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                  alt="Webnixo AI Logo" 
                  className="w-5 h-5 object-contain" 
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <span className="font-sans font-bold text-xl text-white tracking-tight">WEBNIXO AI</span>
            <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full uppercase tracking-wider">
              PRO TALK
            </span>
          </div>

          {/* Nav links mimicking chatgpt premium portfolio layout */}
          <nav className="hidden md:flex items-center gap-1.5 rounded-full bg-zinc-900/40 border border-zinc-800/60 p-1">
            <button
              onClick={() => scrollToSection("home")}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                activeTab === "home" ? "bg-[#27272a] text-white" : "text-zinc-400 hover:text-white"
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => scrollToSection("features")}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                activeTab === "features" ? "bg-[#27272a] text-white" : "text-zinc-400 hover:text-white"
              }`}
            >
              Engine Features
            </button>
            <button
              onClick={() => scrollToSection("pricing")}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                activeTab === "pricing" ? "bg-[#27272a] text-white" : "text-zinc-400 hover:text-white"
              }`}
            >
              Pricing & Limits
            </button>
            <button
              onClick={() => scrollToSection("advantages")}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                activeTab === "advantages" ? "bg-[#27272a] text-white" : "text-zinc-400 hover:text-white"
              }`}
            >
              AI Advantages
            </button>
            <button
              onClick={() => scrollToSection("security")}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                activeTab === "security" ? "bg-[#27272a] text-white" : "text-zinc-400 hover:text-white"
              }`}
            >
              Client Security
            </button>
          </nav>

          {/* Quick CTAs */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                navigate("/login");
              }}
              className="text-xs font-semibold text-zinc-400 hover:text-white px-2 py-1.5 transition-colors cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={() => {
                navigate("/login");
              }}
              className="bg-white hover:bg-neutral-200 text-black text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow-md active:scale-95 cursor-pointer"
            >
              Get Started
            </button>
            
            {/* Hamburger menu button for small screens */}
            <button
              onClick={() => setIsMobileNavOpen(!isMobileNavOpen)}
              className="p-1.5 md:hidden hover:bg-zinc-900 active:scale-90 border border-zinc-800 rounded-lg text-zinc-400 hover:text-white transition-all cursor-pointer flex items-center justify-center h-[34px] w-[34px]"
              aria-label="Toggle Mobile Menu"
            >
              {isMobileNavOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile nav dropdown drawer */}
      <AnimatePresence>
        {isMobileNavOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, filter: "blur(5px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -10, filter: "blur(5px)", transition: { duration: 0.15 } }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="md:hidden border-b border-zinc-900/60 bg-black/95 backdrop-blur-3xl absolute top-[68px] left-0 w-full z-30 shadow-[0_20px_40px_-20px_rgba(0,0,0,1)] transform-gpu max-h-[calc(100vh-68px)] overflow-y-auto"
          >
            <div className="p-5 flex flex-col gap-2">
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest block pl-2 font-mono">Navigation Links</span>
              
              <button
                onClick={() => { scrollToSection("home"); setIsMobileNavOpen(false); }}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition-all active:scale-[0.98] select-none ${
                  activeTab === "home" ? "bg-zinc-900 text-emerald-400 font-bold" : "text-zinc-400 hover:text-white hover:bg-zinc-900/40"
                }`}
              >
                Overview
              </button>
              
              <button
                onClick={() => { scrollToSection("features"); setIsMobileNavOpen(false); }}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition-all active:scale-[0.98] select-none ${
                  activeTab === "features" ? "bg-zinc-900 text-emerald-400 font-bold" : "text-zinc-400 hover:text-white hover:bg-zinc-900/40"
                }`}
              >
                Engine Features
              </button>
              
              <button
                onClick={() => { scrollToSection("pricing"); setIsMobileNavOpen(false); }}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition-all active:scale-[0.98] select-none ${
                  activeTab === "pricing" ? "bg-zinc-900 text-emerald-400 font-bold" : "text-zinc-400 hover:text-white hover:bg-zinc-900/40"
                }`}
              >
                Pricing & Token Limits
              </button>
              
              <button
                onClick={() => { scrollToSection("advantages"); setIsMobileNavOpen(false); }}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition-all active:scale-[0.98] select-none ${
                  activeTab === "advantages" ? "bg-zinc-900 text-emerald-400 font-bold" : "text-zinc-400 hover:text-white hover:bg-zinc-900/40"
                }`}
              >
                AI Advantages
              </button>
              
              <button
                onClick={() => { scrollToSection("security"); setIsMobileNavOpen(false); }}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition-all active:scale-[0.98] select-none ${
                  activeTab === "security" ? "bg-zinc-900 text-emerald-400 font-bold" : "text-zinc-400 hover:text-white hover:bg-zinc-900/40"
                }`}
              >
                Client Security & Isolation
              </button>

              <div className="h-px bg-zinc-900/60 my-3" />
              
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    navigate("/login");
                    setIsMobileNavOpen(false);
                  }}
                  className="bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs font-semibold py-2.5 rounded-xl text-center cursor-pointer active:scale-95 transition-all"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    navigate("/login");
                    setIsMobileNavOpen(false);
                  }}
                  className="bg-white hover:bg-neutral-200 text-black text-xs font-semibold py-2.5 rounded-xl text-center cursor-pointer active:scale-95 transition-all"
                >
                  Get Started
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. BODY CONTENT SECTION SWITCHER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 pt-12 pb-2 md:pt-20 md:pb-4 flex flex-col justify-center min-h-0 z-10">
        
        {activeTab === "home" && (
          <div className="space-y-24 md:space-y-32">
            {/* Center-aligned Hero Section */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="flex flex-col items-center text-center space-y-8 max-w-4xl mx-auto pt-4 relative"
            >
              {/* Floating aesthetic elements */}
              <div className="absolute top-10 -left-12 lg:-left-24 hidden md:flex items-center gap-2 px-4 py-2.5 bg-zinc-900/60 backdrop-blur-md border border-zinc-800 rounded-2xl animate-float-badge shadow-2xl z-0">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <Sparkles className="h-3 w-3 text-emerald-400" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">GPT-4o Ready</span>
                  <span className="text-xs text-white font-bold">1ms Latency</span>
                </div>
              </div>

              <div className="absolute top-32 -right-8 lg:-right-16 hidden md:flex items-center gap-2 px-4 py-2.5 bg-zinc-900/60 backdrop-blur-md border border-zinc-800 rounded-2xl animate-float-badge-delayed shadow-2xl z-0">
                <div className="w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center">
                  <Zap className="h-3 w-3 text-indigo-400" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">Claude 3.5</span>
                  <span className="text-xs text-white font-bold">Sonnet Engine</span>
                </div>
              </div>

              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.15, duration: 0.5 }}
                className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-900 border border-zinc-800 rounded-full text-[11px] text-zinc-400 font-semibold uppercase tracking-wider z-10 relative"
              >
                <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
                All-In-One Unified Sandbox Hub
              </motion.div>
              
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                className="text-4xl md:text-5xl lg:text-7xl font-bold tracking-tight text-white leading-tight font-display max-w-3xl z-10 relative"
              >
                Chat With Every Top AI <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-indigo-400 to-sky-400">
                  In One Secure Workspace
                </span>.
              </motion.h1>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.45, duration: 0.6 }}
                className="text-zinc-300 text-base md:text-lg max-w-2xl leading-relaxed"
              >
                Connect seamlessly with GPT-4o, Claude 3.5, Gemini 2.5, ultra-fast Grok-2, and DeepSeek. Ask questions, analyze files, build crisp websites, and write content inside a clean, privacy-focused dashboard.
              </motion.p>

              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.5 }}
                className="flex flex-wrap items-center justify-center gap-4 pt-2"
              >
                <button
                  onClick={() => {
                    navigate("/login");
                  }}
                  className="bg-emerald-500 hover:bg-emerald-400 text-black text-sm font-semibold px-8 py-3.5 rounded-xl flex items-center gap-2 transition-all active:scale-95 shadow-[0_0_40px_rgba(16,185,129,0.3)] hover:shadow-[0_0_60px_rgba(16,185,129,0.5)] group cursor-pointer border border-emerald-400"
                >
                  <Sparkles className="h-4 w-4" />
                  Start Chatting Free
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </motion.div>

              {/* Centered parameters stats banner */}
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.75, duration: 0.7 }}
                className="grid grid-cols-3 gap-8 pt-8 border-t border-zinc-900/80 w-full max-w-lg mt-4 justify-items-center"
              >
                <div className="text-center">
                  <span className="text-2xl font-bold text-white block">100%</span>
                  <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-semibold block mt-1">Data Secure</span>
                </div>
                <div className="text-center">
                  <span className="text-2xl font-bold text-white block">&lt; 1s</span>
                  <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-semibold block mt-1">SSE Latency</span>
                </div>
                <div className="text-center">
                  <span className="text-2xl font-bold text-white block">5+</span>
                  <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-semibold block mt-1">Top AI Models</span>
                </div>
              </motion.div>
              {/* Trusted By Section */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.9, duration: 0.8 }}
                className="pt-12 flex flex-col items-center gap-6 opacity-60 hover:opacity-100 transition-opacity duration-300"
              >
                <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-mono font-bold">Trusted by forward-thinking teams</span>
                <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12 grayscale">
                  <div className="flex items-center gap-2 text-white font-bold text-lg opacity-80"><div className="w-5 h-5 bg-white rounded-sm" /> ACME Corp</div>
                  <div className="flex items-center gap-2 text-white font-bold text-lg opacity-80"><div className="w-5 h-5 bg-white rounded-full" /> GLOBEX</div>
                  <div className="flex items-center gap-2 text-white font-bold text-lg opacity-80"><div className="w-5 h-5 bg-white rotate-45" /> SOYLENT</div>
                  <div className="flex items-center gap-2 text-white font-bold text-lg opacity-80"><div className="w-5 h-5 border-2 border-white rounded-sm" /> INITECH</div>
                  <div className="flex items-center gap-2 text-white font-bold text-lg opacity-80"><div className="w-5 h-5 rounded-tl-xl bg-white" /> UMBRELLA</div>
                </div>
              </motion.div>
            </motion.div>

            {/* Bento features grid beneath the centered hero */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12">
              
              <div className="group relative p-5 rounded-2xl border border-zinc-900 bg-[#121212]/40 backdrop-blur-sm space-y-3 hover:border-emerald-500/30 transition-all duration-500 animate-fade-in-up overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs tracking-wider uppercase relative z-10">
                  <Terminal className="h-4 w-4" />
                  Interactive Capabilities
                </div>
                <h3 className="text-sm font-bold text-white relative z-10">Full Markdown Rendering</h3>
                <p className="text-zinc-500 text-xs leading-relaxed relative z-10 group-hover:text-zinc-400 transition-colors">
                  Generates robust highlighted scripts, beautiful visual tables, nested lists, and semantic tags.
                </p>
                <div className="flex items-center gap-2 text-[10px] text-zinc-400 bg-zinc-900/50 border border-zinc-800 px-2.5 py-1 rounded w-fit font-mono relative z-10">
                  PROMPT: &quot;Show TS utility interfaces...&quot;
                </div>
              </div>

              <div className="group relative p-5 rounded-2xl border border-zinc-900 bg-[#121212]/40 backdrop-blur-sm space-y-3 hover:border-indigo-500/30 transition-all duration-500 animate-fade-in-up delay-75 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs tracking-wider uppercase relative z-10">
                  <Zap className="h-4 w-4" />
                  Dynamic Generator Engines
                </div>
                <h3 className="text-sm font-bold text-white relative z-10">Task-tailored Token Allocations</h3>
                <p className="text-zinc-500 text-xs leading-relaxed relative z-10 group-hover:text-zinc-400 transition-colors">
                  Tailors responses by switching tokens & instructions: 2,500 for HTML layout structures, 3,000 for informative blogs, and 1,000 for viral copy posts.
                </p>
              </div>

              <div className="group relative p-5 rounded-2xl border border-zinc-900 bg-[#121212]/40 backdrop-blur-sm space-y-3 hover:border-amber-500/30 transition-all duration-500 animate-fade-in-up delay-150 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                <div className="flex items-center gap-2 text-amber-500 font-semibold text-xs tracking-wider uppercase relative z-10">
                  <Compass className="h-4 w-4" />
                  Multimodal Sandbox
                </div>
                <h3 className="text-sm font-bold text-white relative z-10">Direct Attachment Processing</h3>
                <p className="text-zinc-500 text-xs leading-relaxed relative z-10 group-hover:text-zinc-400 transition-colors">
                  Analyzes text documents, CSV files, and converts image base64 directly inside of standard chat prompts without memory leakage.
                </p>
              </div>

            </div>

            {/* AI MODELS LOGO BRAND SECTION - HORIZONTAL CONTINUOUS MARQUEE SLIDER */}
            <div className="space-y-6 border-t border-zinc-900/60 pt-16 text-left">
              <div className="space-y-2">
                <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-full uppercase tracking-wider">
                  Infinite Model Ecosystem
                </span>
                <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-white font-display">
                  Continuous AI Engine Stream
                </h2>
                <p className="text-zinc-400 text-sm max-w-2xl leading-relaxed">
                  Webnixo AI coordinates seamlessly across multiple industry-leading flagship models. See our continuously synchronized high-speed frontier model list gliding below.
                </p>
              </div>

              {/* Looping Marquee container */}
              <div className="relative w-full overflow-hidden bg-zinc-950/20 py-10 border border-zinc-900 rounded-3xl mt-6 group">
                {/* Left & Right fading masking block */}
                <div className="absolute top-0 bottom-0 left-0 w-20 md:w-32 bg-gradient-to-r from-black/80 via-black/40 to-transparent z-10 pointer-events-none" />
                <div className="absolute top-0 bottom-0 right-0 w-20 md:w-32 bg-gradient-to-l from-black/80 via-black/40 to-transparent z-10 pointer-events-none" />

                <div className="flex animate-marquee gap-6">
                  {/* Duplicate 4 times to ensure no gaps ever occur on any viewport */}
                  {[...modelsData, ...modelsData, ...modelsData, ...modelsData].map((item, idx) => (
                    <div
                      key={`${item.id}-${idx}`}
                      className="flex items-center gap-6 px-6 py-5 rounded-3xl border border-zinc-800 shrink-0 min-w-[380px] md:min-w-[450px] bg-[#121212]/60 backdrop-blur-md transition-all duration-300 hover:scale-[1.03] shadow-lg shadow-black/40 hover:border-emerald-500/50 hover:shadow-[0_0_30px_rgba(16,185,129,0.15)] group/card"
                    >
                      <div className="w-24 h-24 md:w-28 md:h-28 rounded-2xl bg-zinc-900/50 overflow-hidden p-3.5 flex items-center justify-center shrink-0 border border-zinc-800 group-hover/card:border-emerald-500/50 transition-colors duration-300 shadow-inner">
                        <img 
                          src={item.logo} 
                          alt={item.name} 
                          className="w-full h-full object-contain filter drop-shadow-[0_0_10px_rgba(255,255,255,0.2)] transform group-hover/card:scale-110 transition-all duration-500" 
                          referrerPolicy="no-referrer" 
                        />
                      </div>
                      <div className="min-w-0 flex-1 space-y-1.5 text-left">
                        <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded uppercase tracking-wider font-extrabold font-mono inline-block">
                          {item.company}
                        </span>
                        <h4 className="text-base md:text-lg font-extrabold text-white tracking-tight leading-tight">{item.name}</h4>
                        <p className="text-zinc-300 text-xs md:text-sm leading-relaxed font-sans">{item.desc}</p>
                        <div className="text-[10px] text-zinc-500 font-mono tracking-wider pt-0.5 border-t border-zinc-900/60 uppercase">
                          {item.limits.split(' • ')[0]}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}


         {/* SECTION 2: INTEGRATION ARCHITECTURE */}
        <div id="features" className="space-y-12 max-w-6xl mx-auto text-center scroll-mt-24 border-t border-zinc-900/60 pt-20 mt-20">
          <div className="space-y-4 max-w-3xl mx-auto">
            <span className="text-[11px] font-extrabold bg-pink-500/10 text-pink-400 border border-pink-500/20 px-3.5 py-1 rounded-full uppercase tracking-wider">
              Smart Platform Engineering
            </span>
            <h2 className="text-3xl md:text-5xl font-black tracking-tight text-white font-display mt-2">
              Engine System Core
            </h2>
            <p className="text-zinc-400 text-sm md:text-base leading-relaxed max-w-2xl mx-auto">
              Webnixo AI uses a super simple, unified core system. We connect all the best AI models directly to your clean workspace screen. No messy setups, no hidden fees, just fast answers.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-8 items-center text-left">
            {/* Left Column: Simple English Description Cards */}
            <div className="lg:col-span-6 space-y-4">
              
              <div className="p-5 rounded-2xl bg-[#09090b]/80 border border-zinc-900 hover:border-zinc-800 transition-all duration-300 space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-pink-500/10 flex items-center justify-center text-pink-400 border border-pink-500/15">
                    <Cpu className="h-4.5 w-4.5" />
                  </div>
                  <h3 className="font-bold text-zinc-150 text-sm">Direct, Fast AI Router</h3>
                </div>
                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  We route your prompts directly to powerful models like Gemini, Claude, and GPT-4o. Our system remembers repeated queries to fetch answers almost instantly, saving you time.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#09090b]/80 border border-zinc-900 hover:border-zinc-800 transition-all duration-300 space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-[#10b981]/15 flex items-center justify-center text-[#10b981] border border-[#10b981]/15">
                    <Zap className="h-4.5 w-4.5" />
                  </div>
                  <h3 className="font-bold text-zinc-150 text-sm">Automatic Token Optimizer</h3>
                </div>
                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  The core automatically manages word count limits for you. It expands to give you longer code or website draft guides, and tightens limits for short, exciting social media ideas.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#09090b]/80 border border-zinc-900 hover:border-zinc-800 transition-all duration-300 space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/15">
                    <Shield className="h-4.5 w-4.5" />
                  </div>
                  <h3 className="font-bold text-zinc-150 text-sm">Strict Security Guard</h3>
                </div>
                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  Your private API keys and session inputs are kept strictly safe inside secure server containers. They are completely hidden and never exposed to dangerous browser trackers.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#09090b]/80 border border-zinc-900 hover:border-zinc-800 transition-all duration-300 space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 border border-amber-500/15">
                    <Sparkles className="h-4.5 w-4.5" />
                  </div>
                  <h3 className="font-bold text-zinc-150 text-sm">Live Workspace Renderer</h3>
                </div>
                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  Watch code turn into real layouts in real-time. Our safe rendering playground presents interactive website previews using standard, clean styles without slowing down your browser.
                </p>
              </div>

            </div>

            {/* Right Column: Visual AI Models Linkage Map with Webnixo Logo & model image logos */}
            <div className="lg:col-span-6 flex flex-col items-center justify-center p-6 bg-zinc-950/40 border border-zinc-900 rounded-3xl relative overflow-hidden min-h-[380px] md:min-h-[460px]">
              {/* Background Glows */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

              <div className="relative w-72 h-72 md:w-[360px] md:h-[360px] flex items-center justify-center">
                
                {/* SVG Connecting Spiderweb Lines */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-50" xmlns="http://www.w3.org/2000/svg">
                  <line x1="50%" y1="50%" x2="50%" y2="8%" stroke="#818cf8" strokeWidth="1.5" strokeDasharray="3 3" />
                  <line x1="50%" y1="50%" x2="88%" y2="28%" stroke="#34d399" strokeWidth="1.5" strokeDasharray="3 3" />
                  <line x1="50%" y1="50%" x2="88%" y2="72%" stroke="#60a5fa" strokeWidth="1.5" strokeDasharray="3 3" />
                  <line x1="50%" y1="50%" x2="50%" y2="92%" stroke="#9ca3af" strokeWidth="1.5" strokeDasharray="3 3" />
                  <line x1="50%" y1="50%" x2="12%" y2="72%" stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="3 3" />
                  <line x1="50%" y1="50%" x2="12%" y2="28%" stroke="#fb923c" strokeWidth="1.5" strokeDasharray="3 3" />
                </svg>

                {/* Central Webnixo Logo Node */}
                <div className="absolute z-20 w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-indigo-505 via-purple-500 to-emerald-505 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[2px] rounded-2xl shadow-[0_0_30px_rgba(99,102,241,0.2)] hover:scale-110 transition-transform duration-300">
                  <div className="w-full h-full bg-[#0d0d0d] flex flex-col items-center justify-center rounded-2xl">
                    <img 
                      src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                      alt="Webnixo AI Logo" 
                      className="w-10 h-10 md:w-12 md:h-12 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-[7.5px] font-bold text-zinc-400 uppercase tracking-widest mt-1">Core</span>
                  </div>
                </div>

                {/* AI Model Nodes Floating Around */}
                {/* 1. Claude - Top Middle */}
                <div className="absolute top-[2%] left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 hover:scale-110 transition-transform duration-200">
                  <div className="w-11 h-11 md:w-13 md:h-13 bg-[#161616] border border-[#ff6e4a]/30 rounded-2xl p-2 shadow-lg flex items-center justify-center">
                    <img src="https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw" alt="Claude" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  </div>
                  <span className="text-[9px] text-zinc-400 font-bold font-mono bg-zinc-900/80 px-2 py-0.5 rounded border border-zinc-800">Claude</span>
                </div>

                {/* 2. ChatGPT - Top Right */}
                <div className="absolute right-[6%] top-[22%] flex flex-col items-center gap-1 hover:scale-110 transition-transform duration-200">
                  <div className="w-11 h-11 md:w-13 md:h-13 bg-[#161616] border border-[#10a37f]/30 rounded-2xl p-2 shadow-lg flex items-center justify-center">
                    <img src="https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa" alt="GPT-4o" className="w-full h-full object-contain overflow-hidden rounded-md" referrerPolicy="no-referrer" />
                  </div>
                  <span className="text-[9px] text-zinc-400 font-bold font-mono bg-zinc-900/80 px-2 py-0.5 rounded border border-zinc-800">GPT-4o</span>
                </div>

                {/* 3. Gemini - Bottom Right */}
                <div className="absolute right-[6%] bottom-[22%] flex flex-col items-center gap-1 hover:scale-110 transition-transform duration-200">
                  <div className="w-11 h-11 md:w-13 md:h-13 bg-[#161616] border border-[#4484FC]/30 rounded-2xl p-2 shadow-lg flex items-center justify-center">
                    <img src="https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m" alt="Gemini" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  </div>
                  <span className="text-[9px] text-zinc-400 font-bold font-mono bg-zinc-900/80 px-2 py-0.5 rounded border border-zinc-800">Gemini</span>
                </div>

                {/* 4. Grok - Bottom Middle */}
                <div className="absolute bottom-[2%] left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 hover:scale-110 transition-transform duration-200">
                  <div className="w-11 h-11 md:w-13 md:h-13 bg-[#161616] border border-zinc-700 rounded-2xl p-2 shadow-lg flex items-center justify-center">
                    <img src="https://lh3.googleusercontent.com/d/1YwA9adPBxxiSJho0oitmi8eAxR_JZ5Q9" alt="Grok" className="w-full h-full object-contain invert" referrerPolicy="no-referrer" />
                  </div>
                  <span className="text-[9px] text-zinc-400 font-bold font-mono bg-zinc-900/80 px-2 py-0.5 rounded border border-zinc-800 font-sans">Grok-2</span>
                </div>

                {/* 5. DeepSeek - Bottom Left */}
                <div className="absolute left-[6%] bottom-[22%] flex flex-col items-center gap-1 hover:scale-110 transition-transform duration-200">
                  <div className="w-11 h-11 md:w-13 md:h-13 bg-[#161616] border border-[#2F61FF]/30 rounded-2xl p-2 shadow-lg flex items-center justify-center">
                    <img src="https://lh3.googleusercontent.com/d/1Fbg0NTwHIIcYDrsMx66sE9PB1FbnpfvZ" alt="DeepSeek" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  </div>
                  <span className="text-[9px] text-zinc-400 font-bold font-mono bg-zinc-900/80 px-2 py-0.5 rounded border border-zinc-800">DeepSeek</span>
                </div>

                {/* 6. Mistral - Top Left */}
                <div className="absolute left-[6%] top-[22%] flex flex-col items-center gap-1 hover:scale-110 transition-transform duration-200">
                  <div className="w-11 h-11 md:w-13 md:h-13 bg-[#161616] border border-[#FD5320]/30 rounded-2xl p-2 shadow-lg flex items-center justify-center">
                    <img src="https://lh3.googleusercontent.com/d/1yfqzyKb6799thhOSIN7V7a_6V78mo57h" alt="Mistral" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  </div>
                  <span className="text-[9px] text-zinc-400 font-bold font-mono bg-zinc-900/80 px-2 py-0.5 rounded border border-zinc-800">Mistral</span>
                </div>

              </div>
            </div>

          </div>
        </div>

        {/* SECTION 3: PRICING & LIMITS */}
        <div id="pricing" className="space-y-12 max-w-6xl mx-auto text-left scroll-mt-24 border-t border-zinc-900/60 pt-20 mt-20 relative z-10">

          <div className="space-y-4 text-center max-w-3xl mx-auto">
            <span className="text-[11px] font-extrabold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-4 py-1.5 rounded-full uppercase tracking-wider">
              Simple and Fair Billing
            </span>
            <h2 className="text-3xl md:text-5xl font-black tracking-tight text-white font-display mt-2">
              Pricing Plans & Token Limits
            </h2>
            <p className="text-zinc-400 text-sm md:text-base leading-relaxed max-w-xl mx-auto font-sans">
              Choose the plan that fits you best. Clear and simple prices structured in Indian Rupees (INR).
            </p>
          </div>

          {/* Pricing cards grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 animate-fade-in">
            {/* Starter plan */}
            <div className="p-6 rounded-2xl bg-zinc-950/60 border border-zinc-900 hover:border-zinc-800 transition-all flex flex-col justify-between space-y-8 relative overflow-hidden group">
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 mb-1">
                    <img 
                      src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                      alt="Webnixo Logo" 
                      className="w-4.5 h-4.5 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-xs text-zinc-400 font-mono uppercase tracking-wider font-extrabold">Starter Pass</span>
                  </div>
                  <h3 className="text-xl font-black text-white">Free Access</h3>
                </div>
                
                <div className="py-1">
                  <span className="text-4xl font-extrabold text-white">₹0</span>
                  <span className="text-sm text-zinc-500"> / forever</span>
                </div>

                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  Perfect for learning about Webnixo AI features and testing the workspace.
                </p>

                {/* AI Model Included Badge */}
                <div className="bg-zinc-900/50 p-2.5 rounded-xl border border-zinc-900/50 flex items-center justify-between">
                  <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider font-mono">Power Model:</span>
                  <div className="flex items-center gap-1.5 bg-zinc-950 px-2 py-1 rounded-md border border-zinc-800">
                    <img src="https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m" alt="Gemini" className="w-4 h-4 object-contain" referrerPolicy="no-referrer" />
                    <span className="text-[10px] font-bold text-zinc-300">Gemini</span>
                  </div>
                </div>

                <div className="border-t border-zinc-900 pt-4 space-y-3">
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <Zap className="h-4 w-4 text-indigo-400 shrink-0" />
                    <span><strong>1,500 word limit</strong> per prompt</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>Standard low-latency streaming</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>Runs standard web components</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => navigate("/login")}
                className="w-full py-3 bg-zinc-900 text-white text-xs font-bold rounded-lg text-center transition-all cursor-pointer border border-zinc-800 hover:bg-zinc-800"
              >
                Launch Client Sandbox
              </button>
            </div>

            {/* Pro plan (Popular) */}
            <div className="p-6 rounded-2xl bg-zinc-900/40 border-2 border-indigo-500/30 hover:border-indigo-500/50 shadow-[0_4px_30px_rgba(99,102,241,0.05)] transition-all flex flex-col justify-between space-y-8 relative overflow-hidden group">
              <div className="absolute top-0 right-0 bg-indigo-500/10 text-indigo-400 text-[10px] font-extrabold px-3 py-1 rounded-bl-xl border-l border-b border-indigo-500/20 uppercase tracking-widest">
                Popular
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 mb-1">
                    <img 
                      src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                      alt="Webnixo Logo" 
                      className="w-4.5 h-4.5 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-xs text-indigo-400 font-mono uppercase tracking-wider font-extrabold">Professional Pass</span>
                  </div>
                  <h3 className="text-xl font-black text-white">Developer Pro</h3>
                </div>
                
                <div className="py-1 flex flex-col font-sans">
                  {discountPercent > 0 ? (
                    <div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-sm text-zinc-500 line-through">₹850</span>
                        <span className="text-4xl font-extrabold text-emerald-400">
                          ₹{Math.round(850 * (1 - discountPercent / 100))}
                        </span>
                        <span className="text-xs text-zinc-400 font-normal"> / month</span>
                      </div>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 font-mono mt-1 inline-block">
                        {discountPercent}% Code Discount Added
                      </span>
                    </div>
                  ) : (
                    <div>
                      <span className="text-4xl font-extrabold text-white">₹850</span>
                      <span className="text-sm text-zinc-500"> / month</span>
                    </div>
                  )}
                </div>

                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  Best for programmers, content creators, and professional builders who need fast speeds.
                </p>

                {/* AI Models Included Images Badge */}
                <div className="bg-zinc-950 p-2.5 text-left rounded-xl border border-zinc-900 space-y-1.5">
                  <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider font-mono block">Premium Models Unlocked (Pro):</span>
                  <div className="flex flex-wrap gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#161616] p-1.5 border border-[#ff6e4a]/40 bg-[#ff6e4a]/10 flex items-center justify-center relative group/tooltip" title="Claude Opus 4.8 & 3.5">
                      <img src="https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw" alt="Claude" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      <span className="absolute -top-1 -right-1 bg-purple-500 text-[6px] text-white px-0.5 rounded font-mono font-bold uppercase">Opus</span>
                    </div>
                    <div className="w-8 h-8 rounded-lg bg-[#161616] p-1.5 border border-[#10a37f]/40 bg-[#10a37f]/10 flex items-center justify-center relative" title="GPT 5.5 & 4o">
                      <img src="https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa" alt="GPT" className="w-full h-full object-contain rounded-sm" referrerPolicy="no-referrer" />
                      <span className="absolute -top-1 -right-1 bg-emerald-500 text-[6px] text-white px-0.5 rounded font-mono font-bold uppercase">v5.5</span>
                    </div>
                    <div className="w-8 h-8 rounded-lg bg-[#161616] p-1.5 border border-[#ff6e4a]/40 bg-[#ff6e4a]/5 flex items-center justify-center relative" title="Claude Sonnet 4.5">
                      <img src="https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw" alt="Claude" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      <span className="absolute -top-1 -right-1 bg-indigo-500 text-[6px] text-white px-0.5 rounded font-mono font-bold uppercase">v4.5</span>
                    </div>
                    <div className="w-8 h-8 rounded-lg bg-[#161616] p-1.5 border border-[#4484FC]/25 flex items-center justify-center" title="Gemini 2.5 Flash">
                      <img src="https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m" alt="Gemini" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                    </div>
                    <div className="w-8 h-8 rounded-lg bg-[#161616] p-1.5 border border-zinc-805 flex items-center justify-center" title="Grok-2">
                      <img src="https://lh3.googleusercontent.com/d/1YwA9adPBxxiSJho0oitmi8eAxR_JZ5Q9" alt="Grok" className="w-full h-full object-contain invert" referrerPolicy="no-referrer" />
                    </div>
                  </div>
                </div>

                <div className="border-t border-zinc-800/80 pt-4 space-y-3">
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <Zap className="h-4 w-4 text-indigo-400 fill-indigo-400/20 shrink-0" />
                    <span><strong>2,500 word limit</strong> per prompt</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>Fast proxy lanes to premium endpoints</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>Load image and text files easily</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  navigate("/login");
                }}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg text-center transition-all shadow-md cursor-pointer duration-300"
              >
                Join Developer Pro
              </button>
            </div>

            {/* Enterprise plan */}
            <div className="p-6 rounded-2xl bg-zinc-950/60 border border-zinc-900 hover:border-zinc-800 transition-all flex flex-col justify-between space-y-8 relative overflow-hidden group">
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 mb-1">
                    <img 
                      src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                      alt="Webnixo Logo" 
                      className="w-4.5 h-4.5 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-xs text-zinc-400 font-mono uppercase tracking-wider font-extrabold">Enterprise Pass</span>
                  </div>
                  <h3 className="text-xl font-black text-white">Scale-up Infinite</h3>
                </div>
                
                <div className="py-1 flex flex-col font-sans">
                  {discountPercent > 0 ? (
                    <div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-sm text-zinc-500 line-through">₹2,450</span>
                        <span className="text-4xl font-extrabold text-emerald-400">
                          ₹{Math.round(2450 * (1 - discountPercent / 100))}
                        </span>
                        <span className="text-xs text-zinc-400 font-normal"> / month</span>
                      </div>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 font-mono mt-1 inline-block font-bold">
                        {discountPercent}% Code Discount Added
                      </span>
                    </div>
                  ) : (
                    <div>
                      <span className="text-4xl font-extrabold text-white">₹2,450</span>
                      <span className="text-sm text-zinc-500"> / month</span>
                    </div>
                  )}
                </div>

                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  The ultimate plan for companies requiring massive prompt space and direct API access.
                </p>

                {/* All 6 model images nested inside card */}
                <div className="bg-zinc-900/60 p-2 rounded-xl border border-zinc-900 space-y-1.5">
                  <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider font-mono block">All Models + Custom Overlays:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {modelsData.map((m) => (
                      <div 
                        key={m.id} 
                        className="w-7 h-7 rounded-md bg-[#161616] p-1 border border-zinc-850 border-zinc-805 flex items-center justify-center hover:scale-105 transition-transform" 
                        title={m.name}
                      >
                        <img 
                          src={m.logo} 
                          alt={m.name} 
                          className={`w-full h-full object-contain ${m.id === "grok" ? "invert" : ""}`} 
                          referrerPolicy="no-referrer" 
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t border-zinc-900 pt-4 space-y-3">
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <Zap className="h-4 w-4 text-indigo-400 shrink-0" />
                    <span><strong>3,000 word limit</strong> per prompt</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>Dedicated high-availability bypass servers</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-zinc-300">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>VIP continuous human support</span>
                  </div>
                </div>
              </div>

              <a
                href="mailto:support@webnixo.ai"
                className="w-full py-3 bg-zinc-900 hover:bg-zinc-850 hover:text-white text-zinc-300 text-xs font-bold rounded-lg text-center transition-all cursor-pointer border border-zinc-800 block"
              >
                Inquire Enterprise
              </a>
            </div>

          </div>



          {/* Quick limits conversion description info box */}
          <div className="p-5 rounded-xl bg-zinc-950 border border-zinc-900 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex gap-3">
              <div className="p-2 rounded bg-zinc-900 border border-zinc-800 text-emerald-400 shrink-0">
                <Info className="h-4 w-4" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-white">Token constraints guide</h4>
                <p className="text-zinc-500 text-[11px] leading-relaxed mt-0.5 font-sans">
                  Token parameters are strictly evaluated on server ingress: Website outputs allocate up to 2,500 units; Professional blog generation allocates up to 3000 units; and social copy outputs cap at 1,000 units to guarantee snappy high impact prose.
                </p>
              </div>
            </div>
            <div className="shrink-0 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-[10px] text-zinc-300 font-mono">
              INR billing handled securely via Razorpay
            </div>
          </div>
        </div>

        {/* SECTION 4: COST ADVANTAGES */}
        <div id="advantages" className="space-y-12 max-w-5xl mx-auto text-center scroll-mt-24 border-t border-zinc-900/60 pt-20 mt-20 pb-4">
          <div className="space-y-4 max-w-3xl mx-auto">
            <span className="text-[11px] font-extrabold bg-[#A855F7]/10 text-[#C084FC] border border-[#A855F7]/20 px-4 py-1.5 rounded-full uppercase tracking-wider">
              Ultimate Cost Efficiency
            </span>
            <h2 className="text-3xl md:text-5xl font-black tracking-tight text-white font-display mt-2">
              Why Choose Webnixo AI?
            </h2>
            <p className="text-zinc-400 text-sm md:text-base leading-relaxed max-w-xl mx-auto font-sans">
              Stop paying for separate AI accounts. With Webnixo AI, you get access to all top-tier models in one beautiful workspace.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 text-left">
            
            {/* Left Card: The Siloed Way */}
            <div className="p-6 rounded-2xl bg-zinc-950/45 border border-zinc-900 space-y-4 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-3 bg-red-500/5 text-red-500 text-[9px] font-mono uppercase tracking-widest border-b border-l border-zinc-900 rounded-bl-xl font-bold">
                Separate Accounts
              </div>
              
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-zinc-400">The Expensive Way</h3>
                <div className="text-2xl font-bold text-zinc-400 font-mono">
                  ≈ ₹5,900<span className="text-xs text-zinc-500 font-sans"> / month</span>
                </div>
              </div>

              <p className="text-xs text-zinc-500 leading-relaxed font-sans">
                Subscribing to each model individually adds up very quickly and gets expensive:
              </p>

              <div className="space-y-2.5 pt-2">
                <div className="flex items-center justify-between text-xs text-zinc-400 border-b border-zinc-900 pb-2">
                  <span className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                    ChatGPT Plus Subscription
                  </span>
                  <span className="font-mono text-zinc-500">₹1,999 / mo</span>
                </div>
                <div className="flex items-center justify-between text-xs text-zinc-400 border-b border-zinc-900 pb-2">
                  <span className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                    Claude Pro Subscription
                  </span>
                  <span className="font-mono text-zinc-500">₹1,999 / mo</span>
                </div>
                <div className="flex items-center justify-between text-xs text-zinc-400 border-b border-zinc-900 pb-2">
                  <span className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-505 bg-red-500 shrink-0" />
                    Gemini Advanced Subscription
                  </span>
                  <span className="font-mono text-zinc-500">₹1,950 / mo</span>
                </div>
              </div>

              <div className="pt-2 text-[11px] text-zinc-550 text-zinc-500 italic font-sans">
                Sum Total: Over ₹5,948+ every month to use all top tools.
              </div>
            </div>

            {/* Right Card: The Integrated Webnixo Pass */}
            <div className="p-6 rounded-2xl bg-zinc-900/20 border-2 border-emerald-500/25 space-y-4 relative overflow-hidden group shadow-[0_0_30px_rgba(16,185,129,0.02)]">
              <div className="absolute top-0 right-0 p-3 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold font-mono uppercase tracking-widest border-b border-l border-emerald-500/25 rounded-bl-xl">
                Webnixo AI Pass
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <img 
                    src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                    alt="Webnixo Logo" 
                    className="w-5 h-5 object-contain" 
                    referrerPolicy="no-referrer"
                  />
                  <h3 className="text-sm font-bold text-emerald-400">The Smarter Way</h3>
                </div>
                <div className="text-3xl font-extrabold text-white font-mono flex items-baseline gap-1 mt-1">
                  ₹850<span className="text-xs text-zinc-400 font-sans font-normal"> / month</span>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/25 px-2 py-0.5 rounded ml-2 uppercase font-mono tracking-wider animate-pulse">
                    Save ~85%
                  </span>
                </div>
              </div>

              <p className="text-xs text-zinc-300 leading-relaxed font-sans">
                Access GPT-4o, Claude 3.5, Gemini, and Grok-2 side-by-side in a single workspace. You get everything for <strong>less than half the cost of just one</strong> individual subscription!
              </p>

              {/* Mini AI models images preview */}
              <div className="flex items-center gap-2 bg-zinc-950 p-2 rounded-xl border border-zinc-900 w-fit">
                <img src="https://lh3.googleusercontent.com/d/1VDDHzhtOeAqS6PMjmYqz_JhgeHExKUDa" alt="GPT-4o" className="w-5 h-5 object-contain" referrerPolicy="no-referrer" />
                <img src="https://lh3.googleusercontent.com/d/1rzhFsbaA85mYhRtTI1b3RJ1_b0ZvjcKw" alt="Claude" className="w-5 h-5 object-contain" referrerPolicy="no-referrer" />
                <img src="https://lh3.googleusercontent.com/d/1mYyhQcqUADLcZbY_p66mAn3VW7f1L01m" alt="Gemini" className="w-5 h-5 object-contain" referrerPolicy="no-referrer" />
                <img src="https://lh3.googleusercontent.com/d/1YwA9adPBxxiSJho0oitmi8eAxR_JZ5Q9" alt="Grok" className="w-5 h-5 object-contain invert" referrerPolicy="no-referrer" />
              </div>

              <div className="space-y-2.5 pt-1">
                <div className="flex items-center gap-2 text-xs text-zinc-200">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>All key frontier models side-by-side in one page</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-zinc-200">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Unified fast word count and budget controls</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-zinc-200">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>Secure local cache without any tracking</span>
                </div>
              </div>
            </div>

          </div>

          {/* Integrated Frontier Models Beautiful Pocket Singularity Animation */}
          <ModelPocketAnimation />

          {/* Graphical Cost Visualizer Banner */}
          <div className="p-5 rounded-2xl bg-zinc-950/35 border border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-1.5 text-left md:max-w-md">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">The Mathematical Advantage</h4>
              <p className="text-zinc-500 text-[11px] leading-relaxed font-sans">
                Why pay <strong>₹1,999 each month</strong> for just one service when Webnixo gives you all of them for only <strong>₹850 per month</strong>? Zero context limits, unified workspace dashboard, and smart caching overlays built directly inside your browser.
              </p>
            </div>
            <div className="w-full md:w-auto flex items-center gap-4 bg-zinc-900/60 px-4 py-3 border border-zinc-850 rounded-xl shrink-0 font-sans">
              <div className="text-center">
                <span className="text-[10px] text-zinc-500 uppercase block font-mono">Single ChatGPT</span>
                <span className="text-sm font-bold text-zinc-400 line-through">₹1,999/mo</span>
              </div>
              <div className="text-zinc-650 text-zinc-605 text-zinc-500 text-lg font-mono">→</div>
              <div className="text-center">
                <span className="text-[10px] text-emerald-400 uppercase block font-bold font-mono">Webnixo 5+ AI</span>
                <span className="text-lg font-extrabold text-white">₹850/mo</span>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 5: CLIENT SECURITY */}
        <div id="security" className="space-y-6 max-w-5xl mx-auto text-center scroll-mt-24 border-t border-zinc-900/60 pt-16 mt-16 pb-2">
          <div className="space-y-2 max-w-2xl mx-auto">
            <span className="text-[10px] font-extrabold bg-amber-500/10 text-amber-500 border border-amber-500/10 px-3 py-1 rounded-full uppercase tracking-wider font-mono">
              Fail-Safe Compliance
            </span>
            <h2 className="text-2xl md:text-3xl font-black text-white font-display mt-2">Client-Side Security & Isolation</h2>
            <p className="text-zinc-400 text-xs">We enforce strict container sandbox boundaries protecting client session interactions perfectly.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 text-left max-w-4xl mx-auto">
            <div className="p-4 rounded-xl border border-zinc-900 bg-zinc-950/40 flex items-start gap-3">
              <Shield className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-xs font-bold text-white font-mono">Isolated Keys</h3>
                <p className="text-zinc-500 text-[11px] leading-relaxed font-sans">Secrets processed container-side; never leaked to browser hooks.</p>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-zinc-900 bg-zinc-950/40 flex items-start gap-3">
              <Lock className="h-5 w-5 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-xs font-bold text-white font-mono">Encrypted Cache</h3>
                <p className="text-zinc-500 text-[11px] leading-relaxed font-sans">Zero server-side logging. All data runs in isolated local cache vaults.</p>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-zinc-900 bg-zinc-950/40 flex items-start gap-3">
              <Lock className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-xs font-bold text-white font-mono">Iframe Safety</h3>
                <p className="text-zinc-500 text-[11px] leading-relaxed font-sans">Advanced sandboxing prevents hijacking or cross-site overrides.</p>
              </div>
            </div>
          </div>
        </div>



        {/* DETAILED FAQ KNOWLEDGE CENTER */}
        <div id="faq" className="space-y-12 max-w-6xl mx-auto text-left scroll-mt-24 border-t border-zinc-900/60 pt-20 mt-20 pb-16 relative z-10 w-full">
          
          <div className="space-y-4 text-center max-w-3xl mx-auto">
            <span className="text-[11px] font-extrabold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-4 py-1.5 rounded-full uppercase tracking-wider">
              Assistance & Compliance Center
            </span>
            <h2 className="text-3xl md:text-5xl font-black tracking-tight text-white font-display mt-3">
              Frequently Asked Questions
            </h2>
            <p className="text-zinc-400 text-sm md:text-base leading-relaxed">
              Find complete answers to platform capabilities, concurrent split screen testing benchmarks, credit allocations, and our strict no-refund policy.
            </p>
          </div>

          {/* Expanded Accordion List */}
          <div className="space-y-4.5 max-w-5xl mx-auto">
            {(() => {
              const faqItems = [
                {
                  category: "general",
                  q: "What is Webnixo AI and what direct benefits does it offer me?",
                  a: "Webnixo AI is a unified generative workspace coordinating multiple industry-defining artificial intelligence models inside a beautiful and cohesive sheet. Instead of keeping 5+ separate windows open and managing fragmented subscription overheads, you gain a singular, secure workspace designed to route conversational requests, analyze documents, and output functional templates cleanly."
                },
                {
                  category: "general",
                  q: "Do I need to supply a credit card during trial registration?",
                  a: "Absolutely not! Signing up for our Client Sandbox requires only basic credentials and yields continuous access to free dialogue limits without requiring pre-authorization or payment details."
                },
                {
                  category: "benchmarking",
                  q: "How does the Side-by-Side Model Comparison mode operate?",
                  a: "Clicking the 'Compare' option launches our native comparison split screen interface. Select your two preferred active models (e.g., Anthropic Claude and Google Gemini), and dispatch your query. Both neural engines process your text concurrently and stream independent answers side-by-side in real time, making benchmarking speed, format correctness, and copy tone instantaneous."
                },
                {
                  category: "benchmarking",
                  q: "Can I manage multiple conversational paths simultaneously?",
                  a: "Yes! The workspace sidebar lists your complete session logs historical list. You can seamlessly delete, clear, partition, and jump between distinct chat threads or document attachments without overlapping parameters."
                },
                {
                  category: "billing",
                  q: "What is your purchase Refund Policy?",
                  a: "Due to immediate allocation of physical API compute resources, we employ a strict no-refund policy. Once you pay, no refund will be initiated under any circumstances. Since immediate tokens and advanced model paths are allocated upon transaction setup, all card, UPI, or credit payments are final and cannot be returned."
                },
                {
                  category: "billing",
                  q: "How are smart credit fees computed per query?",
                  a: "Prompt costs are balanced strictly against system load overheads. A standard dialogue prompt deducts 1,500 smart credits from your wallet. Specialized developer templates—such as our Website Generator or Blog Writer—allow for generous token lengths and deduct up to 3,000 credits to cover the deep text compiled."
                },
                {
                  category: "billing",
                  q: "Can I apply discount coupons to my Indian Rupee (INR) plan purchase?",
                  a: "Definitely. Typing in promotion codes like LAUNCH50 or WEBNIXO20 applies a continuous 50% or 20% discount across our entire subscription menu instantly. Your localized INR pricing adapts automatically, making payments through our verified payment processing gateways fast and secure."
                },
                {
                  category: "data safety",
                  q: "Are my workspace files and historical transcripts securely saved?",
                  a: "Your data is treated with absolute priority. All generated sessions, folders, and uploaded file parameters are instantly backed up to our cloud database. Your workspace values remain safely isolated from physical device storage errors or cache deletion actions."
                },
                {
                  category: "data safety",
                  q: "Does Webnixo AI train models on my private dialogue interactions?",
                  a: "Never. We enforce isolated pipeline routing on all API proxies. Because your conversational payloads do not bypass our strict API privacy agreements, your data is never compiled, shared, or fed into machine learning backends for analytical training."
                }
              ];

              return faqItems.map((item, index) => {
                const isOpen = openedLandingFaqIndex === index;
                return (
                  <div 
                    key={index}
                    className="border border-zinc-900 rounded-xl overflow-hidden bg-zinc-950/30 hover:border-zinc-800 transition-all duration-200 shadow-lg"
                  >
                    <button
                      type="button"
                      onClick={() => setOpenedLandingFaqIndex(isOpen ? null : index)}
                      className="w-full text-left p-5 md:p-6.5 flex items-start sm:items-center justify-between gap-5 cursor-pointer active:scale-[0.98] transition-transform select-none"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4.5 flex-1">
                        <span className={`text-[9px] font-extrabold px-2.5 py-0.8 rounded border inline-block uppercase tracking-wider w-fit shrink-0 ${
                          item.category === "benchmarking" 
                            ? "text-indigo-400 bg-indigo-500/10 border-indigo-500/15"
                            : item.category === "billing"
                            ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/15"
                            : item.category === "data safety"
                            ? "text-amber-400 bg-amber-500/10 border-amber-500/15"
                            : "text-zinc-400 bg-zinc-550/5 border-zinc-800"
                        }`}>
                          {item.category}
                        </span>
                        <span className="text-sm md:text-base text-zinc-100 font-bold font-sans leading-relaxed hover:text-white transition-colors">
                          {item.q}
                        </span>
                      </div>
                      <span className="text-zinc-500 text-xs shrink-0 select-none font-bold">
                        {isOpen ? "▲" : "▼"}
                      </span>
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.15 }}
                          className="border-t border-zinc-900 bg-[#0d0d0f]/80 text-zinc-300 p-5 md:p-6.5 font-sans"
                        >
                          <p className="text-sm md:text-[15px] text-zinc-300 leading-relaxed font-sans whitespace-pre-line font-medium">
                            {item.a}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              });
            })()}
          </div>
        </div>

      </main>

      {/* 3. PREMIUM MINIMAL FOOTER (Clean and simplified as requested) */}
      <footer className="w-full border-t border-zinc-900 bg-[#070707] py-8 px-6 mt-auto text-xs text-zinc-500 relative z-10 font-sans overflow-hidden">
        <div className="absolute inset-x-0 bottom-0 h-[300px] bg-gradient-to-t from-emerald-500/10 via-indigo-500/5 to-transparent blur-3xl pointer-events-none -z-10" />
        <div className="max-w-7xl mx-auto space-y-6">
          
          {/* Top Row: Brand & Clean Menu links */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 pb-6 border-b border-zinc-950">
            <div className="flex items-center gap-2.5">
              <div 
                className="w-6 h-6 bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 p-[1px] shrink-0" 
                style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
              >
                <div 
                  className="w-full h-full bg-[#070707] flex items-center justify-center"
                  style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                >
                  <img 
                    src="https://lh3.googleusercontent.com/d/11yuTE40NZx1imt0DARVHUfIPTrgtrJA6=s512" 
                    alt="Webnixo AI Logo" 
                    className="w-4 h-4 object-contain" 
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
              <span className="font-sans font-extrabold text-sm text-white tracking-tight">WEBNIXO AI</span>
              <span className="text-[8px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded-md uppercase tracking-wider">
                Stable Proxy
              </span>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-zinc-400 font-medium text-[11px]">
              <button onClick={() => scrollToSection("home")} className="hover:text-white transition-colors cursor-pointer">Overview</button>
              <button onClick={() => scrollToSection("features")} className="hover:text-white transition-colors cursor-pointer">System Features</button>
              <button onClick={() => scrollToSection("pricing")} className="hover:text-white transition-colors cursor-pointer">Pricing Plans</button>
              <button onClick={() => scrollToSection("advantages")} className="hover:text-white transition-colors cursor-pointer">AI Advantages</button>
              <button onClick={() => scrollToSection("security")} className="hover:text-white transition-colors cursor-pointer">Security</button>
              <button onClick={() => scrollToSection("faq")} className="text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer">FAQ Center</button>
            </div>
          </div>

          {/* Bottom Row: Copyright & Policy triggers */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px]">
            <div className="text-zinc-650 text-center sm:text-left flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
              <span>© 2026 WEBNIXO AI. Secure Multi-Model Stream Dialog Sandbox.</span>
              <span className="hidden sm:inline text-zinc-800">|</span>
              <button 
                onClick={() => navigate("/login?role=affiliate")}
                className="text-[10px] text-zinc-500 hover:text-emerald-400 transition-colors uppercase font-mono font-bold tracking-wider cursor-pointer underline text-left"
              >
                Affiliate Partner Portal Login
              </button>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-4 text-zinc-500">
              <a href="/policies/privacy" target="_blank" rel="noopener noreferrer" className="hover:text-white hover:underline transition-colors cursor-pointer font-semibold">Privacy Policy</a>
              <span>•</span>
              <a href="/policies/terms" target="_blank" rel="noopener noreferrer" className="hover:text-white hover:underline transition-colors cursor-pointer font-semibold">Terms</a>
              <span>•</span>
              <a href="/policies/cookies" target="_blank" rel="noopener noreferrer" className="hover:text-white hover:underline transition-colors cursor-pointer font-semibold">Cookie Consent</a>
              <span>•</span>
              <a href="/policies/refund" target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:text-emerald-300 hover:underline transition-colors cursor-pointer font-semibold">Refund Policy</a>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}
