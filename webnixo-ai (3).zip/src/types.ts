export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  isStreaming?: boolean;
  error?: boolean;
  files?: {
    id: string;
    name: string;
    type: string;
    size: number;
    isImage: boolean;
    base64?: string;
  }[];
  isSideBySide?: boolean;
  modelA_id?: string;
  modelA_content?: string;
  modelA_isStreaming?: boolean;
  modelA_error?: string;
  modelB_id?: string;
  modelB_content?: string;
  modelB_isStreaming?: boolean;
  modelB_error?: string;
  modelC_id?: string;
  modelC_content?: string;
  modelC_isStreaming?: boolean;
  modelC_error?: string;
  modelD_id?: string;
  modelD_content?: string;
  modelD_isStreaming?: boolean;
  modelD_error?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
  promptType: "general" | "creative" | "code" | "concise" | "website" | "blog" | "social";
  selectedModel: string;
}

export interface ModelOption {
  id: string;
  name: string;
  description: string;
  badge?: string;
  logo?: string;
}
