import { useEffect, useState, useCallback } from "react";
import { supabase } from "../lib/supabaseClient";
import {
  SupabaseService,
  Profile,
  Conversation,
  MessageRow,
  UserUsage,
  Subscription,
  Payment,
  GeneratedContent,
  UploadedFileRow
} from "../lib/supabaseService";

export function useSupabase() {
  const [sessionUser, setSessionUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [usage, setUsage] = useState<UserUsage | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [generatedContents, setGeneratedContents] = useState<GeneratedContent[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFileRow[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  // Initialize and listen to Auth updates
  useEffect(() => {
    let active = true;

    async function initializeUser() {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!active) return;

        if (session?.user) {
          setSessionUser(session.user);
          await loadUserData(session.user.id);
        } else {
          setSessionUser(null);
          setProfile(null);
          setUsage(null);
          setSubscription(null);
          setLoading(false);
        }
      } catch (err: any) {
        console.error("Auth initialization failed:", err.message);
        if (active) setLoading(false);
      }
    }

    initializeUser();

    const { data: { subscription: authListener } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!active) return;
        setLoading(true);
        if (session?.user) {
          setSessionUser(session.user);
          await loadUserData(session.user.id);
        } else {
          setSessionUser(null);
          setProfile(null);
          setUsage(null);
          setSubscription(null);
          setConversations([]);
          setMessages([]);
          setGeneratedContents([]);
          setUploadedFiles([]);
          setLoading(false);
        }
      }
    );

    return () => {
      active = false;
      authListener.unsubscribe();
    };
  }, []);

  // Sync / Load all relational client data
  const loadUserData = async (userId: string) => {
    try {
      const [
        pData,
        uData,
        subData,
        payData,
        convData,
        genData,
        fileData
      ] = await Promise.all([
        SupabaseService.getProfile(userId),
        SupabaseService.getUsage(userId),
        SupabaseService.getSubscription(userId),
        SupabaseService.getPayments(userId),
        SupabaseService.getConversations(userId),
        SupabaseService.getGeneratedContents(userId),
        SupabaseService.getUploadedFiles(userId)
      ]);

      setProfile(pData);
      setUsage(uData);
      setSubscription(subData);
      setPayments(payData);
      setConversations(convData);
      setGeneratedContents(genData);
      setUploadedFiles(fileData);
    } catch (e: any) {
      console.error("Failed to fetch full database context:", e.message);
    } finally {
      setLoading(false);
    }
  };

  // Reload details helper
  const reloadData = useCallback(async () => {
    if (sessionUser?.id) {
      setLoading(true);
      await loadUserData(sessionUser.id);
    }
  }, [sessionUser]);

  // === AUTHENTICATION MUTATORS ===
  const signUp = async (email: string, password: string, name: string) => {
    setAuthError(null);
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: name,
        },
      },
    });

    if (error) {
      setAuthError(error.message);
      setLoading(false);
      throw error;
    }
    return data;
  };

  const signIn = async (email: string, password: string) => {
    setAuthError(null);
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      setAuthError(error.message);
      setLoading(false);
      throw error;
    }
    return data;
  };

  const signInWithGoogle = async () => {
    setAuthError(null);
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: window.location.origin,
      },
    });

    if (error) {
      setAuthError(error.message);
      throw error;
    }
    return data;
  };

  const signOut = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error("Sign out fail:", error.message);
    }
  };

  // === CONVERSATIONS ACTIONS ===
  const selectConversationMessages = async (convId: string) => {
    setLoading(true);
    try {
      const msgs = await SupabaseService.getMessages(convId);
      setMessages(msgs);
    } catch (e) {
      console.error("Failed to select conversation messages:", e);
    } finally {
      setLoading(false);
    }
  };

  const startNewConversation = async (title: string, customId?: string) => {
    if (!sessionUser) return null;
    const newConv = await SupabaseService.createConversation(sessionUser.id, title, customId);
    setConversations(prev => [newConv, ...prev]);
    setMessages([]);
    return newConv;
  };

  const renameConv = async (id: string, newTitle: string) => {
    await SupabaseService.updateConversationTitle(id, newTitle);
    setConversations(prev =>
      prev.map(c => (c.id === id ? { ...c, title: newTitle, updated_at: new Date().toISOString() } : c))
    );
  };

  const fetchUpdatedConversations = useCallback(async () => {
    if (sessionUser?.id) {
      const convs = await SupabaseService.getConversations(sessionUser.id);
      setConversations(convs);
    }
  }, [sessionUser]);

  const deleteConv = async (id: string) => {
    await SupabaseService.deleteConversation(id);
    setConversations(prev => prev.filter(c => c.id !== id));
    setMessages([]);
  };

  // === MESSAGE ACTIONS ===
  const appendMessageToConversation = async (
    convId: string,
    role: "user" | "assistant",
    content: string,
    modelUsed?: string,
    tokensUsed?: number,
    customId?: string
  ) => {
    const saved = await SupabaseService.saveMessage({
      id: customId,
      conversation_id: convId,
      role,
      content,
      model_used: modelUsed,
      tokens_used: tokensUsed
    });
    setMessages(prev => [...prev, saved]);
    
    // Refresh conversation lists to show the updated timestamp order
    fetchUpdatedConversations();
    return saved;
  };

  // === LIMITS / USAGE ACTIONS ===
  const trackAIUsage = async (type: "prompts" | "images") => {
    if (!sessionUser) return;
    const updated = await SupabaseService.incrementUsage(sessionUser.id, type);
    setUsage(updated);
  };

  // === SUBSCRIPTION & BILLING ===
  const purchasePlan = async (planName: string, amount: number, gateway = "stripe") => {
    if (!sessionUser) return;
    
    // Create actual payment transaction first
    await SupabaseService.recordPayment({
      user_id: sessionUser.id,
      amount,
      payment_gateway: gateway,
      transaction_id: `tx_${Math.floor(10000000 + Math.random() * 90000000)}`,
      status: "succeeded"
    });

    // Elevate subscription state
    const newSub = await SupabaseService.upgradeSubscription(sessionUser.id, planName);
    setSubscription(newSub);
    
    // Reload profiles to sync newly elevated tier
    const freshProfile = await SupabaseService.getProfile(sessionUser.id);
    setProfile(freshProfile);
    
    // Reload payments to list transaction history
    const freshPayments = await SupabaseService.getPayments(sessionUser.id);
    setPayments(freshPayments);
  };

  // === GENERATED CONTENT WORKSPACE ===
  const saveWorkToCloud = async (contentType: string, title: string, content: string) => {
    if (!sessionUser) return null;
    const saved = await SupabaseService.saveGeneratedContent({
      user_id: sessionUser.id,
      content_type: contentType,
      title,
      content
    });
    setGeneratedContents(prev => [saved, ...prev]);
    return saved;
  };

  const removeWorkFromCloud = async (id: string) => {
    await SupabaseService.deleteGeneratedContent(id);
    setGeneratedContents(prev => prev.filter(c => c.id !== id));
  };

  // === FILE ATTACHMENTS ===
  const saveDocumentReference = async (fileName: string, fileUrl: string, fileType: string) => {
    if (!sessionUser) return null;
    const saved = await SupabaseService.saveUploadedFile({
      user_id: sessionUser.id,
      file_name: fileName,
      file_url: fileUrl,
      file_type: fileType
    });
    setUploadedFiles(prev => [saved, ...prev]);
    return saved;
  };

  const deleteDocumentReference = async (id: string) => {
    await SupabaseService.deleteUploadedFile(id);
    setUploadedFiles(prev => prev.filter(f => f.id !== id));
  };

  return {
    sessionUser,
    profile,
    usage,
    subscription,
    payments,
    conversations,
    messages,
    generatedContents,
    uploadedFiles,
    loading,
    authError,
    
    signUp,
    signIn,
    signInWithGoogle,
    signOut,
    
    reloadData,
    selectConversationMessages,
    startNewConversation,
    renameConv,
    deleteConv,
    appendMessageToConversation,
    trackAIUsage,
    purchasePlan,
    saveWorkToCloud,
    removeWorkFromCloud,
    saveDocumentReference,
    deleteDocumentReference
  };
}
