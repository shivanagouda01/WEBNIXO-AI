import React from "react";
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { LandingPage } from "./components/LandingPage";
import { AuthCallback } from "./pages/AuthCallback";
import { Policies } from "./pages/Policies";

/**
 * Starting page wrapper that renders the public showcase page.
 * If user is already authenticated, redirects them straight to the active session dashboard.
 */
function StartingPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (user) {
      if (localStorage.getItem("login_as") === "affiliate") {
        navigate("/login?role=affiliate", { replace: true });
      } else {
        navigate("/dashboard", { replace: true });
      }
    }
  }, [user, navigate]);

  return <LandingPage />;
}

/**
 * App Router Orchestrator
 * Integrates AuthProvider context and routes.
 * /login is open to public, /dashboard is restricted behind ProtectedRoute.
 */
function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Starting Page showing public Landing Page */}
          <Route path="/" element={<StartingPage />} />

          {/* Public Authentication gate */}
          <Route path="/login" element={<Login />} />

          {/* Secure Auth callback handler */}
          <Route path="/auth/callback" element={<AuthCallback />} />

          {/* Policies routes */}
          <Route path="/policies/:policyType" element={<Policies />} />

          {/* Secure authenticated Dashboard sandbox */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />

          {/* Fallback pattern: Any other route redirects directly to /dashboard */}
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
