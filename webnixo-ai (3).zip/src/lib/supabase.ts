import { createClient } from "@supabase/supabase-js";

/**
 * Reusable Supabase client file.
 * Reads configurations from Vite environment variables VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.
 */

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "";

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    "Supabase credentials missing. Ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set in your environment configuration (.env file)."
  );
} else {
  console.log("[Supabase Client] Initializing singleton instance client on URL:", supabaseUrl);
}

// Instantiate and export the reusable Supabase client with explicit options
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    detectSessionInUrl: true,
    flowType: "pkce",
    storage: window.localStorage
  }
});
