import { supabase } from "./supabaseClient";

// Database Type Definitions
export interface Profile {
  id: string; // matches auth.uid()
  full_name: string;
  email: string;
  avatar_url: string;
  plan: "free" | "starter" | "pro" | "admin";
  created_at: string;
}

export interface Conversation {
  id: string;
  user_id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface MessageRow {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  model_used?: string;
  tokens_used?: number;
  created_at: string;
}

export interface UserUsage {
  id: string; // references profiles.id
  user_id: string;
  prompts_used_today: number;
  images_generated_today: number;
  last_reset_date: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  plan_name: string;
  payment_status: string;
  start_date: string;
  expiry_date?: string;
}

export interface Payment {
  id: string;
  user_id: string;
  amount: number;
  payment_gateway: string;
  transaction_id: string;
  status: string;
  created_at: string;
}

export interface GeneratedContent {
  id: string;
  user_id: string;
  content_type: string; // 'blog', 'website', 'social', etc.
  title: string;
  content: string;
  created_at: string;
}

export interface UploadedFileRow {
  id: string;
  user_id: string;
  file_name: string;
  file_url: string;
  file_type: string;
  created_at: string;
}

// Supabase CRUD Service Methods
export const SupabaseService = {
  // === AUTHENTICATION & PROFILE METHODS ===
  async getCurrentUser() {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error) return null;
    return user;
  },

  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();
    if (error) {
      console.error("Error retrieving user profile:", error.message);
      return null;
    }
    return data as Profile;
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile | null> {
    const { data, error } = await supabase
      .from("profiles")
      .update(updates)
      .eq("id", userId)
      .select()
      .single();
    if (error) {
      console.error("Error updating user profile:", error.message);
      throw error;
    }
    return data as Profile;
  },

  // === CONVERSATION METHODS ===
  async getConversations(userId: string): Promise<Conversation[]> {
    const { data, error } = await supabase
      .from("conversations")
      .select("*")
      .eq("user_id", userId)
      .order("updated_at", { ascending: false });
    if (error) {
      console.error("Error fetching conversations:", error.message);
      return [];
    }
    return data as Conversation[];
  },

  async createConversation(userId: string, title: string, id?: string): Promise<Conversation> {
    const newId = id || crypto.randomUUID();
    const { data, error } = await supabase
      .from("conversations")
      .insert({
        id: newId,
        user_id: userId,
        title,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single();
    if (error) {
      console.error("Error creating conversation:", error.message);
      throw error;
    }
    return data as Conversation;
  },

  async updateConversationTitle(id: string, title: string): Promise<void> {
    const { error } = await supabase
      .from("conversations")
      .update({ title, updated_at: new Date().toISOString() })
      .eq("id", id);
    if (error) {
      console.error("Error updating conversation title:", error.message);
      throw error;
    }
  },

  async deleteConversation(id: string): Promise<void> {
    const { error } = await supabase
      .from("conversations")
      .delete()
      .eq("id", id);
    if (error) {
      console.error("Error deleting conversation:", error.message);
      throw error;
    }
  },

  // === MESSAGE METHODS ===
  async getMessages(conversationId: string): Promise<MessageRow[]> {
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true });
    if (error) {
      console.error("Error retrieving conversation messages:", error.message);
      return [];
    }
    return data as MessageRow[];
  },

  async saveMessage(msg: {
    id?: string;
    conversation_id: string;
    role: "user" | "assistant";
    content: string;
    model_used?: string;
    tokens_used?: number;
  }): Promise<MessageRow> {
    const { data, error } = await supabase
      .from("messages")
      .insert({
        id: msg.id || crypto.randomUUID(),
        conversation_id: msg.conversation_id,
        role: msg.role,
        content: msg.content,
        model_used: msg.model_used,
        tokens_used: msg.tokens_used || 0,
        created_at: new Date().toISOString(),
      })
      .select()
      .single();
    if (error) {
      console.error("Error saving chat message:", error.message);
      throw error;
    }
    // Update the parent conversation's updated_at timestamp!
    await supabase
      .from("conversations")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", msg.conversation_id);
      
    return data as MessageRow;
  },

  // === USER USAGE METHODS ===
  async getUsage(userId: string): Promise<UserUsage | null> {
    const { data, error } = await supabase
      .from("user_usage")
      .select("*")
      .eq("user_id", userId)
      .single();
    if (error) {
      console.error("Error retrieving user usage info:", error.message);
      return null;
    }
    return data as UserUsage;
  },

  async incrementUsage(
    userId: string,
    type: "prompts" | "images"
  ): Promise<UserUsage> {
    const { data: current, error: fetchError } = await supabase
      .from("user_usage")
      .select("*")
      .eq("user_id", userId)
      .single();

    if (fetchError || !current) {
      throw new Error("Could not retrieve current usage state for incrementation.");
    }

    const todayStr = new Date().toISOString().split("T")[0];
    const isNewDay = current.last_reset_date !== todayStr;

    const updates: Partial<UserUsage> = {};
    if (isNewDay) {
      updates.last_reset_date = todayStr;
      updates.prompts_used_today = type === "prompts" ? 1 : 0;
      updates.images_generated_today = type === "images" ? 1 : 0;
    } else {
      if (type === "prompts") {
        updates.prompts_used_today = current.prompts_used_today + 1;
      } else {
        updates.images_generated_today = current.images_generated_today + 1;
      }
    }

    const { data, error } = await supabase
      .from("user_usage")
      .update(updates)
      .eq("user_id", userId)
      .select()
      .single();

    if (error) {
      console.error("Error incrementing usage limits:", error.message);
      throw error;
    }
    return data as UserUsage;
  },

  // === SUBSCRIPTIONS ===
  async getSubscription(userId: string): Promise<Subscription | null> {
    const { data, error } = await supabase
      .from("subscriptions")
      .select("*")
      .eq("user_id", userId)
      .order("start_date", { ascending: false })
      .limit(1);

    if (error) {
      console.error("Error loading subscription records:", error.message);
      return null;
    }
    return data && data.length > 0 ? (data[0] as Subscription) : null;
  },

  async upgradeSubscription(userId: string, planName: string): Promise<Subscription> {
    const { data, error } = await supabase
      .from("subscriptions")
      .insert({
        id: crypto.randomUUID(),
        user_id: userId,
        plan_name: planName,
        payment_status: "paid",
        start_date: new Date().toISOString(),
        expiry_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days of service
      })
      .select()
      .single();

    if (error) {
      console.error("Error creating subscription upgrade record:", error.message);
      throw error;
    }

    // Also upgrade plan field inside profiles table!
    await supabase
      .from("profiles")
      .update({ plan: planName as any })
      .eq("id", userId);

    return data as Subscription;
  },

  // === PAYMENTS ===
  async getPayments(userId: string): Promise<Payment[]> {
    const { data, error } = await supabase
      .from("payments")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) {
      console.error("Error loading billing history records:", error.message);
      return [];
    }
    return data as Payment[];
  },

  async recordPayment(payment: Omit<Payment, "id" | "created_at">): Promise<Payment> {
    const { data, error } = await supabase
      .from("payments")
      .insert({
        id: crypto.randomUUID(),
        ...payment,
        created_at: new Date().toISOString()
      })
      .select()
      .single();
    if (error) {
      console.error("Error recording payment transaction:", error.message);
      throw error;
    }
    return data as Payment;
  },

  // === GENERATED CONTENT ===
  async getGeneratedContents(userId: string): Promise<GeneratedContent[]> {
    const { data, error } = await supabase
      .from("generated_content")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) {
      console.error("Error loads generated documents:", error.message);
      return [];
    }
    return data as GeneratedContent[];
  },

  async saveGeneratedContent(content: Omit<GeneratedContent, "id" | "created_at">): Promise<GeneratedContent> {
    const { data, error } = await supabase
      .from("generated_content")
      .insert({
        id: crypto.randomUUID(),
        ...content,
        created_at: new Date().toISOString()
      })
      .select()
      .single();
    if (error) {
      console.error("Error saving generated asset:", error.message);
      throw error;
    }
    return data as GeneratedContent;
  },

  async deleteGeneratedContent(id: string): Promise<void> {
    const { error } = await supabase
      .from("generated_content")
      .delete()
      .eq("id", id);
    if (error) {
      console.error("Error clearing generated workspace asset:", error.message);
      throw error;
    }
  },

  // === UPLOADED FILES ===
  async getUploadedFiles(userId: string): Promise<UploadedFileRow[]> {
    const { data, error } = await supabase
      .from("uploaded_files")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) {
      console.error("Error retrieving uploaded attachments history:", error.message);
      return [];
    }
    return data as UploadedFileRow[];
  },

  async saveUploadedFile(file: Omit<UploadedFileRow, "id" | "created_at">): Promise<UploadedFileRow> {
    const { data, error } = await supabase
      .from("uploaded_files")
      .insert({
        id: crypto.randomUUID(),
        ...file,
        created_at: new Date().toISOString()
      })
      .select()
      .single();
    if (error) {
      console.error("Error saving document reference in database:", error.message);
      throw error;
    }
    return data as UploadedFileRow;
  },

  async deleteUploadedFile(id: string): Promise<void> {
    const { error } = await supabase
      .from("uploaded_files")
      .delete()
      .eq("id", id);
    if (error) {
      console.error("Failed to delete document reference in query:", error.message);
      throw error;
    }
  },
};
