// Production-ready pricing and AI model credit configuration for Webnixo AI

export interface ModelDetails {
  id: string;
  name: string;
  group: "Gemini Flash" | "DeepSeek" | "Mistral" | "Grok" | "Perplexity" | "GPT" | "Claude";
  cost: number;
}

export const MODERN_MODELS: ModelDetails[] = [
  {
    id: "google/gemini-3.5-flash",
    name: "Gemini 3.5 Flash",
    group: "Gemini Flash",
    cost: 1,
  },
  {
    id: "google/gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    group: "Gemini Flash",
    cost: 1,
  },
  {
    id: "deepseek/deepseek-chat",
    name: "DeepSeek Chat",
    group: "DeepSeek",
    cost: 1,
  },
  {
    id: "mistralai/mistral-large-2",
    name: "Mistral Large 2",
    group: "Mistral",
    cost: 2,
  },
  {
    id: "mistralai/codestral",
    name: "Mistral Codestral",
    group: "Mistral",
    cost: 2,
  },
  {
    id: "xai/grok-2",
    name: "xAI Grok-2",
    group: "Grok",
    cost: 4,
  },
  {
    id: "perplexity/sonar",
    name: "Perplexity Sonar",
    group: "Perplexity",
    cost: 4,
  },
  {
    id: "openai/gpt-5.5-preview",
    name: "GPT-5.5 Preview",
    group: "GPT",
    cost: 5,
  },
  {
    id: "openai/gpt-5.5",
    name: "GPT 5.5",
    group: "GPT",
    cost: 8,
  },
  {
    id: "openai/gpt-4o",
    name: "GPT-4o",
    group: "GPT",
    cost: 5,
  },
  {
    id: "openai/gpt-o1-preview",
    name: "OpenAI o1 Preview",
    group: "GPT",
    cost: 5,
  },
  {
    id: "anthropic/claude-3-5-sonnet",
    name: "Claude 3.5 Sonnet",
    group: "Claude",
    cost: 5,
  },
  {
    id: "anthropic/claude-opus-4.8",
    name: "Claude Opus 4.8",
    group: "Claude",
    cost: 8,
  },
  {
    id: "anthropic/claude-sonnet-4.5",
    name: "Claude Sonnet 4.5",
    group: "Claude",
    cost: 6,
  },
];

export interface PlanConfig {
  key: "free" | "starter" | "pro" | "pro_yearly";
  name: string;
  price: number; // in INR
  limit: number; // credits
  period: "day" | "month" | "year";
  allowedGroups: ("Gemini Flash" | "DeepSeek" | "Mistral" | "Grok" | "Perplexity" | "GPT" | "Claude")[];
}

export const PRICING_PLANS: Record<string, PlanConfig> = {
  free: {
    key: "free",
    name: "Free Plan",
    price: 0,
    limit: 3,
    period: "day",
    allowedGroups: ["Gemini Flash", "DeepSeek"],
  },
  starter: {
    key: "starter",
    name: "Starter Plan",
    price: 199,
    limit: 1000,
    period: "month",
    allowedGroups: ["Gemini Flash", "DeepSeek", "Mistral"],
  },
  pro: {
    key: "pro",
    name: "Pro Plan",
    price: 499,
    limit: 3000,
    period: "month",
    allowedGroups: ["Gemini Flash", "DeepSeek", "Mistral", "Grok", "Perplexity", "GPT", "Claude"],
  },
  pro_yearly: {
    key: "pro_yearly",
    name: "Developer Pro (Yearly)",
    price: 3999,
    limit: 40000,
    period: "year",
    allowedGroups: ["Gemini Flash", "DeepSeek", "Mistral", "Grok", "Perplexity", "GPT", "Claude"],
  },
};

// Affiliate System Constants
export const AFFILIATE_SYSTEM = {
  customerDiscount: 50, // INR ₹50
  affiliateCommission: 50, // INR ₹50
  validCoupons: ["LAUNCH50", "AFFILIATE50", "WEBNIXO50", "START50"],
};

/**
 * Computes model pricing based on applied discount code.
 * @param planKey The target subscription tier
 * @param hasAffiliateDiscount Whether they used a valid affiliate promo code
 */
export function getPlanCost(planKey: string, hasAffiliateDiscount: boolean): number {
  const plan = PRICING_PLANS[planKey.toLowerCase()];
  if (!plan) return 0;
  if (plan.price === 0) return 0;
  
  if (hasAffiliateDiscount) {
    return Math.max(0, plan.price - AFFILIATE_SYSTEM.customerDiscount);
  }
  return plan.price;
}

/**
 * Validates if a model is accessible on a given plan
 */
export function isModelAllowedOnPlan(modelId: string, planKey: string): boolean {
  const plan = PRICING_PLANS[planKey.toLowerCase()] || PRICING_PLANS.free;
  const model = MODERN_MODELS.find(m => m.id === modelId);
  if (!model) return false;
  return plan.allowedGroups.includes(model.group);
}

/**
 * Resolves the cost in credits for a given model ID
 */
export function getModelCreditCost(modelId: string): number {
  const model = MODERN_MODELS.find(m => m.id === modelId);
  return model ? model.cost : 1;
}
