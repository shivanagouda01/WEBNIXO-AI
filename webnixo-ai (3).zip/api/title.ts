export default async function handler(req: any, res: any) {
  // Check for POST request
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }

  try {
    const { message } = req.body;
    if (!message) {
      return res.status(400).json({ title: "New Conversation" });
    }

    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
      return res.json({ title: message.length > 25 ? message.substring(0, 25) + "..." : message });
    }

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
        "HTTP-Referer": "https://ai.studio/build",
        "X-Title": "WEBNIXO AI"
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: "Suggest a brief conversation title (max 3-5 words) summarizing the core topic of the user's message. Respond only with the title itself, with no quotation marks, punctuation, or prefacing words."
          },
          {
            role: "user",
            content: message
          }
        ],
        temperature: 0.5,
        max_tokens: 25
      })
    });

    if (!response.ok) {
      throw new Error(`OpenRouter title API responded with status ${response.status}`);
    }

    const data = await response.json() as any;
    const titleText = data.choices?.[0]?.message?.content || "";
    const cleanTitle = titleText.replace(/^["']|["']$/g, "").trim();
    res.json({ title: cleanTitle || "Active Discussion" });
  } catch (error) {
    console.error("Vercel api/title error:", error);
    res.json({ title: "Active Discussion" });
  }
}
