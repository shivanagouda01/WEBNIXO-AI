export default function handler(req: any, res: any) {
  res.status(200).json({
    status: "ok",
    hasKey: !!process.env.OPENROUTER_API_KEY,
    message: "WEBNIXO AI Vercel backend is operational using OpenRouter."
  });
}
