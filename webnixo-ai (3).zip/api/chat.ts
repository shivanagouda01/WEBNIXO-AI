import { IncomingMessage, ServerResponse } from "http";

function getTokenLimit(promptType?: string): number {
  if (promptType === "website") return 2500;
  if (promptType === "blog") return 3000;
  if (promptType === "social") return 1000;
  return 1500; // default for AI Chat (general, creative, code, concise)
}

export default async function handler(req: any, res: any) {
  // Check for POST request
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }

  const { message, history, model, promptType, files } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message content is required" });
  }

  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error: "API key error",
      details: "OPENROUTER_API_KEY environment variable is not defined on Vercel deployment."
    });
  }

  // Set headers for Server-Sent Events (SSE)
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive"
  });

  try {
    const openRouterMessages: any[] = [];

    // Add system prompt first
    let systemInstruction = "You are WEBNIXO AI, an advanced AI dialogue companion. You provide responses with high clarity, excellent composition, and clear formatting. " +
      "You always return clean Markdown, utilizing bullet lines, tables, and standard language highlighted code blocks (e.g. ```typescript).";

    if (promptType === "creative") {
      systemInstruction += " Adopt an exceptionally imaginative, poetic, or storytelling voice with plenty of descriptive nuance.";
    } else if (promptType === "code") {
      systemInstruction += " Focus heavily on providing clean, robust, and commented code blocks with thorough step-by-step logic and absolutely zero fluff.";
    } else if (promptType === "concise") {
      systemInstruction += " Keep your responses extremely brief, punchy, direct and restricted to only key details.";
    } else if (promptType === "website") {
      systemInstruction += " You are an expert website architect. You write highly clean, responsive, beautiful full HTML/CSS/JS or React webpage structures, focusing on semantic markup, clean Tailwind CSS design patterns, and great animations.";
    } else if (promptType === "blog") {
      systemInstruction += " You are a professional publisher and content strategist. Produce exceptionally structured, engaging, and highly informative blog articles containing rich subheaders, key takeaways, and comprehensive details.";
    } else if (promptType === "social") {
      systemInstruction += " You are a viral growth-hacker and social copywriter. Generate catchy, high-engagement, compact social media postings, threads, and captions with relevant taglines, bullet points, and trending hashtags.";
    }

    openRouterMessages.push({
      role: "system",
      content: systemInstruction
    });

    // Construct history messages
    if (history && Array.isArray(history)) {
      for (const msg of history) {
        const role = msg.role === "user" ? "user" : "assistant";
        
        if (msg.files && Array.isArray(msg.files) && msg.files.length > 0) {
          const contentParts: any[] = [];
          let textAttachments = "";
          
          for (const file of msg.files) {
            if (file.isImage && file.base64) {
              contentParts.push({
                type: "image_url",
                image_url: {
                  url: file.base64
                }
              });
            } else if (file.content) {
              textAttachments += `\n\n--- Attachment: ${file.name} ---\n${file.content}\n-----------------------------`;
            }
          }
          
          contentParts.unshift({
            type: "text",
            text: msg.content + textAttachments
          });
          
          openRouterMessages.push({ role, content: contentParts });
        } else {
          openRouterMessages.push({ role, content: msg.content });
        }
      }
    }

    // Construct current user message
    if (files && Array.isArray(files) && files.length > 0) {
      const contentParts: any[] = [];
      let textAttachments = "";
      
      for (const file of files) {
        if (file.isImage && file.base64) {
          contentParts.push({
            type: "image_url",
            image_url: {
              url: file.base64
            }
          });
        } else if (file.content) {
          textAttachments += `\n\n--- Attachment: ${file.name} ---\n${file.content}\n-----------------------------`;
        }
      }
      
      contentParts.unshift({
        type: "text",
        text: message + textAttachments
      });
      
      openRouterMessages.push({ role: "user", content: contentParts });
    } else {
      openRouterMessages.push({ role: "user", content: message });
    }

    const modelToUse = model || "google/gemini-2.5-flash";
    const tempToUse = promptType === "creative" ? 1.0 : promptType === "code" ? 0.2 : 0.7;

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
        "HTTP-Referer": "https://ai.studio/build",
        "X-Title": "WEBNIXO AI"
      },
      body: JSON.stringify({
        model: modelToUse,
        messages: openRouterMessages,
        stream: true,
        temperature: tempToUse,
        max_tokens: getTokenLimit(promptType)
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      res.write(`data: ${JSON.stringify({ error: `OpenRouter responded with status ${response.status}: ${errorText}` })}\n\n`);
      res.end();
      return;
    }

    if (!response.body) {
      res.write(`data: ${JSON.stringify({ error: "No response body received from OpenRouter API." })}\n\n`);
      res.end();
      return;
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        const cleanLine = line.trim();
        if (!cleanLine) continue;

        if (cleanLine.startsWith("data: ")) {
          const dataStr = cleanLine.substring(6).trim();
          if (dataStr === "[DONE]") {
            continue;
          }

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.error) {
              const errMsg = parsed.error.message || parsed.error.metadata?.message || JSON.stringify(parsed.error);
              res.write(`data: ${JSON.stringify({ error: errMsg })}\n\n`);
              res.end();
              return;
            }
            const text = parsed.choices?.[0]?.delta?.content || "";
            if (text) {
              res.write(`data: ${JSON.stringify({ text })}\n\n`);
            }
          } catch (e) {
            // ignore partial stream lines
          }
        }
      }
    }

    res.end();
  } catch (error: any) {
    console.error("Vercel api/chat error:", error);
    res.write(`data: ${JSON.stringify({ error: error.message || "An error occurred during content generation." })}\n\n`);
    res.end();
  }
}
