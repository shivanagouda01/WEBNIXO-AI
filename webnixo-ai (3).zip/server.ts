import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import fs from "fs";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { 
  checkSupabaseConnection, 
  getSessionsForEmail, 
  upsertChatSession, 
  deleteChatSession, 
  clearAllSessionsForEmail, 
  getGenerationsForEmail, 
  insertGeneration, 
  deleteGenerationFromDb, 
  clearAllGenerationsForEmail,
  getOrCreateUserCredits,
  consumeUserCredits,
  upgradeUserProfilePlan
} from "./server/db";
import { getModelCreditCost, isModelAllowedOnPlan, PRICING_PLANS, getPlanCost, AFFILIATE_SYSTEM } from "./src/lib/pricing_config";
import { loadAdminData, saveAdminData } from "./server/admin_db";

dotenv.config();

// Initialize the native Gemini client lazily
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      geminiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return geminiClient;
}

function getOpenRouterApiKey(): string | null {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey || apiKey.trim() === "" || apiKey === "null" || apiKey === "undefined") {
    return null;
  }
  return apiKey.trim();
}

function mapModelIdForOpenRouter(id: string): string {
  const mapping: Record<string, string> = {
    "google/gemini-3.5-flash": "google/gemini-2.5-flash",
    "anthropic/claude-3-5-sonnet": "anthropic/claude-3.5-sonnet",
    "anthropic/claude-opus-4.8": "anthropic/claude-3-opus",
    "anthropic/claude-sonnet-4.5": "anthropic/claude-3.5-sonnet-20241022",
    "openai/gpt-5.5-preview": "openai/gpt-4o",
    "openai/gpt-5.5": "openai/gpt-4o",
  };
  return mapping[id] || id;
}

function getTokenLimit(promptType?: string): number {
  if (promptType === "website") return 2500;
  if (promptType === "blog") return 3000;
  if (promptType === "social") return 1000;
  return 1500; // default for AI Chat (general, creative, code, concise)
}

async function streamWithGemini(
  res: any,
  message: string,
  history: any[],
  promptType: string,
  files: any[]
) {
  const gemini = getGeminiClient();
  if (!gemini) {
    throw new Error("No native Gemini API key configuration found in server environment.");
  }

  // Set headers for Server-Sent Events (SSE) if not header-sent
  if (!res.headersSent) {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
  }

  // Build system instructions
  let systemInstruction = "You are WEBNIXO AI, an advanced AI dialogue companion. You provide responses with high clarity, excellent composition, and clear formatting. " +
    "You always return clean Markdown, utilizing bullet lines, tables, and standard language highlighted code blocks (e.g. ```typescript).";

  if (promptType === "creative") {
    systemInstruction += " Adopt an exceptionally imaginative, poetic, or storytelling voice with plenty of descriptive nuance.";
  } else if (promptType === "code") {
    systemInstruction += " Focus heavily on providing clean, robust, and commented code blocks with thorough step-by-step logic and absolutely zero fluff.";
  } else if (promptType === "concise") {
    systemInstruction += " Keep your responses extremely brief, punchy, direct and restricted to only key details.";
  } else if (promptType === "website") {
    systemInstruction += " You are an expert website architect. You write highly clean, responsive, beautiful full HTML/CSS/JS or React webpage structures, focusing on semantic markup, clean Tailwind CSS design patterns, and great animations.";
  } else if (promptType === "blog") {
    systemInstruction += " You are a professional publisher and content strategist. Produce exceptionally structured, engaging, and highly informative blog articles containing rich subheaders, key takeaways, and comprehensive details.";
  } else if (promptType === "social") {
    systemInstruction += " You are a viral growth-hacker and social copywriter. Generate catchy, high-engagement, compact social media postings, threads, and captions with relevant taglines, bullet points, and trending hashtags.";
  }

  // Build standard contents list format for GoogleGenAI
  const contentsList: any[] = [];

  // Convert history messages cleanly
  if (history && Array.isArray(history)) {
    for (const msg of history) {
      const role = msg.role === "user" ? "user" : "model";
      const parts: any[] = [];

      // Add attached files support
      if (msg.files && Array.isArray(msg.files)) {
        for (const file of msg.files) {
          if (file.isImage && file.base64) {
            const rawBase64 = file.base64.split(",")[1] || file.base64;
            const mimeType = file.base64.match(/^data:([^;]+);/)?.[1] || "image/png";
            parts.push({
              inlineData: {
                mimeType: mimeType,
                data: rawBase64
              }
            });
          } else if (file.content) {
            parts.push({
              text: `\n[Context File: ${file.name}]\n${file.content}\n`
            });
          }
        }
      }

      parts.push({ text: msg.content || "" });
      contentsList.push({ role, parts });
    }
  }

  // Convert latest message inputs
  const currentParts: any[] = [];
  if (files && Array.isArray(files)) {
    for (const file of files) {
      if (file.isImage && file.base64) {
        const rawBase64 = file.base64.split(",")[1] || file.base64;
        const mimeType = file.base64.match(/^data:([^;]+);/)?.[1] || "image/png";
        currentParts.push({
          inlineData: {
            mimeType: mimeType,
            data: rawBase64
          }
        });
      } else if (file.content) {
        currentParts.push({
          text: `\n[Context File: ${file.name}]\n${file.content}\n`
        });
      }
    }
  }
  currentParts.push({ text: message });
  contentsList.push({ role: "user", parts: currentParts });

  const tempToUse = promptType === "creative" ? 1.0 : promptType === "code" ? 0.2 : 0.7;

  console.log("Streaming chat response using Native `@google/genai` (gemini-3.5-flash)...");

  const responseStream = await gemini.models.generateContentStream({
    model: "gemini-3.5-flash",
    contents: contentsList,
    config: {
      systemInstruction,
      temperature: tempToUse,
    }
  });

  for await (const chunk of responseStream) {
    const text = chunk.text;
    if (text) {
      res.write(`data: ${JSON.stringify({ text })}\n\n`);
    }
  }

  res.write("data: [DONE]\n\n");
  res.end();
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "20mb" }));

  // API Check Endpoint
  app.get("/api/health", (req, res) => {
    const openRouterKey = getOpenRouterApiKey();
    const geminiClientExists = !!getGeminiClient();

    res.json({ 
      status: "ok", 
      hasKey: !!openRouterKey || geminiClientExists,
      hasOpenRouterKey: !!openRouterKey,
      hasGeminiKey: geminiClientExists,
      message: "WEBNIXO AI backend is operational with fully unified routing (OpenRouter & Gemini natively integrated)."
    });
  });

  // Supabase Connection Status
  app.get("/api/supabase-status", async (req, res) => {
    try {
      const status = await checkSupabaseConnection();
      res.json(status);
    } catch (e: any) {
      res.status(500).json({ connected: false, hasTables: false, error: e.message });
    }
  });

  // Credit and usage balance endpoint
  app.get("/api/credits", async (req, res) => {
    try {
      const { email } = req.query;
      if (!email) {
        return res.status(400).json({ error: "Email parameter is required" });
      }
      const data = await getOrCreateUserCredits(String(email));
      res.json(data);
    } catch (err: any) {
      console.error("GET /api/credits API Route error:", err);
      res.status(500).json({ error: err.message || "Failed to fetch user credit tracking profile" });
    }
  });

  // subscription billing upgrade tier endpoint 
  app.post("/api/upgrade", async (req, res) => {
    try {
      const { email, planKey, couponCode } = req.body;
      if (!email || !planKey) {
        return res.status(400).json({ error: "Email and planKey are required to process checkout" });
      }
      const result = await upgradeUserProfilePlan(String(email), String(planKey));
      res.json(result);
    } catch (err: any) {
      console.error("POST /api/upgrade API Route error:", err);
      res.status(500).json({ error: err.message || "Checkout payment transaction failed" });
    }
  });

  // GENERAL PRICING ENDPOINT (Gets active settings with admin overrides)
  app.get("/api/pricing", (req, res) => {
    try {
      const data = loadAdminData();
      res.json({
        success: true,
        plans: data.pricingOverrides,
        settings: data.systemSettings
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to fetch pricing config" });
    }
  });

  // PAYOUT REQUEST SUBMISSION ENDPOINT
  app.post("/api/payout/request", (req, res) => {
    try {
      const { email, affiliateCode, amount, bankDetails } = req.body;
      if (!email || !amount || !bankDetails) {
        return res.status(400).json({ error: "Email, amount and bank account details are required to submit payout request." });
      }

      const data = loadAdminData();
      const token = "TXN-WNX-" + Math.random().toString(36).substring(2, 8).toUpperCase();
      
      const newPayout = {
        token,
        email,
        affiliateCode: affiliateCode || (email.split("@")[0].toUpperCase() + "50"),
        amount: Number(amount),
        date: new Date().toLocaleDateString("en-IN", { day: 'numeric', month: 'short', year: 'numeric' }),
        status: "Processing" as const,
        bankDetails: {
          holderName: bankDetails.holderName || "",
          accountNumber: bankDetails.accountNumber || "",
          ifscCode: bankDetails.ifscCode || "",
          upiId: bankDetails.upiId || ""
        }
      };

      data.payouts.unshift(newPayout);
      saveAdminData(data);

      res.json({ success: true, payout: newPayout });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to submit payout request." });
    }
  });

  // ADMIN ENDPOINT: FETCH ALL PAYOUTS
  app.get("/api/admin/payouts", (req, res) => {
    try {
      const { email } = req.query;
      const admins = ["spatil23012008@gmail.com", "shivanagouda.012@gmail.com", "ytshivu8@gmail.com"];
      if (!email || !admins.includes(String(email).trim().toLowerCase())) {
        return res.status(403).json({ error: "Access Denied. Admin accounts only can check ledger dispatches." });
      }

      const data = loadAdminData();
      res.json({ success: true, payouts: data.payouts });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to load payouts for administrator portal." });
    }
  });

  // ADMIN ENDPOINT: UPDATE PAYOUT STATUS & DETAILS
  app.post("/api/admin/payouts/update", (req, res) => {
    try {
      const { email, token, status, transactionId, notes } = req.body;
      const admins = ["spatil23012008@gmail.com", "shivanagouda.012@gmail.com", "ytshivu8@gmail.com"];
      if (!email || !admins.includes(String(email).trim().toLowerCase())) {
        return res.status(403).json({ error: "Access Denied. Admin accounts only." });
      }

      const data = loadAdminData();
      const payoutIdx = data.payouts.findIndex(p => p.token === token);
      if (payoutIdx === -1) {
        return res.status(404).json({ error: `Payout Token '${token}' not found on file db.` });
      }

      data.payouts[payoutIdx].status = status;
      if (transactionId !== undefined) {
        data.payouts[payoutIdx].transactionId = transactionId;
      }
      if (notes !== undefined) {
        data.payouts[payoutIdx].notes = notes;
      }

      saveAdminData(data);
      res.json({ success: true, payout: data.payouts[payoutIdx] });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to update payout token status." });
    }
  });

  // ADMIN ENDPOINT: UPDATE PRICING AND COUPONS
  app.post("/api/admin/pricing/update", (req, res) => {
    try {
      const { 
        email, 
        starterPrice, starterLimit, 
        proPrice, proLimit, 
        proYearlyPrice, proYearlyLimit, 
        customerDiscount, affiliateCommission, 
        validCoupons 
      } = req.body;

      const admins = ["spatil23012008@gmail.com", "shivanagouda.012@gmail.com", "ytshivu8@gmail.com"];
      if (!email || !admins.includes(String(email).trim().toLowerCase())) {
        return res.status(403).json({ error: "Access Denied. Admin accounts only." });
      }

      const data = loadAdminData();

      if (starterPrice !== undefined) data.pricingOverrides.starter.price = Number(starterPrice);
      if (starterLimit !== undefined) data.pricingOverrides.starter.limit = Number(starterLimit);

      if (proPrice !== undefined) data.pricingOverrides.pro.price = Number(proPrice);
      if (proLimit !== undefined) data.pricingOverrides.pro.limit = Number(proLimit);

      if (proYearlyPrice !== undefined) data.pricingOverrides.pro_yearly.price = Number(proYearlyPrice);
      if (proYearlyLimit !== undefined) data.pricingOverrides.pro_yearly.limit = Number(proYearlyLimit);

      if (customerDiscount !== undefined) data.systemSettings.customerDiscount = Number(customerDiscount);
      if (affiliateCommission !== undefined) data.systemSettings.affiliateCommission = Number(affiliateCommission);
      
      if (validCoupons !== undefined) {
        if (Array.isArray(validCoupons)) {
          data.systemSettings.validCoupons = validCoupons.map((c: string) => c.trim().toUpperCase());
        } else if (typeof validCoupons === "string") {
          data.systemSettings.validCoupons = (validCoupons as string)
            .split(",")
            .map(c => c.trim().toUpperCase())
            .filter(Boolean);
        }
      }

      saveAdminData(data);
      res.json({ 
        success: true, 
        plans: data.pricingOverrides, 
        settings: data.systemSettings 
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Failed to finalize pricing modifications on configuration store." });
    }
  });

  // CASHFREE CHECKOUT GATEWAY api endpoints
  app.post("/api/cashfree/create-order", async (req, res) => {
    try {
      const { email, planKey, couponCode } = req.body;
      if (!email || !planKey) {
        return res.status(400).json({ error: "Email and planKey are required to create payment order" });
      }

      const CASHFREE_APP_ID = process.env.CASHFREE_APP_ID || "126261124527ddafb0e31c545111162621";
      const CASHFREE_SECRET_KEY = process.env.CASHFREE_SECRET_KEY || "cfsk_ma_prod_80291f08dac3a46e542d698a5a3f189f_df8b841e";

      const normalizedPlan = planKey.toLowerCase();
      const plan = PRICING_PLANS[normalizedPlan];
      if (!plan) {
        return res.status(400).json({ error: `Invalid subscription plan key: ${planKey}` });
      }

      // Check for active admin overrides
      const adminData = loadAdminData();
      const override = adminData.pricingOverrides[normalizedPlan as keyof typeof adminData.pricingOverrides];
      const baseCost = override ? override.price : plan.price;

      // Compute total costing
      let hasDiscount = false;
      if (couponCode) {
        const cleanup = couponCode.trim().toUpperCase();
        if (adminData.systemSettings.validCoupons.includes(cleanup)) {
          hasDiscount = true;
        }
      }

      const cost = hasDiscount 
        ? Math.max(0, baseCost - adminData.systemSettings.customerDiscount) 
        : baseCost;

      // Unique order details in Cashfree
      const orderId = `order_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      const customerId = email.replace(/[^a-zA-Z0-9]/g, "_");

      const host = req.get('host') || 'localhost:3000';
      const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
      const returnUrl = `${protocol}://${host}/?order_id={order_id}&plan_key=${normalizedPlan}&email=${encodeURIComponent(email)}`;

      console.log(`[CASHFREE] Creating order_id=${orderId} email=${email} plan=${normalizedPlan} amount=₹${cost}`);

      const response = await fetch("https://api.cashfree.com/pg/orders", {
        method: "POST",
        headers: {
          "x-client-id": CASHFREE_APP_ID,
          "x-client-secret": CASHFREE_SECRET_KEY,
          "x-api-version": "2023-08-01",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          order_amount: cost,
          order_currency: "INR",
          order_id: orderId,
          customer_details: {
            customer_id: customerId,
            customer_email: email,
            customer_phone: "9999999999"
          },
          order_meta: {
            return_url: returnUrl
          }
        })
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("[CASHFREE] PG gateway create order response error:", errText);
        throw new Error(`Cashfree Error: ${errText}`);
      }

      const orderData: any = await response.json();
      res.json({
        success: true,
        order_id: orderData.order_id,
        payment_session_id: orderData.payment_session_id,
        order_status: orderData.order_status,
        order_amount: cost
      });

    } catch (err: any) {
      console.error("[CASHFREE] Error inside create-order API Route:", err);
      res.status(500).json({ error: err.message || "Failed to create checkout transaction in Cashfree gateway" });
    }
  });

  app.post("/api/cashfree/verify-payment", async (req, res) => {
    try {
      const { orderId, email, planKey } = req.body;
      if (!orderId || !email || !planKey) {
        return res.status(400).json({ error: "orderId, email and planKey are required to verify transaction" });
      }

      const CASHFREE_APP_ID = process.env.CASHFREE_APP_ID || "126261124527ddafb0e31c545111162621";
      const CASHFREE_SECRET_KEY = process.env.CASHFREE_SECRET_KEY || "cfsk_ma_prod_80291f08dac3a46e542d698a5a3f189f_df8b841e";

      console.log(`[CASHFREE] Verifying orderId=${orderId} for email=${email}`);

      const response = await fetch(`https://api.cashfree.com/pg/orders/${orderId}`, {
        method: "GET",
        headers: {
          "x-client-id": CASHFREE_APP_ID,
          "x-client-secret": CASHFREE_SECRET_KEY,
          "x-api-version": "2023-08-01",
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("[CASHFREE] PG gateway verify response error text:", errText);
        throw new Error(`Cashfree verification request failed: ${errText}`);
      }

      const orderData: any = await response.json();
      console.log(`[CASHFREE] Order status in gateway check: ${orderData.order_status}`);

      if (orderData.order_status === "PAID" || orderData.order_status === "SUCCESS") {
        // DB upgrade triggered
        const result = await upgradeUserProfilePlan(String(email), String(planKey));
        res.json({
          success: true,
          status: orderData.order_status,
          plan: result.plan,
          message: "Database upgraded and subscription transaction finalized successfully!"
        });
      } else {
        res.json({
          success: false,
          status: orderData.order_status,
          message: `Your payment was not verified. Status: ${orderData.order_status}`
        });
      }

    } catch (err: any) {
      console.error("[CASHFREE] Error inside verify-payment API Route:", err);
      res.status(500).json({ error: err.message || "Verification checkout transaction failure" });
    }
  });

  // Get all sessions for a user email
  app.get("/api/sessions", async (req, res) => {
    try {
      const { email } = req.query;
      if (!email) {
        return res.status(400).json({ error: "Email parameter is required" });
      }
      const data = await getSessionsForEmail(String(email));
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to retrieve sessions" });
    }
  });

  // Save/Update session
  app.post("/api/sessions", async (req, res) => {
    try {
      const { session, email } = req.body;
      if (!session || !email) {
        return res.status(400).json({ error: "Session and email are required" });
      }
      const data = await upsertChatSession(session, email);
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to save session" });
    }
  });

  // Delete a specific session
  app.delete("/api/sessions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { email } = req.query;
      if (!email) {
        return res.status(400).json({ error: "Email parameter is required" });
      }
      const data = await deleteChatSession(id, String(email));
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to delete session" });
    }
  });

  // Clear all sessions for an email
  app.delete("/api/sessions", async (req, res) => {
    try {
      const { email } = req.query;
      if (!email) {
        return res.status(400).json({ error: "Email parameter is required" });
      }
      const data = await clearAllSessionsForEmail(String(email));
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to clear sessions" });
    }
  });

  // Get all generations for a user email
  app.get("/api/generations", async (req, res) => {
    try {
      const { email } = req.query;
      if (!email) {
        return res.status(400).json({ error: "Email parameter is required" });
      }
      const data = await getGenerationsForEmail(String(email));
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to retrieve generations" });
    }
  });

  // Save an image generation
  app.post("/api/generations", async (req, res) => {
    try {
      const { generation, email } = req.body;
      if (!generation || !email) {
        return res.status(400).json({ error: "Generation and email are required" });
      }
      const data = await insertGeneration(generation, email);
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to save image generation" });
    }
  });

  // Delete a specific image generation
  app.delete("/api/generations/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { email } = req.query;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      const data = await deleteGenerationFromDb(id, String(email));
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to delete generation" });
    }
  });

  // Clear all generations for an email
  app.delete("/api/generations", async (req, res) => {
    try {
      const { email } = req.query;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      const data = await clearAllGenerationsForEmail(String(email));
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to clear generations" });
    }
  });

  // Intelligent Title Generation Endpoint
  app.post("/api/title", async (req, res) => {
    try {
      const { message } = req.body;
      if (!message) {
        return res.status(400).json({ title: "New Conversation" });
      }

      const openRouterKey = getOpenRouterApiKey();
      const gemini = getGeminiClient();

      // If we don't have OpenRouter or if it is suspected to be invalid, immediately prefer native Gemini SDK
      if (!openRouterKey && gemini) {
        try {
          const response = await gemini.models.generateContent({
            model: "gemini-3.5-flash",
            contents: message,
            config: {
              systemInstruction: "Suggest a brief conversation title (max 2-4 words) summarizing the core topic of the user's message. Respond only with the title itself, with no quotation marks, punctuation, or prefacing words."
            }
          });
          const text = response.text || "";
          const cleanTitle = text.replace(/^["']|["']$/g, "").trim();
          if (cleanTitle) {
            return res.json({ title: cleanTitle });
          }
        } catch (gemError) {
          console.error("Gemini title generation fallback failed:", gemError);
        }
      }

      // Try OpenRouter if key is present
      if (openRouterKey) {
        try {
          const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${openRouterKey}`,
              "HTTP-Referer": "https://ai.studio/build",
              "X-Title": "WEBNIXO AI"
            },
            body: JSON.stringify({
              model: "google/gemini-2.5-flash",
              messages: [
                {
                  role: "system",
                  content: "Suggest a brief conversation title (max 2-4 words) summarizing the core topic of the user's message. Respond only with the title itself, with no quotation marks, punctuation, or prefacing words."
                },
                {
                  role: "user",
                  content: message
                }
              ],
              temperature: 0.5,
              max_tokens: 25
            })
          });

          if (response.ok) {
            const data = await response.json() as any;
            const titleText = data.choices?.[0]?.message?.content || "";
            const cleanTitle = titleText.replace(/^["']|["']$/g, "").trim();
            if (cleanTitle) {
              return res.json({ title: cleanTitle });
            }
          }
        } catch (error) {
          console.error("OpenRouter title fetch failed, falling back to Gemini:", error);
        }
      }

      // Final local fallbacks
      if (gemini) {
        try {
          const gemResponse = await gemini.models.generateContent({
            model: "gemini-3.5-flash",
            contents: message,
            config: {
              systemInstruction: "Suggest a brief conversation title (max 2-4 words) summarizing the core topic of the user's message. Respond only with the title itself, with no quotation marks, punctuation, or prefacing words."
            }
          });
          const text = gemResponse.text || "";
          const cleanTitle = text.replace(/^["']|["']$/g, "").trim();
          if (cleanTitle) return res.json({ title: cleanTitle });
        } catch (e) {
          // ignore
        }
      }

      res.json({ title: message.length > 25 ? message.substring(0, 25) + "..." : message });
    } catch (error) {
      console.error("Failed to generate topic title:", error);
      res.json({ title: "Active Discussion" });
    }
  });

  // Streaming Chat Endpoint using SSE
  app.post("/api/chat", async (req, res) => {
    const { message, history, model, promptType, files, email } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message content is required" });
    }

    // 1. Credit-Based Subscription Authorization Enforcement
    if (email) {
      try {
        const credits = await getOrCreateUserCredits(String(email));
        const cost = getModelCreditCost(model);

        if (!isModelAllowedOnPlan(model, credits.plan)) {
          return res.status(403).json({
            error: `Subscription Constraint: Access to the requested model is locked on your current ${credits.plan.toUpperCase()} plan. Please upgrade to unleash full capabilities.`
          });
        }

        if (credits.creditsRemaining < cost) {
          return res.status(403).json({
            error: `Usage Balance Depleted: This action requires ${cost} credits, but you only have ${credits.creditsRemaining} credits left today/this month.`
          });
        }

        // Fully consume credits securely at the gate of generation
        await consumeUserCredits(String(email), cost);
      } catch (err: any) {
        console.error("Express API credit validation system error:", err);
      }
    }

    const openRouterKey = getOpenRouterApiKey();
    const gemini = getGeminiClient();

    // If OpenRouter key is not specified, route immediately to native Gemini
    if (!openRouterKey) {
      if (gemini) {
        try {
          await streamWithGemini(res, message, history, promptType, files);
          return;
        } catch (gemStreamError: any) {
          console.error("Native Gemini streaming execution failed:", gemStreamError);
          return res.status(500).json({ error: "Streaming failed", details: gemStreamError.message });
        }
      } else {
        return res.status(500).json({ 
          error: "API key error", 
          details: "No active OPENROUTER_API_KEY detected and native GEMINI_API_KEY is not pre-configured in sandbox." 
        });
      }
    }

    // Attempt OpenRouter streaming
    try {
      // Set headers for Server-Sent Events (SSE)
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      // Build model messages representation in OpenAI/OpenRouter format
      const openRouterMessages: any[] = [];

      // Add system prompt first
      let systemInstruction = "You are WEBNIXO AI, an advanced AI dialogue companion. You provide responses with high clarity, excellent composition, and clear formatting. " +
        "You always return clean Markdown, utilizing bullet lines, tables, and standard language highlighted code blocks (e.g. ```typescript).";

      if (promptType === "creative") {
        systemInstruction += " Adopt an exceptionally imaginative, poetic, or storytelling voice with plenty of descriptive nuance.";
      } else if (promptType === "code") {
        systemInstruction += " Focus heavily on providing clean, robust, and commented code blocks with thorough step-by-step logic and absolutely zero fluff.";
      } else if (promptType === "concise") {
        systemInstruction += " Keep your responses extremely brief, punchy, direct and restricted to only key details.";
      } else if (promptType === "website") {
        systemInstruction += " You are an expert website architect. You write highly clean, responsive, beautiful full HTML/CSS/JS or React webpage structures, focusing on semantic markup, clean Tailwind CSS design patterns, and great animations.";
      } else if (promptType === "blog") {
        systemInstruction += " You are a professional publisher and content strategist. Produce exceptionally structured, engaging, and highly informative blog articles containing rich subheaders, key takeaways, and comprehensive details.";
      } else if (promptType === "social") {
        systemInstruction += " You are a viral growth-hacker and social copywriter. Generate catchy, high-engagement, compact social media postings, threads, and captions with relevant taglines, bullet points, and trending hashtags.";
      }

      openRouterMessages.push({
        role: "system",
        content: systemInstruction
      });

      // Construct history messages
      if (history && Array.isArray(history)) {
        for (const msg of history) {
          const role = msg.role === "user" ? "user" : "assistant";
          
          if (msg.files && Array.isArray(msg.files) && msg.files.length > 0) {
            const contentParts: any[] = [];
            let textAttachments = "";
            
            for (const file of msg.files) {
              if (file.isImage && file.base64) {
                contentParts.push({
                  type: "image_url",
                  image_url: {
                    url: file.base64
                  }
                });
              } else if (file.content) {
                textAttachments += `\n\n--- Attachment: ${file.name} ---\n${file.content}\n-----------------------------`;
              }
            }
            
            contentParts.unshift({
              type: "text",
              text: (msg.content || "") + textAttachments
            });
            
            openRouterMessages.push({ role, content: contentParts });
          } else {
            openRouterMessages.push({ role, content: msg.content || "" });
          }
        }
      }

      // Construct current user message
      if (files && Array.isArray(files) && files.length > 0) {
        const contentParts: any[] = [];
        let textAttachments = "";
        
        for (const file of files) {
          if (file.isImage && file.base64) {
            contentParts.push({
              type: "image_url",
              image_url: {
                url: file.base64
              }
            });
          } else if (file.content) {
            textAttachments += `\n\n--- Attachment: ${file.name} ---\n${file.content}\n-----------------------------`;
          }
        }
        
        contentParts.unshift({
          type: "text",
          text: message + textAttachments
        });
        
        openRouterMessages.push({ role: "user", content: contentParts });
      } else {
        openRouterMessages.push({ role: "user", content: message });
      }

      const originalModel = model || "google/gemini-2.5-flash";
      const modelToUse = mapModelIdForOpenRouter(originalModel);
      const tempToUse = promptType === "creative" ? 1.0 : promptType === "code" ? 0.2 : 0.7;

      console.log(`Routing stream request to OpenRouter (Model: ${modelToUse})...`);

      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${openRouterKey}`,
          "HTTP-Referer": "https://ai.studio/build",
          "X-Title": "WEBNIXO AI"
        },
        body: JSON.stringify({
          model: modelToUse,
          messages: openRouterMessages,
          stream: true,
          temperature: tempToUse,
          max_tokens: getTokenLimit(promptType)
        })
      });

      // If OpenRouter returns any error code (e.g., 401 Unauthorized, invalid token, route limit), try Gemini fallback
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`OpenRouter returned status ${response.status}: ${errorText}. Activating native Gemini fallback...`);
        
        if (gemini) {
          await streamWithGemini(res, message, history, promptType, files);
          return;
        } else {
          throw new Error(`OpenRouter returned status ${response.status}: ${errorText}`);
        }
      }

      if (!response.body) {
        throw new Error("No response body stream received from OpenRouter.");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          const cleanLine = line.trim();
          if (!cleanLine) continue;

          if (cleanLine.startsWith("data: ")) {
            const dataStr = cleanLine.substring(6).trim();
            if (dataStr === "[DONE]") {
              continue;
            }

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.error) {
                const errMsg = parsed.error.message || parsed.error.metadata?.message || JSON.stringify(parsed.error);
                
                // If OpenRouter streams an authorization / user not found error mid-flight, fallback to Gemini in real-time
                if (parsed.error.code === 401 || errMsg.toLowerCase().includes("user not found") || errMsg.toLowerCase().includes("unauthorized")) {
                  console.warn("Mid-stream 401 error received from OpenRouter. Attempting native Gemini bypass...");
                  if (gemini) {
                    await streamWithGemini(res, message, history, promptType, files);
                    return;
                  }
                }

                res.write(`data: ${JSON.stringify({ error: errMsg })}\n\n`);
                res.end();
                return;
              }
              const text = parsed.choices?.[0]?.delta?.content || "";
              if (text) {
                res.write(`data: ${JSON.stringify({ text })}\n\n`);
              }
            } catch (e) {
              // ignore partial lines parsing issues
            }
          }
        }
      }

      res.write(`data: [DONE]\n\n`);
      res.end();

    } catch (openRouterError: any) {
      console.error("OpenRouter execution failed, trying fallback to native Gemini SDK:", openRouterError);
      if (gemini) {
        try {
          await streamWithGemini(res, message, history, promptType, files);
        } catch (geminiError: any) {
          console.error("Both OpenRouter and Gemini SDK failed to generate response:", geminiError);
          res.write(`data: ${JSON.stringify({ error: `Connection limit reached: ${geminiError.message}` })}\n\n`);
          res.end();
        }
      } else {
        res.write(`data: ${JSON.stringify({ error: openRouterError.message || "An unexpected error occurred during chat routing." })}\n\n`);
        res.end();
      }
    }
  });

  // Serve Static Frontend
  const distPath = path.join(process.cwd(), "dist");
  const hasDist = fs.existsSync(path.join(distPath, "index.html"));

  if (process.env.NODE_ENV !== "production" || !hasDist) {
    console.log("Starting backend with Vite live dev-modelling middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`WEBNIXO AI Server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
